const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
const section = (start, end) => html.slice(html.indexOf(start), html.indexOf(end));
const source =
  section('function spawnAt(', 'function spawnSpiderlings(') +
  section('function spawnBoss(){', 'function toast(') +
  section('function damageBug(', 'var COMBO_WORDS=') +
  section('function killBug(', 'function updateScore()');
const noop = () => {};
function game(mode = 'classic') {
  const g = {
    W:360, H:720, elapsed:0, mode, MODE_CLASSIC:'classic',
    MODE_ATTACK:'cakeattack', MODE_HENGUARD:'henguard', boss:null, bugs:[],
    cake:null, level:1, wave:1, score:0, coinsThisRun:0, waveKills:0,
    stats:{ kills:{ ant:0,boss:0 } }, feverUntil:1e9, comboFill:0,
    TYPES:{ant:{hp:1,r:12,speed:40,points:4,color:'#432',bodyColor:'#432'}},
    worldMod:()=>({speed:1,boss:1}), phaseHasCake:()=>false,
    rand:(a,b)=>(a+b)/2, clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),
    t:x=>x, tt:x=>x, toast:noop, popup:noop, burst:noop,
    stampSplat:noop, shakePaper:noop, sfxBossHit:noop, sfxBossDown:noop,
    vibrate:noop, updateScore:noop, registerCombo:()=>1, hitStop:noop,
    sfxPowerup:noop, beetleArmored:()=>false, sfxEmpty:noop,
    atkHurt:noop, spawnSpiderlings:noop, spawnWeb:noop,
  };
  vm.createContext(g); vm.runInContext(source,g); g.spawnBoss();
  return g;
}
let checks=0;
function check(name,fn){fn(); checks++; console.log('PASS',name);}
check('Classic giant is a smaller ant with exactly five hit points',()=>{
  const g=game();
  assert.equal(g.boss.isAnt,true);
  assert.equal(g.boss.r,24);
  assert.equal(g.boss.hp,5);
});
check('Five accepted hits kill the giant; each hit releases exactly five guards',()=>{
  const g=game();
  for(let hit=1;hit<=5;hit++){
    g.elapsed=hit;
    const owner=g.boss;
    g.damageBoss(1000);
    assert.equal(owner.hp,5-hit);
    const guards=g.bugs.filter(b=>b.bossGuard===owner && !b.guardDefeated);
    assert.equal(guards.length,5);
    assert.equal(owner.guardsLeft,5);
    assert(guards.every(b=>b.r===7 && b.hp===1 && b.visualScale===0.65));
    if(hit===5){assert.equal(g.boss,null); break;}
    g.damageBoss(1000);
    assert.equal(owner.hp,5-hit,'Shield must reject heavy/repeated hits');
    for(let i=0;i<4;i++){
      const b=guards[i];
      g.damageBug(b,1,g.bugs.indexOf(b));
    }
    assert.equal(owner.guardsLeft,1);
    g.damageBoss(1000);
    assert.equal(owner.hp,5-hit,'The fifth guard is mandatory');
    g.damageBug(guards[4],1,g.bugs.indexOf(guards[4]));
    assert.equal(owner.guardsLeft,0);
  }
  assert.equal(g.stats.kills.boss,1);
  assert.equal(g.stats.kills.ant,20);
  assert.doesNotThrow(()=>g.damageBoss(1000));
});
check('Only the correct living guard wave controls the shield',()=>{
  const g=game(); g.damageBoss(1);
  const old=g.bugs[0];
  g.releaseBossGuard({});
  assert.equal(g.boss.guardsLeft,5);
  g.releaseBossGuard(old); g.releaseBossGuard(old);
  assert.equal(g.boss.guardsLeft,4);
  g.clearContinueBugs();
  assert.equal(g.bugs.length,5);
  assert.equal(g.boss.guardsLeft,5);
  old.guardDefeated=false;
  g.releaseBossGuard(old);
  assert.equal(g.boss.guardsLeft,5,'Old guard references cannot unlock a fresh wave');
});
check('Classic giant moves horizontally and vertically throughout the paper',()=>{
  const g=game(); g.boss.phase='fight'; g.boss.turnAt=1e6;
  for(const [tx,ty] of [[50,90],[310,90],[310,650],[50,650]]){
    g.boss.x=180; g.boss.y=350; g.boss.tx=tx; g.boss.ty=ty;
    g.updateAntBoss(1);
    assert.equal(Math.sign(g.boss.x-180),Math.sign(tx-180));
    assert.equal(Math.sign(g.boss.y-350),Math.sign(ty-350));
    assert(g.boss.x>=30 && g.boss.x<=330);
    assert(g.boss.y>=70 && g.boss.y<=690);
  }
});
check('Non-classic legacy bosses retain their existing health and damage rules',()=>{
  const g=game('henguard');
  assert.equal(g.boss.isAnt,false);
  assert.equal(g.boss.hp,14);
  g.damageBoss(2);
  assert.equal(g.boss.hp,12);
  assert.equal(g.bugs.length,0);
});
console.log(`All ${checks} classic-giant checks passed.`);

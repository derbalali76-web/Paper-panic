const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
const section = (start, end) => html.slice(html.indexOf(start), html.indexOf(end));
const source =
  section('function spawnAt(', 'function spawnSpiderlings(') +
  section('var BOSS_KINDS=', 'function toast(') +
  section('function damageBug(', 'var COMBO_WORDS=') +
  section('function killBug(', 'function updateScore()');
const noop = () => {};
function game(mode = 'classic') {
  const g = {
    W:360, H:720, elapsed:0, mode, MODE_CLASSIC:'classic',
    MODE_ATTACK:'cakeattack', MODE_HENGUARD:'henguard', boss:null, bugs:[],
    cake:null, level:1, wave:1, score:0, coinsThisRun:0, waveKills:0,
    stats:{ kills:{ ant:0,boss:0 } }, feverUntil:1e9, comboFill:0,
    TYPES:Object.fromEntries(['ant','roach','beetle','fly','ladybug','flea'].map(k=>[k,{hp:1,r:12,speed:40,points:4,color:'#432',bodyColor:'#432'}])),
    bossPoops:[], BOSS_WAVE_COUNTS:[4,6,8,10,12], BOSS_WAVE_TYPES:['roach','beetle','fly','ladybug','flea','ant'],
    worldMod:()=>({speed:1,boss:1}), phaseHasCake:()=>false,
    rand:(a,b)=>(a+b)/2, clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),
    lang:'en', t:x=>x, tt:x=>x, toast:noop, popup:noop, burst:noop,
    stampSplat:(...a)=>{g.splats=(g.splats||0)+1;}, shakePaper:noop, sfxBossHit:noop, sfxBossDown:noop, sfxBossBoing:noop, sfxBossFall:noop, sfxSlideUp:noop, sfxKill:noop,
    vibrate:noop, updateScore:noop, registerCombo:()=>1, hitStop:noop,
    sfxPowerup:noop, beetleArmored:()=>false, sfxEmpty:noop,
    atkHurt:noop, spawnSpiderlings:noop, spawnWeb:noop, setTimeout:noop, currentStage:0, stageWorld:()=>0,
  };
  vm.createContext(g); vm.runInContext(source,g); g.spawnBoss();
  return g;
}
let checks=0;
function check(name,fn){fn(); checks++; console.log('PASS',name);}
check('Classic giant is a small ant with 25 hit points (5 cycles x 5 hits)',()=>{
  const g=game();
  assert.equal(g.boss.isAnt,true);
  assert(['ant','ladybug','flea','fly'].includes(g.boss.kind));
  assert.equal(g.boss.hp,25);
  assert.equal(new Set(g.boss.waveTypes).size,1,'a giant only releases its own kind');
  assert.equal(g.boss.waveTypes[0],g.boss.kind);
});
check('Ant giant: 5th hit queues a telegraphed summon instead of spawning instantly',()=>{
  let g=game(); while(g.boss.kind!=='ant') g=game();
  let t=0; for(let hit=1;hit<=5;hit++){ t+=1; g.elapsed=t; g.boss.guardsLeft=0; g.damageBoss(1,'hammer'); }
  assert.equal(g.boss.pendingWave,true); assert.equal(g.bugs.length,0,'no instant wave');
});
check('Every 5 hammer hits releases a bigger shielded wave of a new type; 25th hit kills',()=>{
  let g=game(); while(g.boss.kind==='ant') g=game();
  /* ant waves are telegraphed (pendingWave) — covered by the previous check */  const owner=g.boss; const counts=[]; const types=[]; let t=0;
  for(let hit=1;hit<=25;hit++){
    t+=1; g.elapsed=t;
    const before=g.bugs.length;
    g.damageBoss(1000,'hammer');
    assert.equal(owner.hp,25-hit,'every accepted hammer hit costs exactly 1 hp');
    if(hit%5===0 && hit<25){
      const fresh=g.bugs.slice(before);
      counts.push(fresh.length); types.push(fresh[0].type);
      assert(fresh.every(b=>b.type===fresh[0].type && b.bossGuard===owner),'one type per wave');
      assert.equal(owner.guardsLeft,fresh.length);
      t+=1; g.elapsed=t; g.damageBoss(1000,'hammer');
      assert.equal(owner.hp,25-hit,'shield rejects hits while the wave lives');
      for(const b of fresh.slice(0,-1)) g.damageBug(b,1,g.bugs.indexOf(b));
      t+=1; g.elapsed=t; g.damageBoss(1000,'hammer');
      assert.equal(owner.hp,25-hit,'last guard still mandatory');
      const last=fresh[fresh.length-1]; g.damageBug(last,1,g.bugs.indexOf(last));
      assert.equal(owner.guardsLeft,0);
    }
  }
  assert.deepEqual(counts,[4,6,8,10]);
  assert.equal(new Set(types).size,1,'same small kind every wave');
  assert.equal(types[0],owner.kind);
  assert.equal(g.boss,null);
  assert.equal(g.stats.kills.boss,1);
  assert.doesNotThrow(()=>g.damageBoss(1000,'hammer'));
});
check('Shoe and every non-hammer source cannot hurt the ant giant',()=>{
  const g=game(); g.elapsed=1;
  assert.equal(g.damageBoss(1),false); assert.equal(g.damageBoss(2,'shoe'),false);
  assert.equal(g.boss.hp,25); assert.equal(g.boss.cycleHits,0);
});
check('Rapid repeated hammer hits inside the cooldown are ignored',()=>{
  const g=game(); g.elapsed=1; g.damageBoss(1,'hammer'); g.damageBoss(1,'hammer');
  assert.equal(g.boss.hp,24);
});
check('Boss droppings land and stain the paper',()=>{
  const g=game(); g.boss.phase='fight'; g.boss.turnAt=1e6; g.boss.nextPoop=0; g.elapsed=1;
  g.updateAntBoss(0.016);
  assert.equal(g.bossPoops.length,1);
  g.updateBossPoops(1);
  assert.equal(g.bossPoops.length,0);
  assert.equal(g.splats,1);
});
check('Classic giant moves horizontally and vertically throughout the paper',()=>{
  const g=game(); g.boss.phase='fight'; g.boss.turnAt=1e6;
  for(const [tx,ty] of [[50,90],[310,90],[310,650],[50,650]]){
    g.boss.x=180; g.boss.y=350; g.boss.tx=tx; g.boss.ty=ty;
    g.updateAntBoss(1);
    assert.equal(Math.sign(g.boss.x-180),Math.sign(tx-180));
    assert.equal(Math.sign(g.boss.y-350),Math.sign(ty-350));
    assert(g.boss.x>=30 && g.boss.x<=330);
    assert(g.boss.y>=70 && g.boss.y<=690);
  }
});
check('Cake-guard mode uses the very same giant rules as classic',()=>{
  const g=game('henguard');
  assert.equal(g.boss.isAnt,true); assert.equal(g.boss.hp,25);
  g.elapsed=1; assert.equal(g.damageBoss(2,'shoe'),false); assert.equal(g.boss.hp,25);
  g.elapsed=3; g.damageBoss(1,'hammer'); assert.equal(g.boss.hp,24);
});
check('Giants rotate: never the same kind twice in a row, all four appear',()=>{
  const g=game(); const seen=new Set([g.boss.kind]); let prev=g.boss.kind;
  for(let i=0;i<60;i++){ g.spawnBoss(); assert.notEqual(g.boss.kind,prev); prev=g.boss.kind; seen.add(prev); }
  assert.equal(seen.size,4);
});
check('Old roach queen still used by non-giant modes (speed-clean)',()=>{
  const g=game('speedclean');
  assert.equal(g.boss.isAnt,false); assert.equal(g.boss.hp,14);
});
console.log(`All ${checks} classic-giant checks passed.`);

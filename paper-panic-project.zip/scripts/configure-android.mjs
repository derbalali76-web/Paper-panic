/* Prepares the generated Capacitor Android project for release.
   Runs on the GitHub build server after `npx cap add android` (safe to run twice):
     - locks the game to portrait (one-handed play)
     - adds the vibration permission (haptic feedback on hits)
     - sets versionCode / versionName
     - signs release builds when a keystore is present */
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const A = (p) => path.join(root, "android", p);
const read = (p) => fs.readFileSync(A(p), "utf8");
const write = (p, s) => fs.writeFileSync(A(p), s);
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const done = [];

// 1) portrait + vibration + AdMob app id + billing permission (in-app purchases)
//    IMPORTANT: the AdMob App ID below is Google's PUBLIC TEST ID. Replace with your own real
//    App ID (looks like ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX) once the app is set up in
//    the AdMob console. The test ID shows test ads only — safe to publish while testing,
//    but the Play Store listing can be rejected if you serve test ads to real users long term.
const ADMOB_APP_ID = process.env.ADMOB_APP_ID || "ca-app-pub-2543802268630336~7271366722";
let manifest = read("app/src/main/AndroidManifest.xml");
if (!manifest.includes("android:screenOrientation")) {
  manifest = manifest.replace('android:name=".MainActivity"', 'android:name=".MainActivity"\n            android:screenOrientation="portrait"');
}
if (!manifest.includes("android.permission.VIBRATE")) {
  manifest = manifest.replace("</manifest>", '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
}
// Google Play Billing permission (added by cordova-plugin-purchase automatically, but ensure it's there)
if (!manifest.includes("com.android.vending.BILLING")) {
  manifest = manifest.replace("</manifest>", '    <uses-permission android:name="com.android.vending.BILLING" />\n</manifest>');
}
// AdMob App ID meta-data (required by the AdMob SDK on first launch)
if (!manifest.includes("com.google.android.gms.ads.APPLICATION_ID")) {
  manifest = manifest.replace("</application>",
    '        <meta-data\n' +
    '            android:name="com.google.android.gms.ads.APPLICATION_ID"\n' +
    '            android:value="' + ADMOB_APP_ID + '" />\n' +
    '    </application>');
}
write("app/src/main/AndroidManifest.xml", manifest);
done.push("portrait", "vibrate", "billing-permission", "admob-app-id");

// 2) version: name from package.json, code from the build number (always increasing)
const code = parseInt(process.env.VERSION_CODE || "1", 10);
let app = read("app/build.gradle");
app = app.replace(/versionCode \d+/, "versionCode " + code).replace(/versionName "[^"]*"/, 'versionName "' + pkg.version + '"');
done.push("version " + pkg.version + " (" + code + ")");

// 3) STABLE debug signing — a committed debug keystore so every build has the same signature.
//    Without this, each APK uses a fresh randomly-generated debug keystore and Android refuses to
//    "update" the existing app (signatures don't match); the user has to uninstall then reinstall.
const stableDebug = path.join(root, "android-signing/debug.keystore");
const releaseKs = process.env.KEYSTORE_FILE;
if (!app.includes("signingConfigs")) {
  const releaseBlock = (releaseKs && fs.existsSync(releaseKs)) ? `
        release {
            // only set when the env var exists (the debug build step runs without it)
            if (System.getenv("KEYSTORE_FILE")) { storeFile file(System.getenv("KEYSTORE_FILE")) }
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS") ?: "upload"
            keyPassword System.getenv("KEY_PASSWORD") ?: System.getenv("KEYSTORE_PASSWORD")
        }` : "";
  // relative path from android/app/build.gradle up to android-signing/debug.keystore (works on any build machine)
  const debugBlock = fs.existsSync(stableDebug) ? `
        debug {
            storeFile file("$rootDir/../android-signing/debug.keystore")
            storePassword "papep123"
            keyAlias "paperpanic-debug"
            keyPassword "papep123"
        }` : "";
  if (releaseBlock || debugBlock) {
    app = app.replace("    buildTypes {", `    signingConfigs {${debugBlock}${releaseBlock}
    }
    buildTypes {`);
    if (releaseBlock) {
      app = app.replace("            minifyEnabled false", "            minifyEnabled false\n            signingConfig signingConfigs.release");
      done.push("release signing");
    }
    if (debugBlock) done.push("stable debug signing");
  }
}
// 4) full screen: hide the status bar and navigation bar (swipe from the edge shows them briefly)
if (!app.includes('androidx.core:core:')) {
  app = app.replace('implementation "androidx.appcompat:appcompat:$androidxAppCompatVersion"',
    'implementation "androidx.appcompat:appcompat:$androidxAppCompatVersion"\n    implementation "androidx.core:core:$androidxCoreVersion"');
}
// 5) Android target SDK — Google Play requires targetSdk 35 for new apps (Aug 2025) and 36 (Aug 2026).
// We bump the generated project to API 36 so the AAB is accepted year-round.
app = app.replace(/compileSdk\s+\d+/, "compileSdk 36")
         .replace(/compileSdkVersion\s+\d+/, "compileSdk 36")
         .replace(/targetSdkVersion\s+\d+/, "targetSdkVersion 36")
         .replace(/targetSdk\s+\d+/, "targetSdk 36");
done.push("targetSdk 36");
write("app/build.gradle", app);

// Also bump the project-level variables that Capacitor's gradle template reads from variables.gradle
try{
  const varsPath = A("variables.gradle");
  if(fs.existsSync(varsPath)){
    let v = fs.readFileSync(varsPath, "utf8");
    v = v.replace(/compileSdkVersion\s*=\s*\d+/, "compileSdkVersion = 36")
         .replace(/targetSdkVersion\s*=\s*\d+/, "targetSdkVersion = 36");
    fs.writeFileSync(varsPath, v);
    done.push("variables.gradle sdk 36");
  }
}catch(e){}

const cap = JSON.parse(fs.readFileSync(path.join(root, "capacitor.config.json"), "utf8"));
const pkgPath = cap.appId.split(".").join("/");
const activity = A("app/src/main/java/" + pkgPath + "/MainActivity.java");
fs.writeFileSync(activity, `package ${cap.appId};

import android.os.Bundle;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }
}
`);
done.push("full screen");
console.log("Android project configured: " + done.join(", "));

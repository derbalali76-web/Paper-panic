const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const locales=html.slice(html.indexOf('var RESULT_KEYS=['),html.indexOf('function paintAttackTower('));
const rewards=html.slice(html.indexOf('function roundRewardBonus('),html.indexOf('function finalizeGameOver('));
const languages=html.match(/var LANGS\s*=\s*(\[[\s\S]*?\]);/)[0];
let tests=0;
const noop=()=>{};
function setup(mode='classic'){
  let saves=0;
  const g={mode,MODE_CLASSIC:'classic',MODE_ATTACK:'cakeattack',MODE_HENGUARD:'henguard',
    lang:'en',score:600,coins:100,coinsThisRun:4,elapsed:90,dirt:20,currentStage:0,escaped:0,
    roundState:{id:1,settled:false,bestBefore:1000},
    stats:{kills:{ant:45},maxCombo:10},atk:{eaten:70,timeLeft:200,timeMax:420},
    cake:{hp:30},clamp:(x,a,b)=>Math.max(a,Math.min(b,x)),
    fmtScore:String,atkFmt:s=>String(Math.ceil(s)),t:k=>k,tt:k=>k,
    saveProgress:()=>{saves++;},checkAchievements:()=>{g.coins+=20;return[{reward:20}];}};
  vm.createContext(g);vm.runInContext(languages+locales+rewards,g);
  return {g,saves:()=>saves};
}
function check(name,fn){fn();tests++;console.log('PASS',name);}
check('Every new result and tower string exists in all 11 real app languages',()=>{
  const {g}=setup();assert.equal(g.LANGS.length,11);
  const keys=Object.keys(g.RESULT_I18N.en);
  assert(keys.length>=38);
  for(const l of g.LANGS) for(const k of keys) assert(g.RESULT_I18N[l.code][k],`${l.code}.${k}`);
});
check('Partial cake progress and faster victories receive proportionate bonuses',()=>{
  const {g}=setup('cakeattack');
  const info={mode:'cakeattack',won:false,progress:0,remaining:0,timeMax:420,stars:0};
  assert.equal(g.roundRewardBonus(info),0);
  info.progress=24;const low=g.roundRewardBonus(info);
  info.progress=72;assert(g.roundRewardBonus(info)>low);
  info.won=true;info.progress=100;info.remaining=30;const slow=g.roundRewardBonus(info);
  info.remaining=300;assert(g.roundRewardBonus(info)>slow);
});
check('Classic bonus responds to kills/combos, not instant zero-score retries',()=>{
  const {g}=setup();
  const info={mode:'classic',kills:0,combo:0,seconds:0,clean:100};
  assert.equal(g.roundRewardBonus(info),0);
  info.kills=45;info.combo=10;assert(g.roundRewardBonus(info)>=5);
});
check('Settlement pays base, performance and achievements exactly once',()=>{
  const {g,saves}=setup();const r=g.settleRound(false,0);
  assert.equal(r.base,9);assert.equal(r.bonus,9);assert.equal(r.reward,18);
  assert.equal(r.achievementCoins,20);assert.equal(g.coins,138);
  g.settleRound(false,0);assert.equal(g.coins,138);assert.equal(saves(),1);
});
check('Partial attack losses earn a visible progress reward',()=>{
  const {g}=setup('cakeattack');g.coinsThisRun=0;g.score=70;
  g.checkAchievements=()=>[];g.settleRound(false,0);
  assert.equal(g.roundState.reward,8);
  const card=g.roundCardForRun('loss','<button id="retry">Retry</button>',0);
  assert(card.includes('assets/round-cake.webp'));
  assert(card.includes('<figcaption class="round-caption">'));
  assert(!card.includes('<figcaption class="sr-only">'));
  assert(card.includes('Reward +8'));
  assert(card.includes('clock ran out'));
  assert(card.includes('Next target: eat 80%'));
});
check('Classic loss uses a chewed book and a concrete higher score target',()=>{
  const {g}=setup();g.settleRound(false,0);
  const card=g.roundCardForRun('loss','',0);
  assert(card.includes('assets/round-book.webp'));
  assert(card.includes('took it literally'));
  assert(card.includes('1001'));
  assert(!card.includes('GAMEOVER_HAND_SVG'));
});
check('Won stages and continue cards share the new renderer without premature payout',()=>{
  const {g}=setup('henguard');
  const before=g.coins;
  const preview=g.roundCardForRun('continue','<button id="btnContinueAd">Continue</button>',0);
  assert(preview.includes('btnContinueAd'));assert.equal(g.coins,before);
  g.currentStage=3;g.settleRound(true,3);
  const card=g.roundCardForRun('win','<button id="btnNext">Next</button>',3);
  assert(card.includes('★★★'));assert(card.includes('page 3'));
});
check('Result renderer escapes dynamic text but preserves supplied action markup',()=>{
  const {g}=setup();
  const card=g.buildRoundCard({headline:'<img onerror="bad">',metrics:[],actions:'<button id="safe">OK</button>'});
  assert(!card.includes('<img onerror'));assert(card.includes('&lt;img'));
  assert(card.includes('<button id="safe">'));
});
check('Both offline result photos are bundled identically for browser and Android',()=>{
  for(const kind of ['cake','book']){
    const file=`assets/round-${kind}.webp`;
    const bytes=fs.readFileSync(path.join(root,file));
    assert(bytes.length>1000 && bytes.length<150000);
    assert(bytes.equals(fs.readFileSync(path.join(root,'www',file))));
  }
});
console.log(`All ${tests} round-result checks passed.`);

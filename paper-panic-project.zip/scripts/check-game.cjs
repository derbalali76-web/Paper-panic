// Run with: node scripts/check-game.cjs
// Tests the actual game's attack-mode functions without a native AdMob session.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const mobile = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
assert.equal(html, mobile, 'Browser and Android web sources must match');
for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
  if (match[1].trim()) new vm.Script(match[1]);
}
assert(!html.includes('MODE_NIGHT'), 'Removed desk-lamp mode must not be executable');
assert(!html.includes('btnHowto'), 'How-to card and listener must be removed');
assert(!html.includes('function showHowto'));
const source = html.slice(html.indexOf('var ATK_CFG='), html.indexOf('// Reuse the game'));
const spawnSource = html.slice(html.indexOf('function spawnAt('), html.indexOf('function spawnSpiderlings('));
const noop = () => {};
const classes = { add: noop, remove: noop, toggle: noop };
let checks = 0;
function game(height = 600) {
  const rewards = [];
  const ctx = {
    W: 360, H: height, elapsed: 0, state: 'playing', mode: 'cakeattack',
    MODE_ATTACK: 'cakeattack', MODE_HENGUARD: 'henguard', MODE_CLASSIC: 'classic',
    bugs: [], cake: null, chickens: [], chicken: null, upgrades: {}, best: 0,
    currentStage: 0, level: 1, coinsThisRun: 0, score: 0,
    coffeeTimer: 0, powerupTimer: 0, wormTimer: 0, windTimer: 0, spiderTimer: 0, fanTimer: 0,
    muzzleFlashes: [], usedContinueThisRun: false,
    TYPES: {
      ant: { hp: 1, r: 10, speed: 60, color: '#333' },
      beetle: { hp: 3, r: 15, speed: 50, color: '#333' },
      ladybug: { hp: 2, r: 12, speed: 50, color: '#333' },
    },
    field: { getBoundingClientRect: () => ({ top: 0 }) },
    document: {
      getElementById: id => id === 'atkBar'
        ? { getBoundingClientRect: () => ({ top: height - 80 }) }
        : { classList: classes, textContent: '' },
      querySelectorAll: () => [], querySelector: () => null,
    },
    newCake: hp => ({ x: 0, y: 0, hp, bites: [] }),
    cakeRadius: () => 46,
    worldMod: () => ({ speed: 1 }), phaseHasCake: () => false,
    rand: (lo, hi) => (lo + hi) / 2,
    clamp: (n, lo, hi) => Math.max(lo, Math.min(hi, n)),
    t: x => x, toast: noop, popup: noop, burst: noop, stampSplat: noop,
    sfxClick: noop, sfxPowerup: noop, sfxSpray: noop, sfxGun: noop,
    shakePaper: noop, updateScore: noop, gameOver: noop, checkStageWin: noop,
    finalizeGameOver: noop, showRewardedAd: (_label, cb) => rewards.push(cb),
  };
  vm.createContext(ctx);
  vm.runInContext(spawnSource + '\n' + source, ctx);
  ctx.atkInit();
  return { ctx, rewards };
}
function check(name, test) { test(); checks++; console.log('PASS', name); }
check('Both HTML copies match and inline JavaScript parses', () => {});
check('Fast, armored, and decoy ants launch visibly above controls', () => {
  const { ctx: g } = game();
  for (const kind of ['fast', 'armor', 'decoy']) {
    g.atkSelect(kind); g.atkTap(180, 350);
    assert.equal(g.bugs.at(-1).atkKind, kind);
    assert(g.bugs.at(-1).y < 520);
    assert(g.bugs.at(-1).y > g.cake.y);
  }
  assert.equal(g.bugs.length, 3);
});
check('Cooldown prevents repeated launches; launching resumes when ready', () => {
  const { ctx: g } = game();
  g.atkTap(180, 350); g.atkTap(180, 350);
  assert.equal(g.bugs.length, 1);
  g.elapsed = 1.1; g.atkTap(180, 350);
  assert.equal(g.bugs.length, 2);
});
check('Paused and finished rounds cannot launch ants', () => {
  const { ctx: g } = game();
  g.state = 'paused'; g.atkTap(180, 350);
  g.state = 'playing'; g.atk.won = true; g.atkTap(180, 350);
  assert.equal(g.bugs.length, 0);
});
check('Every tower is behind the cake and inside the paper at all difficulties', () => {
  for (const height of [400, 600, 850]) {
    const { ctx: g } = game(height);
    for (const difficulty of [1, 2, 3]) {
      g.atk.diff = difficulty; g.atkTurrets();
      for (const turret of g.atk.turrets) {
        assert(turret.y + 25 < g.cake.y - 46);
        assert(turret.y + 25 < g.cake.y - 62, 'Weapon must not overlap the cake health bar');
        assert(turret.y - 25 >= 0);
        assert(turret.x - 25 >= 0 && turret.x + 25 <= g.W);
      }
    }
  }
});
check('Giant only spawns after reward; towers kill it within two seconds', () => {
  for (const height of [400, 600, 850]) {
    const { ctx: g, rewards } = game(height);
    g.atkGiant();
    assert.equal(g.bugs.length, 0);
    g.state = 'paused'; rewards.shift()();
    assert.equal(g.bugs[0].atkKind, 'giant');
    assert.equal(g.bugs[0].type, 'ant');
    assert.equal(g.atk.giants, 1);
    g.state = 'playing';
    for (let step = 0; step < 40; step++) {
      g.elapsed += 0.05; g.updateAttack(0.05, 0.05);
    }
    assert(!g.bugs.some(b => b.atkKind === 'giant'));
    assert.equal(g.cake.hp, 100);
    // Boosted range/cadence must not persist after the giant dies.
    g.atkTap(180, 350);
    g.bugs.at(-1).y = g.cake.y + 70;
    g.atk.turrets[0].cd = 0;
    g.updateAttack(0.05, 0.05);
    assert(g.atk.turrets[0].cd >= 1.2);
  }
});
check('A decoy cannot divert anti-giant targeting; out-of-range decoys are ignored', () => {
  const { ctx: g, rewards } = game();
  g.atkSelect('decoy'); g.atkTap(180, 350);
  assert.equal(g.atkTarget(g.atk.turrets[0], 10), null);
  g.atkGiant(); rewards.shift()();
  assert.equal(g.atkTarget(g.atk.turrets[0], 1000).atkKind, 'giant');
});
check('An old rewarded callback cannot spawn a giant in a new round', () => {
  const { ctx: g, rewards } = game();
  g.atkGiant(); g.atkInit(); rewards.shift()();
  assert.equal(g.bugs.length, 0);
  assert.equal(g.atk.giants, 0);
});
check('Giant cooldown and three-reward limit are enforced', () => {
  const { ctx: g, rewards } = game();
  for (let i = 0; i < 3; i++) {
    g.atkGiant(); rewards.shift()(); g.elapsed += 26;
  }
  g.atkGiant();
  assert.equal(rewards.length, 0);
  assert.equal(g.atk.giants, 3);
});
console.log(`All ${checks} regression checks passed.`);

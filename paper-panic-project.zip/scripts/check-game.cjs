// Run with: node scripts/check-game.cjs
// Tests the actual game's attack-mode functions without a native AdMob session.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const mobile = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
assert.equal(html, mobile, 'Browser and Android web sources must match');
assert(/<meta\s+charset=["']utf-8["']/i.test(html.slice(0, 1024)), 'Declare UTF-8 early so phone/leaderboard translations render correctly');
for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
  if (match[1].trim()) new vm.Script(match[1]);
}
assert(!html.includes('MODE_NIGHT'), 'Removed desk-lamp mode must not be executable');
assert(!html.includes('btnHowto'), 'How-to card and listener must be removed');
assert(!html.includes('function showHowto'));
const source = html.slice(html.indexOf('var ATK_CFG='), html.indexOf('// Reuse the game'));
const spawnSource = html.slice(html.indexOf('function spawnAt('), html.indexOf('function spawnSpiderlings('));
const noop = () => {};
const classes = { add: noop, remove: noop, toggle: noop };
let checks = 0;
function game(height = 600) {
  const rewards = [];
  const ctx = {
    W: 360, H: height, elapsed: 0, state: 'playing', mode: 'cakeattack',
    MODE_ATTACK: 'cakeattack', MODE_HENGUARD: 'henguard', MODE_CLASSIC: 'classic',
    bugs: [], cake: null, chickens: [], chicken: null, upgrades: {}, best: 0,
    currentStage: 0, level: 1, coinsThisRun: 0, score: 0,
    coffeeTimer: 0, powerupTimer: 0, wormTimer: 0, windTimer: 0, spiderTimer: 0, fanTimer: 0,
    muzzleFlashes: [], usedContinueThisRun: false,
    TYPES: {
      ant: { hp: 1, r: 10, speed: 60, color: '#333' },
      beetle: { hp: 3, r: 15, speed: 50, color: '#333' },
      ladybug: { hp: 2, r: 12, speed: 50, color: '#333' },
    },
    field: { getBoundingClientRect: () => ({ top: 0 }) },
    document: {
      getElementById: id => id === 'atkBar'
        ? { getBoundingClientRect: () => ({ top: height - 80 }) }
        : { classList: classes, textContent: '' },
      querySelectorAll: () => [], querySelector: () => null,
    },
    newCake: hp => ({ x: 0, y: 0, hp, bites: [] }),
    cakeRadius: () => 46,
    worldMod: () => ({ speed: 1 }), phaseHasCake: () => false,
    rand: (lo, hi) => (lo + hi) / 2,
    clamp: (n, lo, hi) => Math.max(lo, Math.min(hi, n)),
    t: x => x, toast: noop, popup: noop, burst: noop, stampSplat: noop,
    sfxClick: noop, sfxPowerup: noop, sfxSpray: noop, sfxGun: noop,
    shakePaper: noop, updateScore: noop, gameOver: noop, checkStageWin: noop,
    finalizeGameOver: noop, showRewardedAd: (_label, cb) => rewards.push(cb),
  };
  vm.createContext(ctx);
  vm.runInContext(spawnSource + '\n' + source, ctx);
  ctx.atkInit();
  return { ctx, rewards };
}
function check(name, test) { test(); checks++; console.log('PASS', name); }
check('Both HTML copies match and inline JavaScript parses', () => {});
check('Fast, armored, and decoy ants launch visibly above controls', () => {
  const { ctx: g } = game();
  for (const kind of ['fast', 'armor', 'decoy']) {
    g.atkSelect(kind); g.atkTap(180, 350);
    assert.equal(g.bugs.at(-1).atkKind, kind);
    assert(g.bugs.at(-1).y < 520);
    assert(g.bugs.at(-1).y > g.cake.y);
  }
  assert.equal(g.bugs.length, 3);
});
check('Fast ants have no interval, while armored ants keep their cooldown', () => {
  const { ctx: g } = game();
  for (let i = 0; i < 100; i++) g.atkTap(180, 350);
  assert.equal(g.bugs.length, 100);
  assert.equal(g.atk.ready.fast, g.elapsed);
  g.bugs = []; g.atkSelect('armor');
  g.atkTap(180, 350); g.atkTap(180, 350);
  assert.equal(g.bugs.length, 1);
  g.elapsed = 90; g.atkTap(180, 350);
  assert.equal(g.bugs.length, 2);
});
check('Paused and finished rounds cannot launch ants', () => {
  const { ctx: g } = game();
  g.state = 'paused'; g.atkTap(180, 350);
  g.state = 'playing'; g.atk.won = true; g.atkTap(180, 350);
  assert.equal(g.bugs.length, 0);
});
check('Every tower is behind the cake and inside the paper at all difficulties', () => {
  for (const height of [400, 600, 850]) {
    const { ctx: g } = game(height);
    for (const difficulty of [1, 2, 3]) {
      g.atk.diff = difficulty; g.atkTurrets();
      for (const turret of g.atk.turrets) {
        assert(turret.y + 25 < g.cake.y - 46);
        assert(turret.y + 25 < g.cake.y - 62, 'Weapon must not overlap the cake health bar');
        assert(turret.y - 25 >= 0);
        assert(turret.x - 25 >= 0 && turret.x + 25 <= g.W);
      }
    }
  }
});
check('Rewarded giant survives until it personally eats 10 HP, then can be killed', () => {
  for (const height of [400, 600, 850]) {
    const { ctx: g, rewards } = game(height);
    g.atkGiant();
    assert.equal(g.bugs.length, 0);
    g.state = 'paused'; rewards.shift()();
    assert.equal(g.bugs[0].atkKind, 'giant');
    assert.equal(g.bugs[0].type, 'ant');
    assert.equal(g.atk.giants, 1);
    g.state = 'playing';
    const giant = g.bugs[0];
    for (let step = 0; step < 40; step++) {
      g.elapsed += 0.05; g.updateAttack(0.05, 0.05);
    }
    assert.equal(giant.hp, 70);
    assert(g.bugs.includes(giant));
    g.atkEatCake({ atkKind: 'fast' }, 5);
    assert.equal(giant.giantEaten, 0, 'Other ants cannot unlock the giant');
    g.atkEatCake(giant, 9.5);
    g.atkHurt(giant, 10000);
    assert.equal(giant.hp, 70);
    g.atkEatCake(giant, 0.5);
    assert.equal(giant.giantEaten, 10);
    assert.equal(g.atkGiantProtected(giant), false);
    for (let step = 0; step < 160; step++) {
      g.elapsed += 0.05; g.updateAttack(0.05, 0.05);
    }
    assert(!g.bugs.some(b => b.atkKind === 'giant'));
    assert.equal(g.cake.hp, 85);
    // Boosted range/cadence must not persist after the giant dies.
    g.atkTap(180, 350);
    g.bugs.at(-1).y = g.cake.y + 70;
    const active = g.atkActiveTurrets()[0];
    active.kind = 'gun'; active.cd = 0;
    g.updateAttack(0.05, 0.05);
    assert(active.cd >= 1.2);
  }
});
check('A decoy cannot divert anti-giant targeting; out-of-range decoys are ignored', () => {
  const { ctx: g, rewards } = game();
  g.atkSelect('decoy'); g.atkTap(180, 350);
  assert.equal(g.atkTarget(g.atk.turrets[0], 10), null);
  g.atkGiant(); rewards.shift()();
  assert.equal(g.atkTarget(g.atk.turrets[0], 1000).atkKind, 'decoy');
  g.atkEatCake(g.bugs.at(-1), 10);
  assert.equal(g.atkTarget(g.atk.turrets[0], 1000).atkKind, 'giant');
});
check('Tower activation grows only with the number of ants; residual attacks stop', () => {
  const { ctx: g } = game();
  g.atk.diff = 3; g.atkTurrets();
  for (const [ants, towers] of [[0,0],[1,1],[5,1],[6,2],[11,2],[12,3],[17,3],[18,4],[24,5]]) {
    g.bugs = Array.from({ length: ants }, () => ({
      type: 'ant', atkKind: 'fast', hp: 10000, x: 180, y: g.cake.y + 50,
    }));
    assert.equal(g.atkActiveTurrets().length, towers);
  }
  g.atk.turrets.forEach(t => { t.cd = 0; });
  g.updateAttack(0.05, 0.05);
  assert(g.atk.clouds.length && g.atk.jets.length);
  g.bugs = [g.bugs[0]];
  g.updateAttack(0.05, 0.05);
  const active = g.atkActiveTurrets();
  assert.equal(active.length, 1);
  for (const effect of [...g.atk.shots, ...g.atk.clouds, ...g.atk.jets]) {
    assert(active.includes(effect.tu), 'Sleeping towers must not deal residual damage');
  }
});
check('An old rewarded callback cannot spawn a giant in a new round', () => {
  const { ctx: g, rewards } = game();
  g.atkGiant(); g.atkInit(); rewards.shift()();
  assert.equal(g.bugs.length, 0);
  assert.equal(g.atk.giants, 0);
});
check('Giant cooldown and three-reward limit are enforced', () => {
  const { ctx: g, rewards } = game();
  for (let i = 0; i < 3; i++) {
    g.atkGiant(); rewards.shift()(); g.elapsed += 26;
  }
  g.atkGiant();
  assert.equal(rewards.length, 0);
  assert.equal(g.atk.giants, 3);
});
const localeSource = html.slice(html.indexOf('var LANGS ='), html.indexOf('// full screen in browsers')) +
  html.slice(html.indexOf('// Every string in the leaderboard'), html.indexOf('// ---------- coins & permanent upgrades'));
function localeGame(locales, initial = {}) {
  const store = new Map(Object.entries(initial));
  const attrs = {};
  const ctx = {
    navigator: { languages: locales },
    localStorage: { getItem: k => store.get(k) ?? null, setItem: (k,v) => store.set(k,v) },
    document: { documentElement: { setAttribute: (k,v) => { attrs[k] = v; } } },
  };
  vm.createContext(ctx); vm.runInContext(localeSource, ctx);
  return { ctx, store, attrs };
}
check('All 11 languages have every leaderboard and guest/join-card string', () => {
  const { ctx: g } = localeGame(['en-US']);
  assert.equal(g.LANGS.length, 11);
  for (const locale of g.LANGS) {
    if (g.LB_LOCALES[locale.code]) assert.equal(g.LB_LOCALES[locale.code].length, g.LB_KEYS.length);
    for (const key of g.LB_KEYS) {
      assert.equal(typeof g.I18N[locale.code][key], 'string', `${locale.code}: ${key}`);
      assert(g.I18N[locale.code][key].trim());
      if (locale.code !== 'ar') assert(!/[\u0600-\u06ff]/.test(g.I18N[locale.code][key]), `${locale.code}: Arabic fallback in ${key}`);
    }
  }
});
check('Phone language handles regional codes, supported preferences, fallback and RTL', () => {
  for (const [locales, expected] of [
    [['fr-FR'],'fr'], [['es-MX'],'es'], [['pt-BR'],'pt'], [['zh-Hant-TW'],'zh'],
    [['ar-DZ'],'ar'], [['ja-JP','de-DE'],'de'], [['ja-JP'],'en'], [[], 'en'],
  ]) {
    const { ctx: g, attrs, store } = localeGame(locales, { pp_lang: 'ar' });
    assert.equal(g.lang, expected);
    assert.equal(attrs.lang, expected);
    assert.equal(attrs.dir, expected === 'ar' ? 'rtl' : 'ltr');
    assert.notEqual(store.get('pp_lang_mode'), 'manual', 'Auto-detection must not become a manual preference');
  }
});
check('An explicit language choice persists and overrides automatic detection', () => {
  const { ctx: g, store } = localeGame(['fr-FR']);
  g.setLang('de');
  assert.equal(store.get('pp_lang_mode'), 'manual');
  const next = localeGame(['fr-FR'], Object.fromEntries(store));
  assert.equal(next.ctx.lang, 'de');
});
console.log(`All ${checks} regression checks passed.`);

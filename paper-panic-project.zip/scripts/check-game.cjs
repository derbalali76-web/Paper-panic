// Run with: node scripts/check-game.cjs
// Tests the actual game's attack-mode functions without a native AdMob session.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const mobile = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
assert.equal(html, mobile, 'Browser and Android web sources must match');
assert(/<meta\s+charset=["']utf-8["']/i.test(html.slice(0, 1024)), 'Declare UTF-8 early so phone/leaderboard translations render correctly');
for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
  if (match[1].trim()) new vm.Script(match[1]);
}
assert(!html.includes('MODE_NIGHT'), 'Removed desk-lamp mode must not be executable');
assert(!html.includes('btnHowto'), 'How-to card and listener must be removed');
assert(!html.includes('function showHowto'));
const source = html.slice(html.indexOf('var ATK_CFG='), html.indexOf('// Reuse the game'));
const spawnSource = html.slice(html.indexOf('function spawnAt('), html.indexOf('function spawnSpiderlings('));
const noop = () => {};
const classes = { add: noop, remove: noop, toggle: noop };
let checks = 0;
function game(height = 600) {
  const rewards = [];
  const ctx = {
    W: 360, H: height, elapsed: 0, state: 'playing', mode: 'cakeattack',
    MODE_ATTACK: 'cakeattack', MODE_HENGUARD: 'henguard', MODE_CLASSIC: 'classic',
    bugs: [], cake: null, chickens: [], chicken: null, upgrades: {}, best: 0,
    currentStage: 0, level: 1, coinsThisRun: 0, score: 0,
    coffeeTimer: 0, powerupTimer: 0, wormTimer: 0, windTimer: 0, spiderTimer: 0, fanTimer: 0,
    muzzleFlashes: [], usedContinueThisRun: false,
    TYPES: {
      ant: { hp: 1, r: 10, speed: 60, color: '#333' },
      beetle: { hp: 3, r: 15, speed: 50, color: '#333' },
      ladybug: { hp: 2, r: 12, speed: 50, color: '#333' },
    },
    field: { getBoundingClientRect: () => ({ top: 0 }) },
    document: {
      getElementById: id => id === 'atkBar'
        ? { getBoundingClientRect: () => ({ top: height - 80 }) }
        : { classList: classes, textContent: '' },
      querySelectorAll: () => [], querySelector: () => null,
    },
    newCake: hp => ({ x: 0, y: 0, hp, bites: [] }),
    cakeRadius: () => 46,
    worldMod: () => ({ speed: 1 }), phaseHasCake: () => false,
    rand: (lo, hi) => (lo + hi) / 2,
    clamp: (n, lo, hi) => Math.max(lo, Math.min(hi, n)),
    t: x => x, toast: noop, popup: noop, burst: noop, stampSplat: noop,
    sfxClick: noop, sfxPowerup: noop, sfxSpray: noop, sfxGun: noop,
    shakePaper: noop, updateScore: noop, gameOver: noop, checkStageWin: noop,
    finalizeGameOver: noop, showRewardedAd: (_label, cb) => rewards.push(cb),
  };
  vm.createContext(ctx);
  vm.runInContext(spawnSource + '\n' + source, ctx);
  ctx.atkInit();
  return { ctx, rewards };
}
function check(name, test) { test(); checks++; console.log('PASS', name); }
check('Both HTML copies match and inline JavaScript parses', () => {});
check('Fast, armored, and decoy ants launch visibly above controls', () => {
  const { ctx: g } = game();
  for (const kind of ['fast', 'armor', 'decoy']) {
    g.atkSelect(kind); g.atkTap(180, 350);
    assert.equal(g.bugs.at(-1).atkKind, kind);
    assert(g.bugs.at(-1).y < 520);
    assert(g.bugs.at(-1).y > g.cake.y);
  }
  assert.equal(g.bugs.length, 3);
});
check('Fast ants have no interval but never exceed 20 active; slots reopen after deaths', () => {
  const { ctx: g } = game();
  for (let i = 0; i < 100; i++) g.atkTap(180, 350);
  assert.equal(g.bugs.length, 20);
  assert(new Set(g.bugs.map(b=>b.x)).size>=5,'Rapid launches should form lanes, not one overlapping pile');
  assert.equal(g.atkLaunch('fast',180,350,0), null);
  g.bugs.pop(); g.atkTap(180,350);
  assert.equal(g.bugs.length,20);
  assert.equal(g.atk.ready.fast, g.elapsed);
  g.bugs = []; g.atkSelect('armor');
  g.atkTap(180, 350); g.atkTap(180, 350);
  assert.equal(g.bugs.length, 1);
  g.elapsed = 90; g.atkTap(180, 350);
  assert.equal(g.bugs.length, 2);
});
check('Paused and finished rounds cannot launch ants', () => {
  const { ctx: g } = game();
  g.state = 'paused'; g.atkTap(180, 350);
  g.state = 'playing'; g.atk.won = true; g.atkTap(180, 350);
  assert.equal(g.bugs.length, 0);
});
check('Every tower is behind the cake and inside the paper at all difficulties', () => {
  for (const height of [400, 600, 850]) {
    const { ctx: g } = game(height);
    for (const difficulty of [1, 2, 3]) {
      g.atk.diff = difficulty; g.atkTurrets();
      for (const turret of g.atk.turrets) {
        assert(turret.y + 25 < g.cake.y - 46);
        assert(turret.y + 25 < g.cake.y - 62, 'Weapon must not overlap the cake health bar');
        assert(turret.y - 25 >= 0);
        assert(turret.x - 25 >= 0 && turret.x + 25 <= g.W);
      }
    }
  }
});
check('Rewarded giant survives until it personally eats 10 HP, then can be killed', () => {
  for (const height of [400, 600, 850]) {
    const { ctx: g, rewards } = game(height);
    g.atkGiant();
    assert.equal(g.bugs.length, 0);
    g.state = 'paused'; rewards.shift()();
    assert.equal(g.bugs[0].atkKind, 'giant');
    assert.equal(g.bugs[0].type, 'ant');
    assert.equal(g.atk.giants, 1);
    g.state = 'playing';
    const giant = g.bugs[0];
    for (let step = 0; step < 40; step++) {
      g.elapsed += 0.05; g.updateAttack(0.05, 0.05);
    }
    assert.equal(giant.hp, 80);
    assert(g.bugs.includes(giant));
    g.atkEatCake({ atkKind: 'fast' }, 5);
    assert.equal(giant.giantEaten, 0, 'Other ants cannot unlock the giant');
    g.atkEatCake(giant, 9.5);
    g.atkHurt(giant, 10000);
    assert.equal(giant.hp, 80);
    g.atkEatCake(giant, 0.5);
    assert.equal(giant.giantEaten, 10);
    assert.equal(g.atkGiantProtected(giant), false);
    giant.x = g.cake.x; giant.y = g.cake.y + 30;
    for (let step = 0; step < 600; step++) {
      g.elapsed += 0.05; g.updateAttack(0.05, 0.05);
    }
    assert(!g.bugs.some(b => b.atkKind === 'giant'));
    assert.equal(giant.giantHits, 4); // v60: exposed giant takes 22 per hit (80 HP)
    assert.equal(g.cake.hp, 85);
    // Boosted range/cadence must not persist after the giant dies.
    g.atkTap(180, 350);
    g.bugs.at(-1).y = g.cake.y + 25;
    g.bugs.at(-1).bornAt = g.elapsed - 2;
    const active = g.atkActiveTurrets()[0];
    active.kind = 'gun'; active.cd = 0;
    g.updateAttack(0.05, 0.05);
    assert(active.cd >= 1.2);
  }
});
check('A decoy cannot divert anti-giant targeting; out-of-range decoys are ignored', () => {
  const { ctx: g, rewards } = game();
  g.atkSelect('decoy'); g.atkTap(180, 350);
  assert.equal(g.atkTarget(g.atk.turrets[0], 10), null);
  g.atkGiant(); rewards.shift()();
  g.elapsed = 2;
  const decoy = g.bugs.find(x => x.decoy);
  const own = g.atkDecoyOwner(decoy), other = g.atk.turrets.find(x => x !== own);
  assert.equal(g.atkTarget(own, 1000).atkKind, 'decoy');
  assert.equal(g.atkTarget(other, 1000)?.decoy || false, false); // only one tower is distracted
  g.atkEatCake(g.bugs.at(-1), 10);
  assert.equal(g.atkTarget(own, 1000).atkKind, 'giant');
});
check('Tower activation grows only with the number of ants; residual attacks stop', () => {
  const { ctx: g } = game();
  g.atk.diff = 3; g.atkTurrets();
  for (const [ants, towers] of [[0,0],[1,1],[9,1],[10,2],[19,2],[20,3],[29,3],[30,3],[40,3]]) {
    g.bugs = Array.from({ length: ants }, () => ({
      type: 'ant', atkKind: 'fast', hp: 10000, x: 180, y: g.cake.y + 50,
    }));
    assert.equal(g.atkActiveTurrets().length, towers);
  }
  g.atk.turrets.forEach(t => { t.cd = 0; });
  g.atk.shots=[{tu:g.atk.turrets[0],t:100,tg:g.bugs[0]}];
  g.atk.clouds=[{tu:g.atk.turrets[1],x:0,y:0,r:1,age:0,life:1}];
  g.atk.jets=[{tu:g.atk.turrets[2],x:0,y:0,ang:0,len:1,age:0,life:1}];
  g.updateAttack(0.05, 0.05);
  assert(g.atk.clouds.length && g.atk.jets.length);
  g.bugs = [g.bugs[0]];
  g.updateAttack(0.05, 0.05);
  const active = g.atkActiveTurrets();
  assert.equal(active.length, 1);
  for (const effect of [...g.atk.shots, ...g.atk.clouds, ...g.atk.jets]) {
    assert(active.includes(effect.tu), 'Sleeping towers must not deal residual damage');
  }
});
check('Fast ant movement uses its configured speed and cannot overshoot the cake', () => {
  const { ctx: g } = game();
  g.atkTap(180, 350);
  const ant = g.bugs[0];
  ant.x = 180; ant.y = 500; ant.tx = 180; ant.ty = 200; ant.slowMul = 1;
  g.atkMoveBug(ant, 1);
  assert.equal(ant.y, 435);
  g.atkMoveBug(ant, 10);
  assert.equal(ant.y, 200);
  assert.equal(ant.hp, 3);
});
check('Arrival at the cake activates every short-range tower and latches the alarm', () => {
  const { ctx:g }=game();
  for(let i=0;i<20;i++) g.atkTap(180,350);
  const ant=g.bugs[0];
  assert.equal(g.atkActiveTurrets().length,3);
  ant.x=g.cake.x; ant.y=g.cake.y+40;
  g.atkCheckAlarm();
  assert.equal(g.atk.alert,true);
  assert.equal(g.atkActiveTurrets().length,g.atk.turrets.length);
  g.bugs=[];
  assert.equal(g.atkActiveTurrets().length,g.atk.turrets.length);
  g.atkInit();
  assert.equal(g.atk.alert,false);
});
check('Towers cannot shoot distant marching ants outside their short range', () => {
  const {ctx:g}=game(850);
  g.atkTap(180,350); g.elapsed=2;
  g.atk.turrets.forEach(t=>{t.cd=0;});
  g.updateAttack(0.05,0.05);
  assert.equal(g.atk.shots.length+g.atk.clouds.length+g.atk.jets.length,0);
});
check('Four different tower weapons remain unique at every difficulty',()=>{
  const {ctx:g}=game();
  for(const difficulty of [1,2,3]){
    g.atk.diff=difficulty;g.atkTurrets();
    assert.equal(g.atk.turrets.length,4);
    assert.equal(new Set(g.atk.turrets.map(t=>t.kind)).size,4);
    for(const k of ['gun','spray','flame','glue']) assert(g.atk.turrets.some(t=>t.kind===k));
  }
});
check('More ants increase damage, fire rate, burst size and splash, with a safe cap',()=>{
  const {ctx:g}=game();
  let previous=g.atkPowerForCount(0);
  for(const count of [4,8,12,16,20]){
    const p=g.atkPowerForCount(count);
    assert(p.fire>=previous.fire && p.damage>=previous.damage && p.radius>=previous.radius);
    previous=p;
  }
  assert.equal(g.atkPowerForCount(100).fire,g.atkPowerForCount(20).fire);
  function volley(count){
    const {ctx:h}=game();h.elapsed=3;h.atk.alert=true;
    h.bugs=Array.from({length:count},()=>({atkKind:'fast',hp:10000,x:180,y:h.cake.y+10,bornAt:0}));
    h.atk.turrets.forEach(t=>t.cd=0);h.updateAttack(0.001,0.001);
    return h;
  }
  const small=volley(4),swarm=volley(20);
  assert(swarm.atk.turrets[0].cd<small.atk.turrets[0].cd);
  assert(swarm.atk.shots.length>small.atk.shots.length);
  assert(swarm.atk.clouds[0].damage>small.atk.clouds[0].damage);
  assert(swarm.atk.jets[0].damage>small.atk.jets[0].damage);
  assert(swarm.atk.globs[0].slow<small.atk.globs[0].slow);
});
check('Honey puddles slow ordinary ants without harming or trapping a protected giant',()=>{
  const {ctx:g}=game();g.elapsed=3;g.atk.alert=true;
  g.atk.turrets.forEach(t=>t.cd=100);
  const b={atkKind:'fast',hp:30,x:180,y:g.cake.y+10,bornAt:0,spd0:65,speed:65};
  g.bugs=[b];g.atk.globs=[{tu:g.atk.turrets[3],tx:b.x,ty:b.y,r:38,age:0.4,flight:0.32,life:2.8,slow:0.4}];
  g.updateAttack(0.02,0.02);g.elapsed+=0.02;g.updateAttack(0.02,0.02);
  assert.equal(b.speed,26);assert.equal(b.hp,30);
  b.atkKind='giant';b.giantEaten=0;b.glueUntil=0;
  g.updateAttack(0.02,0.02);assert.equal(b.glueUntil,0);
});
check('Cake access is limited to eight normal attackers, not all 20 at once',()=>{
  const {ctx:g}=game();
  assert(g.atkCanJoinCake({atkKind:'fast'},7));
  assert(!g.atkCanJoinCake({atkKind:'fast'},8));
  assert(!g.atkCanJoinCake({atkKind:'armor'},20));
  assert(g.atkCanJoinCake({atkKind:'giant'},20),'Rewarded giant must retain cake access');
  const waiting={};
  g.atkQueueAt(waiting,12,46);
  assert(waiting.ty>g.cake.y+46);
  assert(Math.hypot(waiting.tx-g.cake.x,waiting.ty-g.cake.y)>46);
  assert(html.includes('mode===MODE_ATTACK?atkCanJoinCake(eb,atkN):atkN<maxAtk'));
});
check('Decoy reaches tower range and support units recharge at playable intervals',()=>{
  const {ctx:g}=game();
  g.atkSelect('decoy'); g.atkTap(180,350);
  const bait=g.bugs[0];
  assert(bait.decoy && bait.eatMul===0);
  assert(Math.hypot(bait.tx-g.atk.turrets[1].x,bait.ty-g.atk.turrets[1].y)<165);
  assert.equal(g.ATK_CFG.decoy.cd,16);
  assert.equal(g.ATK_CFG.armor.cd,24);
  assert.equal(g.ATK_CFG.armor.hp,16);
});
check('Giant needs four separated impacts after protection, even under huge damage', () => {
  const { ctx: g, rewards } = game();
  g.atkGiant(); rewards.shift()();
  const giant = g.bugs[0];
  g.atkEatCake(giant, 10);
  assert.equal(giant.eatMul, 1);
  for (let hit = 1; hit <= 4; hit++) {
    g.elapsed = hit;
    g.atkHurt(giant, 100000);
    assert.equal(giant.giantHits, hit);
    assert.equal(giant.hp, 80 - 22 * hit);
    if (hit < 4) {
      assert(g.bugs.includes(giant));
      for (let i = 0; i < 100; i++) g.atkHurt(giant, 100000);
      assert.equal(giant.giantHits, hit, 'Simultaneous bursts must count as one impact');
    }
  }
  assert(!g.bugs.includes(giant));
});
check('Slow ordinary ants can reach the cake, without crossing the field instantly', () => {
  const { ctx: g } = game(850);
  for (let i = 0; i < 8; i++) g.atkTap(70 + 30 * i, 500);
  const original = [...g.bugs];
  let reached=false;
  for (let step = 0; step < 300; step++) {
    g.elapsed += 0.05;
    g.updateAttack(0.05, 0.05);
    for (const bug of g.bugs) {
      bug.tx = g.cake.x; bug.ty = g.cake.y + 25;
      g.atkMoveBug(bug, 0.05);
      if(bug.y<g.cake.y+40) reached=true;
    }
    if(step===19) assert(g.bugs.every(b=>b.y>g.cake.y+100));
  }
  assert(reached, 'Ordinary ants must be able to reach the cake');
});
check('An old rewarded callback cannot spawn a giant in a new round', () => {
  const { ctx: g, rewards } = game();
  g.atkGiant(); g.atkInit(); rewards.shift()();
  assert.equal(g.bugs.length, 0);
  assert.equal(g.atk.giants, 0);
});
check('Giant cooldown and three-reward limit are enforced', () => {
  const { ctx: g, rewards } = game();
  for (let i = 0; i < 3; i++) {
    g.atkGiant(); rewards.shift()(); g.elapsed += 26;
  }
  g.atkGiant();
  assert.equal(rewards.length, 0);
  assert.equal(g.atk.giants, 3);
});
const localeSource = html.slice(html.indexOf('var LANGS ='), html.indexOf('// full screen in browsers')) +
  html.slice(html.indexOf('// Every string in the leaderboard'), html.indexOf('// ---------- coins & permanent upgrades'));
function localeGame(locales, initial = {}) {
  const store = new Map(Object.entries(initial));
  const attrs = {};
  const ctx = {
    navigator: { languages: locales },
    localStorage: { getItem: k => store.get(k) ?? null, setItem: (k,v) => store.set(k,v) },
    document: { documentElement: { setAttribute: (k,v) => { attrs[k] = v; } } },
  };
  vm.createContext(ctx); vm.runInContext(localeSource, ctx);
  return { ctx, store, attrs };
}
check('All 11 languages have every leaderboard and guest/join-card string', () => {
  const { ctx: g } = localeGame(['en-US']);
  assert.equal(g.LANGS.length, 11);
  for (const locale of g.LANGS) {
    if (g.LB_LOCALES[locale.code]) assert.equal(g.LB_LOCALES[locale.code].length, g.LB_KEYS.length);
    for (const key of g.LB_KEYS) {
      assert.equal(typeof g.I18N[locale.code][key], 'string', `${locale.code}: ${key}`);
      assert(g.I18N[locale.code][key].trim());
      if (locale.code !== 'ar') assert(!/[\u0600-\u06ff]/.test(g.I18N[locale.code][key]), `${locale.code}: Arabic fallback in ${key}`);
    }
  }
});
check('Phone language handles regional codes, supported preferences, fallback and RTL', () => {
  for (const [locales, expected] of [
    [['fr-FR'],'fr'], [['es-MX'],'es'], [['pt-BR'],'pt'], [['zh-Hant-TW'],'zh'],
    [['ar-DZ'],'ar'], [['ja-JP','de-DE'],'de'], [['ja-JP'],'en'], [[], 'en'],
  ]) {
    const { ctx: g, attrs, store } = localeGame(locales, { pp_lang: 'ar' });
    assert.equal(g.lang, expected);
    assert.equal(attrs.lang, expected);
    assert.equal(attrs.dir, expected === 'ar' ? 'rtl' : 'ltr');
    assert.notEqual(store.get('pp_lang_mode'), 'manual', 'Auto-detection must not become a manual preference');
  }
});
check('An explicit language choice persists and overrides automatic detection', () => {
  const { ctx: g, store } = localeGame(['fr-FR']);
  g.setLang('de');
  assert.equal(store.get('pp_lang_mode'), 'manual');
  const next = localeGame(['fr-FR'], Object.fromEntries(store));
  assert.equal(next.ctx.lang, 'de');
});
check('Start card (both layouts) preserves every navigation control and works offline',()=>{
  const menu=html.slice(html.indexOf('function menuIcon(name){'),html.indexOf('// Mandatory first-launch name prompt'));
  for(const lang of ['en','ar']){
    const ctx={lang,coins:12,fmtScore:String,t:k=>k==='shop'?'Shop':k,tt:k=>k,buildLangOptionsHTML:()=>'<option>English</option>',LOGO_ANT_SVG:'<svg></svg>',
      xpProgress:()=>({level:1,into:0,need:75,pct:0}),dailyGoalState:()=>({goal:{id:'kills',target:60,reward:150},prog:0,done:0}),dailyGoalLabel:()=>'goal',
      weeklyState:()=>({goal:{id:'kills',target:400,reward:600},p:0,done:0,best:0}),weeklyLabel:()=>'weekly',sceneMap:()=>'<svg></svg>',HOME_ART:{e:'data:image/webp;base64,AA',f:'data:image/webp;base64,AA',b:'data:image/webp;base64,AA'},menuText:k=>k};
    vm.createContext(ctx); vm.runInContext(menu,ctx);
    const card=ctx.buildStartHTML();
    assert(card.includes('start-card'));
    for(const id of ['langSelect','btnMap','btnShop','btnLeaderboard','btnMissions','btnCoinPlus']) assert(card.includes(`id="${id}"`),lang+' '+id);
    for(const mode of ['classic','henguard','cakeattack']) assert(card.includes(`data-mode="${mode}"`),lang+' '+mode);
    assert(!/https?:\/\//.test(card.replace(/xmlns="[^"]*"/g,'')),'No remote assets in the start card');
  }
});
check('Menu and pause freeze canvas redraws and shaking; gameplay still advances',()=>{
  const stability=html.slice(html.indexOf('function applyShake(){'),html.indexOf('// ---------- persistent ink stains'))+
    html.slice(html.indexOf("var last=0, redrawRequested"),html.indexOf('function update(dt, realDt)'))+
    html.slice(html.indexOf('function boot(data){'),html.indexOf('if(window.claude && window.claude.hot)'));
  let draws=0, updates=0, requests=0;
  const g={state:'menu',elapsed:0,shakeUntil:10,shakeSeed:1,shakeMag:4,
    paperShake:{style:{transform:'translate(4px,3px)'}},
    overlay:{hidden:false},stubAdActive:false,PPAds:{isAdInFlight:()=>false},
    slowmoUntil:0,feverUntil:0,requestAnimationFrame:()=>{requests++;},
    draw:()=>{draws++;},update:()=>{updates++;},decayCombo:noop,resize:noop,applyStaticText:noop,
  };
  vm.createContext(g); vm.runInContext(stability,g);
  g.frame(1000); g.frame(1016); g.frame(1032);
  assert.equal(draws,1); assert.equal(updates,0); assert.equal(g.elapsed,0);
  assert.equal(g.paperShake.style.transform,'');
  g.state='playing'; g.frame(1048);
  assert.equal(draws,2); assert.equal(updates,1);
  const elapsed=g.elapsed;
  g.state='paused'; g.frame(1064); g.frame(1080);
  assert.equal(draws,3); assert.equal(g.elapsed,elapsed);
  g.redrawRequested=true; g.frame(1096); assert.equal(draws,4);
  requests=0; g.boot({}); g.boot({});
  assert.equal(requests,1,'Boot must not create duplicate animation loops');
});
console.log(`All ${checks} regression checks passed.`);

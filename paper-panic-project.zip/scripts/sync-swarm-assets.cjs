// Keep the browser authoring module byte-identical in Capacitor's webDir.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
for (const name of ['swarm-invasion.js', 'swarm-invasion.css']) {
  fs.copyFileSync(path.join(root, 'assets', name), path.join(root, 'www', 'assets', name));
}
console.log('Synchronized Paper Panic swarm assets to www/assets.');

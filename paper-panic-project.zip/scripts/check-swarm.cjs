const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const swarm = require('../assets/swarm-invasion.js');
let checks=0;
function check(name,fn){fn();checks++;console.log('PASS',name);}
function memory(){
  const map=new Map(),grants=[];
  global.localStorage={getItem:k=>map.has(k)?map.get(k):null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k)};
  global.window={PPSwarmBridge:{rewardCoins:n=>grants.push(n)}};
  return {map,grants};
}
check('Formation size is based on perimeter and drawing length, clipped to safe deploy bounds',()=>{
  const box={x:0,y:360,w:360,h:160};
  const line=swarm.formationSlots('worker','line',{x:30,y:420},{x:310,y:420},box);
  const circle=swarm.formationSlots('worker','circle',{x:180,y:430},{x:220,y:430},box);
  assert(line.length>0&&circle.length>0,'both line and filled circle must hold workers');
  assert(line.every(p=>p.x>=6&&p.x<=354&&p.y>=366&&p.y<=514));
  assert(line.every((p,i)=>line.slice(i+1).every(q=>Math.hypot(p.x-q.x,p.y-q.y)>=14)));
});
check('Formation placement respects active-unit cap and does not duplicate packed slots',()=>{
  memory();
  const s=swarm.newRun();s.phase='plan';s.reserve.worker=80;
  s.army=Array.from({length:63},(_,i)=>({id:i,role:'worker',x:.5,y:20+i*15,hp:10,maxHp:10}));
  swarm.setStateForTest(s,{w:360,h:640});
  const box={x:0,y:377,w:360,h:160};
  const placed=swarm.placeFormation('worker','line',[{x:35,y:425},{x:325,y:425}]);
  assert.equal(placed.count,1);assert.equal(s.army.filter(x=>x.hp>0).length,64);
  const blocked=swarm.placeFormation('worker','line',[{x:35,y:425},{x:325,y:425}]);
  assert.equal(blocked,null);
  assert.equal(s.reserve.worker,79);
});
check('Versioned snapshots validate and connected march advances to a fresh zone without a scene reset',()=>{
  const s=swarm.newRun();s.towers=[{id:'x',kind:'gun',x:.5,y:350,hp:20,maxHp:20,alive:true}];
  assert(swarm.validSave(s));assert(!swarm.validSave({v:0,phase:'plan',army:[],reserve:{}}));
  swarm.setStateForTest(s);assert.equal(swarm.finishMarch(),1);assert.equal(s.phase,'plan');assert.equal(s.zoneStart,760);assert.equal(s.towers.length,3);
  assert(s.army.length===0,'no free initial troop injection on zone transition');
});
check('Repair choice can be applied once and persists through the next marching state',()=>{
  memory();const s=swarm.newRun();s.phase='repair';s.camera=0;s.towers=[];s.offer=[{id:'reinforce'}];s.repairTaken=false;
  swarm.setStateForTest(s);assert.equal(swarm.applyRepair('reinforce'),true);
  const after=s.reserve.worker;assert.equal(s.phase,'march');assert.equal(s.repairTaken,true);
  assert.equal(swarm.applyRepair('reinforce'),false);assert.equal(s.reserve.worker,after);
});
check('Run reward credits existing coin bridge exactly once, including reload attempts',()=>{
  const {grants}=memory();const s=swarm.newRun();s.runId='swarm-test-id';s.zone=3;s.foods=2;s.towersBroken=5;
  swarm.setStateForTest(s);const paid=swarm.calculateReward();assert(paid>0);assert.equal(swarm.calculateReward(),paid);assert.deepEqual(grants,[paid]);
});
check('Root and Android HTML stay synchronized and load focused invasion assets',()=>{
  const base=path.resolve(__dirname,'..'),a=fs.readFileSync(path.join(base,'index.html'),'utf8'),b=fs.readFileSync(path.join(base,'www/index.html'),'utf8');
  assert.equal(a,b);assert(a.includes('assets/swarm-invasion.js'));assert(a.includes('PPSwarmBridge'));
  new vm.Script(fs.readFileSync(path.join(base,'assets/swarm-invasion.js'),'utf8'));
});
check('Snapshot round-trip restores shared formation members, not duplicated troop objects',()=>{
  memory();const s=swarm.newRun();s.towers=swarm.towerSet(0);swarm.setStateForTest(s,{w:390,h:844});
  const f=swarm.placeFormation('worker','line',[{x:45,y:550},{x:220,y:550}]);
  assert(f.count>0&&f.count<18);
  const restored=swarm.hydrate(JSON.parse(swarm.serialize()));
  assert(swarm.validSave(restored));
  assert.strictEqual(restored.formations[0].units[0],restored.army[0]);
  restored.formations[0].units[0].x=.4;assert.equal(restored.army[0].x,.4);
});
check('Malformed snapshots cannot introduce unknown roles, NaN positions or unlimited armies',()=>{
  memory();const s=swarm.newRun();s.towers=swarm.towerSet(0);
  assert(swarm.validSave(s));
  const bad=JSON.parse(JSON.stringify(s));bad.army=[{role:'dragon',x:0,y:0,hp:1,maxHp:1}];assert(!swarm.validSave(bad));
  bad.army=[];bad.reserve.worker=999;assert(!swarm.validSave(bad));
  bad.reserve.worker=18;bad.camera=NaN;assert(!swarm.validSave(bad));
});
check('Three connected mixed-army encounters can be completed by real movement and combat',()=>{
  memory();const s=swarm.newRun();s.towers=swarm.towerSet(0);swarm.setStateForTest(s,{w:390,h:844});
  ['armor','breaker','worker','medic'].forEach((r,i)=>swarm.placeFormation(r,'line',[{x:35,y:520+i*35},{x:355,y:520+i*35}]));
  assert.equal(s.army.length,30);
  for(let zone=0;zone<3;zone++){
    s.phase='fight';let steps=0;
    while(s.phase==='fight'&&steps++<4500)swarm.simulateFight(.04);
    assert.equal(s.phase,'repair',`encounter ${zone+1} stalled`);
    assert.equal(s.foodHp,0);assert(s.towers.every(t=>!t.alive));assert.equal(s.foods,zone+1);
    const before=s.army.map(u=>u.y),camera=s.camera;
    swarm.simulateMarch(.2);
    assert(s.army.some((u,i)=>u.y>before[i]),'army must march before camera');
    assert.equal(s.camera,camera);
    assert(swarm.applyRepair(s.offer[0].id));
    let previous=s.camera;
    for(let i=0;i<75;i++){if(s.phase!=='march')break;swarm.simulateMarch(.04);assert(s.camera>=previous);previous=s.camera;}
    assert.equal(s.phase,'plan');assert.equal(s.zone,zone+1);assert.equal(s.camera,760*(zone+1));
    assert(s.army.length+Object.values(s.reserve).reduce((a,b)=>a+b,0)<=64);
  }
});
check('A slow repair decision safely stops the march; selecting once introduces no teleport',()=>{
  memory();const s=swarm.newRun();s.towers=swarm.towerSet(0).map(t=>({...t,hp:0,alive:false}));s.foodHp=0;s.phase='fight';
  s.army=[{id:1,role:'armor',x:.5,y:490,hp:54,maxHp:54,atk:0,food:0}];swarm.setStateForTest(s,{w:390,h:844});
  swarm.simulateFight(.04);assert.equal(s.phase,'repair');
  for(let i=0;i<100;i++)swarm.simulateMarch(.04);
  assert.equal(s.phase,'repair');assert.equal(s.zone,0);assert.equal(s.camera,760);
  const y=s.army[0].y;assert(swarm.applyRepair(s.offer[0].id));assert.equal(s.zone,1);assert.equal(s.army[0].y,y);
  assert.equal(swarm.applyRepair('reinforce'),false);
});
check('An empty field does not lose while fighters remain in reserve; healer-only runs end',()=>{
  memory();const s=swarm.newRun();s.towers=swarm.towerSet(0);s.phase='fight';swarm.setStateForTest(s);swarm.simulateFight(.04);assert.equal(s.phase,'fight');
  s.reserve={worker:0,armor:0,breaker:0,medic:2};swarm.simulateFight(.04);assert.equal(s.phase,'defeat');
});
check('Reward ledger blocks payment from a stale snapshot restored after settlement',()=>{
  const {grants}=memory();const s=swarm.newRun();s.foods=2;s.towersBroken=6;s.zone=2;
  const stale=JSON.parse(JSON.stringify(s));swarm.setStateForTest(s);const reward=swarm.calculateReward();
  swarm.setStateForTest(stale);assert.equal(swarm.calculateReward(),reward);assert.deepEqual(grants,[reward]);
});
check('Cake and towers stay at the top on both tall and short phones, with exact touch coordinates',()=>{
  memory();
  for(const h of [640,844]){
    const s=swarm.newRun();s.zone=2;s.camera=1520;swarm.setStateForTest(s,{w:390,h});
    const food=swarm.screenY(1520+490,s.camera,h),towers=swarm.towerSet(2);
    assert.equal(food,135);
    assert(towers.every(t=>swarm.screenY(t.y,s.camera,h)>=190&&swarm.screenY(t.y,s.camera,h)<=240));
    const point=swarm.toWorldPoint(100,500);
    assert.equal(swarm.screenY(point.y,s.camera,h),500);
    assert.equal(point.x,100/390);
  }
});
check('Old saves retain on-screen army position once when migrating the taller attack field',()=>{
  memory();const s=swarm.newRun();delete s.viewVersion;s.camera=760;
  s.army=[{role:'worker',x:.4,y:1000,hp:10,maxHp:17,marchY:1500,marchFromY:1000}];
  const oldScreen=844-(1000-760);
  assert(swarm.migrateView(s,844,625));
  swarm.setStateForTest(s,{w:390,h:844});
  assert.equal(swarm.screenY(s.army[0].y,s.camera,844),oldScreen);
  assert.equal(s.army[0].marchY,1281);
  const after=s.army[0].y;assert.equal(swarm.migrateView(s,844,625),false);assert.equal(s.army[0].y,after);
});
check('Swarm bridge dispatches to the original classic renderers and their original palettes',()=>{
  const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8'),start=html.indexOf('window.PPSwarmBridge={'),end=html.indexOf('\n};',start)+3;
  const calls=[],types=Object.fromEntries(['ant','beetle','roach','ladybug'].map(type=>[type,{bodyColor:type}]));
  const context={window:{},TYPES:types};
  for(const [name,type] of Object.entries({drawAnt:'ant',drawBeetle:'beetle',drawRoach:'roach',drawLadybug:'ladybug'})){
    context[name]=(c,size,b,t)=>{calls.push({type,c,size,b,t});};
  }
  vm.runInNewContext(html.slice(start,end),context);
  let depth=0;const canvasContext={save:()=>depth++,restore:()=>depth--};
  for(const type of Object.keys(types)){
    context.window.PPSwarmBridge.drawInsect(canvasContext,type,12.5,1.25);
    const call=calls.at(-1);assert.equal(call.type,type);assert.strictEqual(call.t,types[type]);
    assert.strictEqual(call.c,canvasContext);assert.equal(call.b.legPhase,1.25);assert.equal(depth,0);
  }
  assert.throws(()=>context.window.PPSwarmBridge.drawInsect(canvasContext,'missing',12,0));
});
check('Each insect card uses the same classic renderer as the moving army',()=>{
  memory();const calls=[];
  window.PPSwarmBridge.drawInsect=(c,type,size,phase)=>calls.push({type,size,phase});
  const ctx=new Proxy({}, {get:(_,key)=>()=>{}});
  const canvas={width:84,height:62,getContext:()=>ctx};
  for(const role of Object.keys(swarm.ROLES))assert(swarm.renderRolePortrait(canvas,role));
  assert.deepEqual(calls.map(c=>c.type),['ant','beetle','roach','ladybug']);
  assert(calls.every(c=>c.size===12.5&&c.phase===0));
});
console.log(`All ${checks} swarm checks passed.`);

check('Finger-drawn loops produce filled formations and larger loops hold more units',()=>{
  const box={x:0,y:320,w:400,h:320};
  const small=swarm.formationSlots('worker','circle',{x:200,y:470},{x:235,y:470},box);
  const large=swarm.formationSlots('worker','circle',{x:200,y:470},{x:275,y:470},box);
  assert(large.length>small.length,`large ${large.length} must exceed small ${small.length}`);
  assert(small.some(p=>Math.hypot(p.x-200,p.y-470)<10),'circle must have bugs near its center');
  const loop=Array.from({length:21},(_,i)=>({x:180+45*Math.cos(2*Math.PI*i/20),y:450+45*Math.sin(2*Math.PI*i/20)}));
  assert.equal(swarm.recognizeGesture(loop),'circle');
  assert.equal(swarm.recognizeGesture([{x:30,y:400},{x:80,y:400},{x:140,y:400}]),'line');
});

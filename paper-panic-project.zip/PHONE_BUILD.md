# بناء تطبيق "حرب الورقة" من الهاتف فقط (عبر GitHub)

نفس طريقة حرب الموارد. البناء يتم مجاناً على خوادم GitHub (نحو 8 دقائق للبناء الواحد).

## مرة واحدة
1. في متصفح الهاتف فعّل **إصدار سطح المكتب (Desktop site)**.
2. **+ ثم New repository**. الاسم: `paper-panic`. اختر **Private** وفعّل **Add a README**، ثم **Create repository**.
3. **Add file ثم Upload files**. اختر `paper-panic-project.zip` **كما هو دون فك ضغطه**، ثم **Commit changes**.
4. **Add file ثم Create new file**. الاسم بالضبط: `.github/workflows/android.yml`. الصق محتوى ملف `android.yml` كاملاً، ثم **Commit changes**. يبدأ البناء تلقائياً.

## تجربة التطبيق على هاتفك
5. تبويب **Actions**، انتظر العلامة الخضراء ✓.
6. افتح عملية البناء، وتحت **Artifacts** اضغط **paper-panic-test-apk**.
7. افتح الملف المنزّل، ثم ملف `.apk`، واسمح بالتثبيت.

## نسخة Google Play
8. **Settings ← Secrets and variables ← Actions ← New repository secret**. الاسم `KEYSTORE_PASSWORD` وقيمته كلمة سر قوية. **احفظها**.
9. **Actions ← Build Android app ← Run workflow** واختر `create-key`. بعد انتهائه نزّل **upload-key-BACKUP-KEEP-SAFE** واحفظه في Google Drive.
10. **Run workflow** مرة أخرى واختر `build`. ستجد **paper-panic-google-play-aab**، وهو ما ترفعه إلى Play Console.

## التحديثات
ارفع ملف `paper-panic-project.zip` الجديد بنفس الاسم. يُستبدل القديم ويبدأ البناء وحده، ويرتفع رقم الإصدار تلقائياً.

## الأمان
أبقِ المستودع **Private**. المفتاح داخل المستودع، وكلمة سره في Secrets، فلا يعمل أحدهما دون الآخر.

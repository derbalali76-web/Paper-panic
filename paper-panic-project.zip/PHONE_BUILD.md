# بناء تطبيق "حرب الورقة" من الهاتف فقط (عبر GitHub)

نفس طريقة حرب الموارد. البناء يتم مجاناً على خوادم GitHub (نحو 8 دقائق للبناء الواحد).

## مرة واحدة
1. في متصفح الهاتف فعّل **إصدار سطح المكتب (Desktop site)**.
2. **+ ثم New repository**. الاسم: `paper-panic`. اختر **Private** وفعّل **Add a README**، ثم **Create repository**.
3. **Add file ثم Upload files**. اختر `paper-panic-project.zip` **كما هو دون فك ضغطه**، ثم **Commit changes**.
4. **Add file ثم Create new file**. الاسم بالضبط: `.github/workflows/android.yml`. الصق محتوى ملف `android.yml` كاملاً، ثم **Commit changes**. يبدأ البناء تلقائياً.

## تجربة التطبيق على هاتفك
5. تبويب **Actions**، انتظر العلامة الخضراء ✓.
6. افتح عملية البناء، وتحت **Artifacts** اضغط **paper-panic-test-apk**.
7. افتح الملف المنزّل، ثم ملف `.apk`، واسمح بالتثبيت.

## نسخة Google Play
8. **Settings ← Secrets and variables ← Actions ← New repository secret**. الاسم `KEYSTORE_PASSWORD` وقيمته كلمة سر قوية. **احفظها**.
9. **Actions ← Build Android app ← Run workflow** واختر `create-key`. بعد انتهائه نزّل **upload-key-BACKUP-KEEP-SAFE** واحفظه في Google Drive.
10. **Run workflow** مرة أخرى واختر `build`. ستجد **paper-panic-google-play-aab**، وهو ما ترفعه إلى Play Console.

## التحديثات
ارفع ملف `paper-panic-project.zip` الجديد بنفس الاسم. يُستبدل القديم ويبدأ البناء وحده، ويرتفع رقم الإصدار تلقائياً.

## الأمان
أبقِ المستودع **Private**. المفتاح داخل المستودع، وكلمة سره في Secrets، فلا يعمل أحدهما دون الآخر.

---

# إعداد الإعلانات والدفعات (AdMob + Google Play Billing)

النسخة الحالية **تعمل مع إعلانات تجريبية ومعرّفات اختبار** (ترى إعلانات اختبار Google الآمنة بينما تختبر). قبل النشر الحقيقي لازم تنشئ حسابات حقيقية.

## 1) حساب AdMob وإنشاء الوحدات الإعلانية

1. اذهب إلى **admob.google.com** وسجّل الدخول بحساب Google.
2. **Apps ← Add app ← Android ← Not listed yet**. اسم التطبيق: `Paper Panic`. احفظ.
3. سيُعطيك **App ID** بالصيغة: `ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX`. **انسخه**.
4. من داخل التطبيق: **Ad units ← Add ad unit**.
   - أنشئ وحدة **Rewarded** واسمها `pp_rewarded`. انسخ **Ad unit ID** (شكله `ca-app-pub-.../NUMBER`).
   - أنشئ وحدة **Interstitial** واسمها `pp_interstitial`. انسخ **Ad unit ID**.

### تطبيق المعرّفات على البناء
في GitHub: **Settings ← Secrets and variables ← Actions ← New secret**:
- `ADMOB_APP_ID` = الـ App ID من الخطوة 3
- بعد البناء الأول الناجح، عدّل `index.html` سطور `ADMOB_REWARDED_ID` و `ADMOB_INTERSTITIAL_ID` بالقيم من الخطوة 4، ثم أعد رفع الـ zip.

> **تنبيه مهم**: إذا نشرت على Play Store وأبقيت معرّفات الاختبار Google قد يرفض التطبيق. لازم تضع معرّفاتك الحقيقية قبل النشر.

## 2) منتجات الشراء في Google Play Console

في **play.google.com/console ← [تطبيقك] ← Monetize ← Products ← In-app products**، أنشئ هذه المنتجات (الـ ID لازم يطابق بالضبط):

| Product ID | Type | Default price |
|---|---|---|
| `pp_remove_ads` | Non-consumable (managed) | $1.99 |
| `pp_coins_small` | Consumable | $0.99 |
| `pp_coins_medium` | Consumable | $1.99 |
| `pp_coins_large` | Consumable | $4.99 |
| `pp_starter_pack` | Non-consumable (managed) | $1.99 |

لكل منتج:
- Name: اختر اسماً معبّراً (مثلاً "500 Coins", "Remove Ads")
- Description: شرح قصير
- بعد الإنشاء اضغط **Activate**.

### اختبار المشتريات قبل النشر
1. في Play Console: **Settings ← License testing**، أضف إيميل Google الخاص بك.
2. ارفع نسخة **Internal testing** أو **Closed testing** من ملف الـ `.aab` الموقّع.
3. أضف نفسك كـ Tester.
4. حمّل التطبيق من Play Store عبر رابط الاختبار. ستشتري بـ **بطاقة اختبار** (لن تُخصم فعلياً).

## 3) تدفقات الإعلانات في اللعبة

- **إعلانات مكافأة (Rewarded)**: يختارها اللاعب بإرادته، كل إعلان = مكافأة واضحة.
- **إعلانات اعتراضية (Interstitial)**: فقط بعد كل **3 جولات انتهت** — لا تظهر مطلقاً أثناء اللعب.
- **حد أقصى**: إعلان واحد كل 60 ثانية فقط (حماية من الإزعاج).
- **مكافأة تراكمية**: مشاهدة 3 إعلانات في جلسة واحدة = +50 عملة إضافية.
- **بعد شراء "إزالة الإعلانات"**: لا تظهر أي إعلانات، والأدوات تُدفع بعملات رمزية (5-15 عملة).

## 4) نموذج أدوات المكافأة (المميزة)

| الأداة | التكلفة بعملات (بعد إزالة الإعلانات) |
|---|---|
| رشاش | 8 عملات لكل استخدام |
| مسدس | 10 عملات |
| لهب | 15 عملة |
| دجاجة | 12 عملة |
| تنظيف سريع | 10 عملات |

في النسخة المجانية: يشاهد اللاعب إعلان واحد → الأداة متاحة 60 ثانية ثم ترتاح 60 ثانية ثم ترجع — طوال الجلسة بدون إعلان آخر.

# Paper Panic — adaptive towers and round results

## This update

- Four unique towers, never duplicated as player power rises: bullet turret,
  pesticide sprayer, flamethrower and sticky honey-glue lobber.
- Crowds raise firing rate, bullet burst size, damage and splash radius.
  Power is capped and briefly decays after the crowd clears. All towers remain
  short-range and behind the cake; the existing 20-fast-ant limit is unchanged.
- Honey projectiles land in slowing puddles. The rewarded giant retains its
  personal 10% eating protection and separated-hit survival.
- New scroll-safe result cards show score, duration, progress/kills, failure
  reason, reward breakdown and a concrete next-attempt target.
- Cake modes show an offline photorealistic cake being eaten by ants; Classic
  shows a chewed notebook. Both have visible funny captions in all 11 languages.
- Performance bonuses reward partial cake progress, faster wins, accurate
  classic play and stage stars. Continuing does not prematurely pay a reward.
  Settlement and rewarded doubling cannot credit the same run twice.
- Stage wins and failures use the same result presentation; retry preserves the
  stage, and Next Page selects the next stage's actual mode.
- Both optimized result photos are bundled in browser and Android assets.
- Verification: 39 programmatic checks plus 19 Chromium runtime assertions
  covering payout, duplicate callbacks, continue/retry, stage transitions and
  natural ant approach. A 20-fast-ant wave could not instantly eat the cake;
  a small wave with armor/decoy made substantially more progress.

No APK was built and no physical Android-device performance is claimed.

## Preserved changes

- Removed the standalone Desk Lamp mode and the How to Play card/button.
  Night phases within Classic mode and its short interactive tutorial remain.
- Ant-type buttons now select and launch an ant immediately. Tapping the paper
  launches the selected type again. Fast ants have no cooldown but are limited
  to 20 simultaneously active units. The button shows the live count out of 20;
  defeating an ant frees a slot. Armored ants recharge in 24 seconds and decoys
  in 16 seconds, so support units can be used tactically within the round.
- Ants enter above the bottom controls so their launch is visible.
- Every defensive tower is positioned behind the cake, including after resizing.
- Tower artwork stays clear of the cake health bar, and attack-mode hints fit a
  narrow phone screen.
- Towers use the game's actual SVG weapon artwork instead of emoji.
- Before arrival, defences activate progressively with ant population. As soon
  as a non-decoy ant reaches the cake, all towers wake and remain active for
  the rest of that round. At least one tower stays asleep until that physical
  arrival, even at the population cap. A new round resets the alarm.
- Fast ants launch in small staggered lanes instead of an overlapping pile.
  The visible 20/20 limit replaces repeated popup messages when the cap is full.
- Fast ants move at 65 px/s, have 3 HP, and eat more slowly. The active-unit
  cap also prevents unlimited swarms from overwhelming rendering or the cake.
- At most eight normal units can advance to eat at once. Others form an
  outside queue and replace defeated attackers; rewarded giants retain access.
  Thus, twenty simultaneous taps cannot produce twenty simultaneous eaters.
- Alerted towers fire a little more frequently with stronger area damage.
  Decoys now travel inside the short-range defensive zone rather than stopping
  too far away to distract anything. Armored units have 16 HP.
- Towers are grouped behind the cake so their short ranges actually cover its
  edge: gun 170 px, spray 165 px, flame 160 px. No whole-board giant targeting.
- Completing the giant-ant reward launches a giant ant protected until it
  personally eats 10 HP (10% of a full cake). Damage by other ants does not
  count. Once that quota is reached, active defences can attack it, but
  it needs eight separate accepted impacts to die. Impacts are at least
  half a second apart, including combined gun/spray/flame attacks. A visible
  health bar tracks its survival. Its eating rate becomes gentler after
  protection ends, so it can survive multiple hits without immediately
  consuming the entire cake.
- Normal attack ants use eight cached animation frames, retaining the original
  vector artwork without rebuilding every leg and body path per ant per frame.
  Small-ant hit flashes no longer require per-ant canvas brightness filters.
- All ants have revised copper-brown segmented bodies, glossy shells,
  articulated legs, curved antennae and larger expressive eyes.
- Attack-mode particles are capped at 160; fire effects are lighter; HUD
  updates run at 10 Hz; sleeping-tower effect cleanup runs only when needed.
- Old ad callbacks cannot introduce a giant into a later round.
- Browser test ads now pause the simulation until the ad finishes.
- Both browser and Capacitor web entry points contain identical game code.
- Leaderboard and guest/join cards are translated into all 11 supported
  languages, including loading, empty, save-name and deletion states.
- Declared UTF-8 at the beginning of the document so Arabic, Chinese, accented
  letters, and emoji render correctly even when hosting supplies no charset.
- On first launch, the language follows the phone/browser language preferences,
  handling regional variants (for example fr-FR, pt-BR and zh-CN).
  Unsupported preferences fall back to English. An explicit choice in the
  language selector is remembered. Legacy automatically saved Arabic defaults
  no longer override the device language.

## Start card and startup stability

- Rebuilt the start card with consistent offline SVG icons for the modes,
  language, currency, shop and leaderboard; no platform emoji on the card.
- Preserves all navigation, translations, language selection and RTL.
  Responsive spacing, scroll-safe short-screen layout and visible focus states.
- The start card has no continuous movement or shifting button transforms.
- Returning to the main menu now explicitly stops gameplay and clears shake.
- Frozen menus and paused overlays no longer redraw the background canvas every
  frame. Gameplay and resize still redraw correctly; duplicate boot requests
  cannot create additional animation loops.

## Classic-mode giant

- Replaces the oversized classic boss with a smaller, actual ant (radius 24).
- Roams both horizontally and vertically across the paper.
- Dies after exactly five accepted hits, regardless of weapon damage.
- Every accepted hit releases five one-hit small ants, including the final hit.
  On nonlethal hits a blue shield stays until all five guards are defeated.
  Guard ants have blue identifying rings and the shield displays guards left.
- Killing unrelated ants does not remove the shield. Repeated/area attacks
  cannot bypass it, and an already-counted guard cannot unlock it twice.
- Continues replace cleared guards so the boss cannot become permanently
  invulnerable after its guard wave disappears.
- Non-classic legacy bosses keep their existing rules. The rewarded giant in
  Attack the Cake retains its separate eating-quota and eight-impact rules.

## Checks

Run `npm test` (no additional test dependencies).

The regression script checks JavaScript syntax, synchronized entry points,
removed menu features, visible spawn positions, all three standard ant types,
unlimited fast launches, other cooldowns, inactive/finished-round guards, tower
placement and density-based activation, personal giant eating quotas, decoy
targeting, stale reward callbacks, the three-giant reward limit, translation
coverage, regional phone locales, RTL, remembered manual language choices,
the 20-unit cap and slot reuse, slow movement, arrival-triggered alarm,
short-range firing and eight separated rewarded-giant hits.
It also checks the eight-attacker capacity, support-unit placement/recharge,
SVG menu controls, frozen menu/pause redraws and single animation-loop startup.

The classic-boss suite checks five-hit death, all five guard kills being required,
guard ownership and duplicate deaths, continue recovery, movement in four
directions, and unchanged non-classic boss rules.

Native AdMob delivery and an Android APK/AAB build require an Android device or
the existing Android build workflow. Browser test ads do not validate live AdMob.


## v60
- النملة العملاقة بعد كشفها: كل الأبراج تستيقظ وتطلق بسرعة وبقوة أعلى وتقتلها خلال ثوانٍ.
- قاعدة معدنية مثبّتة بمسامير للأبراج.
- تحدٍّ أسبوعي محلي (يتغير كل أسبوع) مع مكافأة عملات + أفضل نتيجة للأسبوع.
- إشعارات تذكير محلية: تحتاج المكوّن @capacitor/local-notifications (أُضيف إلى package.json) وتعمل فقط داخل التطبيق.

## v61
- بطاقات المودات برسومات كرتونية: التهم الكعكة (حشرات بملاعق وشوكة حول الكعكة)، الخريطة، الكلاسيك، احمِ الكعكة.

## v62
- إعادة رسم بطاقات المودات بتدرجات وظلال وتفاصيل، شرائط عناوين، خلفية سماء للقائمة، تصحيح نص الخريطة إلى 40.

## v63
- قائمة رئيسية جديدة: ورق مسطّر، بطاقات بإطار ملوّن وشرائط عناوين وأزرار (كلاسيك، هجوم النمل، المهام، المتجر)، شريط وضع حماية الكعكة، وبلاط تنقّل سفلي (الإنجازات، المراحل، الترقيات، المتصدرون، مكافآت).
- شاشة المهام (اليومية والأسبوعية).

## v64
- القائمة الرئيسية بالعربية = نفس التصميم المعتمد (الصورة كغلاف) مع مناطق لمس دقيقة وعملات ومستوى حيّين؛ اللغات الأخرى تستخدم التخطيط ذا النص الحي.

## v65
- القائمة الرئيسية بملء الشاشة بلا إطار.
- متجر جديد: ترويسة خشبية، تبويبات لامعة بأيقونات، بطاقات بإطار وأيقونات للأدوات، أزرار شراء لامعة.
- تحديث فحوصات المشروع (npm test) لتطابق السلوك الحالي: 25 + 5 + 9 تنجح.

## v66 — الزعيم (النملة العملاقة)
- 25 نقطة صحة: كل 5 ضربات تطلق موجة حشرات (4، 6، 8، 10، 12) وكل موجة بنوع مختلف.
- يقذف فضلات تسقط على الورقة وتترك بقعاً (تُنظّف بالممحاة).
- أُزيل نظام الدرع/الحرس القديم. اختبارات الزعيم أُعيدت كتابتها.

### v66 (تعديل لاحق)
- الزعيم: عاد الدرع (الموجة تحميه حتى تُقتل)، والمطرقة فقط تؤذيه (الحذاء وباقي الأسلحة لا تؤثر).
- الحشرات لا تبقى تحت أزرار الأدوات اليمنى.
- اهتزاز: Capacitor Haptics (إضافة @capacitor/haptics) مع بديل navigator.vibrate؛ اهتزاز/اهتزاز ورقة وحجم أكبر لنص الكومبو عند 5/10/15/20.
- صندوق الجولة (مكافأة عشوائية بعد كل جولة، يشمله مضاعفة العملات بالإعلان).
- مهمتان يوميتان إضافيتان (pp_dm) + تقويم الدخول 7 أيام داخل شاشة المهام.
- موسوعة الحشرات (pp_dexkills/pp_dexclaimed): نجوم عند 25/100/500 مع مكافآت.
- ملاحظة: يلزم npm install/npx cap sync لإضافة haptics في CI (android.yml يشغّل npm ci فقط — لا مشكلة: الـworkflow يرجع إلى npm install).

### v66 — شريط الأوضاع (Carousel)
- الشاشة الرئيسية: الوضع المختار في الوسط، يمرّر المستخدم يميناً/يساراً لباقي الأوضاع (الكلاسيكي، هجوم النمل، احمِ الكعكة) مع نقاط مؤشر؛ الضغط على بطاقة جانبية يوسّطها، والضغط على الوسطى يبدأ اللعب؛ يُتذكّر آخر وضع (pp_lastmode).

### v66 — عودة الواجهة البسيطة
- حُذف شريط الأوضاع الدوّار وواجهة الصورة العربية. واجهة موحّدة لكل اللغات: بطاقتا كلاسيكي وهجوم الكعكة بصورتين كرتونيتين، شريط احمِ الكعكة بصورته، ثم زرّا المتجر والمهام البسيطان وصف الأزرار السفلية. ملء الشاشة.

### v66 — واجهة v58 البسيطة + صور كرتونية
- الرئيسية بأسلوب v58 (بطاقات كريمية هادئة): كلاسيكي، هجوم الكعكة، احمِ الكعكة بصورها الكرتونية، خريطة الصفحات، ثم صفّان: المتجر/المهام/المتصدرون و الإنجازات/الترقيات/مكافآت. لم تعد واجهات home2/home3 والشريط الدوّار مستعملة (الشيفرة باقية دون استدعاء).

### v66 — الواجهة الكريمية (شكل v54) بصور كرتونية
- 4 بطاقات 2×2 كما في تصميم المستخدم: كلاسيكي (أحمر) وخريطة الصفحات (أزرق) واحمِ الكعكة وهاجم الكعكة؛ كل واحدة بصورتها الكرتونية. الخريطة بمشهد SVG لأنها بلا صورة كرتونية.
- صف المتجر/المتصدرون وتحته روابط صغيرة: المهام، الإنجازات، الترقيات، مكافآت. الرصيد + المستوى بجانب بعض.
- ضبط الأبعاد: البطاقات أقصر (≈1.06:1 بدل ≈0.9) وتظهر القائمة كاملة بلا تمرير على 390×780 و360×640 و412×915 بالاختبار.

## v66 — المتجر بتصميم كرتوني
- أيقونات كرتونية للتبويبات والترقيات والمكافآت، بطاقات عملات 2×2 ملوّنة، شبكة أزياء من 4 أعمدة بنص داكن واضح (إصلاح النص الباهت).
- لم تُمسّ منطق الشراء/الإعلانات/المعرّفات.

## v67
- حذف بطاقة "ابدأ اللعب/المتجر" الثابتة التي كانت تومض لحظة قبل الرئيسية.
- ترجمة 153 نصاً (الإنجازات، المهام، الترقيات، المتجر، الشرح...) إلى الإسبانية والألمانية والإيطالية والبرتغالية والروسية والتركية والإندونيسية والصينية (والفرنسية الناقص)؛ الاحتياط الآن الإنجليزية بدل العربية.
- التهم الكعكة: مسافة أوسع بين الأبراج (حتى 84px).
- الزعيم العملاق (كلاسيكي + احمِ الكعكة): نملة/دعسوقة/برغوث/ذبابة بالتناوب (لا يتكرر النوع متتالياً)؛ كل زعيم يطلق حشرات صغيرة من نوعه فقط، بنفس قواعد الدرع والمطرقة والـ25 نقطة.
- الذبابة: رسم جديد واقعي بأجنحة بعروق ترفرف وعيون مركّبة حمراء.

## v68
- الأزياء: إعادة تصميم المتجر كما في الصورة (بطاقات، أسعار، علامات ✓/🔒)، أزياء جديدة للحذاء والمطرقة وورقة القلوب.
- عجلة الحظ: نافذة عجلة دوّارة تظهر الجائزة فعلاً.
- التهم الكعكة: إخفاء قوة الأبراج؛ حشرة التشتيت تجول في الورقة ويضربها برج واحد؛ زر ذبابة عملاقة (بعد إعلان) تعطّل الأبراج مؤقتاً.
- أيقونة التطبيق: خلفية كحلية صافية وصورة مصغّرة داخل منطقة الأمان لتظهر كاملة في الدائرة/المربع على الهاتف.
- إصلاح: عند فشل/تأخر الإعلان لا تبقى اللعبة متوقفة (تحرير تلقائي بعد 8 ثوانٍ).
- أيقونة احترافية: صورة كاملة تملأ الدائرة/المربع بدون إطار داخلي.
- إصلاح اسم حدث الإعلان البيني (interstitialAdDismissed) + FailedToShow؛ قسم الإشعارات في سياسة الخصوصية.
- بطاقة خسارة واحدة بتصميم جديد (إحصائيات، مكافأة، XP، إعادة المحاولة / استمر بإعلان) بدل بطاقتين.
- بطاقة الخسارة طبق الأصل للتصميم المعتمد (صورة خلفية + نصوص حية)، دون زر العملات بإعلان.
- فضلات لكل حشرة (حجم/لون/اتساخ خاص بكل نوع) تُمسح بالممحاة.
- بطاقة فوز مشابهة لبطاقة الخسارة (شريط أخضر، كأس، نجوم).

## v68 — بيئات، زعماء بسلوكيات، عنكبوت حقيقي
- العنكبوت: رسم جديد (8 أرجل بمفصلين تمشي بالتناوب، بطن بنقش، عيون، فكوك).
- الزعماء الأربعة بسلوك مختلف وتحذير واضح (⚠ + مثلث + حلقة) ونقطة ضعف ×2 مكتوبة للاعب:
  النملة تستدعي حشرات (تتعب بعد الاستدعاء)، الدعسوقة تختبئ (لا تُصاب) ثم تخرج، البرغوث يقفز بخط تحذير ثم يدوخ، الذبابة تنقضّ على هدف ثم تعلق.
- البيئات: المكتب ← المطبخ ← الحديقة ← حصن الكعكة. لكل بيئة حشراتها وخلفيتها وزعيمها (نملة / ذبابة / دعسوقة) ومراحل «اصطد N من نوع».
- المختبر أُعيد تسميته «الحديقة» (خلفية خضراء، خريطة، أوسمة). 11 لغة.
- الاحتفاظ: «يوم سماح» للسلسلة اليومية — غياب يوم واحد لا يمسح السلسلة (مرة لكل دورة)، مع رسالة لطيفة بـ11 لغة.
- الأصوات (v68b): طقم كرتوني مُركَّب بالكود بلا ملفات: زنبرك «بوينغ» يعلو مع ضربات الزعيم، أصوات بشرية كرتونية («إييك»، «واااو»، «أوه-أوه»)، ترومبون حزين وصفّارة انزلاق عند سقوط الزعيم، بوق مهرّج عند تحذيره، وصوت مختلف لكل حشرة. تحترم زر الكتم.
- الأصوات (v68c): خفض الحدّة (نغمات أخفض + مرشّح ناعم) وأصوات ألم كرتونية عند تلقي الضربة: «إيي» «أوه» «آآآي» «آخ» لكل حشرة وللزعيم.
- الأصوات (v68d): استُبدلت الأصوات المركّبة بتسجيلات حقيقية CC0 (بوينغ زنبرك، صفّارة انزلاق، فقاعات، مواء، أصوات ألم، ضحكة) مضمّنة في index.html (~300KB)، مع تنويع عشوائي للنغمة؛ والأصوات المركّبة احتياطي. المصادر في assets/sfx/LICENSES.md.
- الأصوات (v68e): أصوات الألم البشرية/المخلوقات للزعماء فقط. الحشرات العادية: أصوات خفيفة قصيرة (فقاعة/طقّة/بوينغ/صفّارة) وليس مع كل قتلة (~60%) مع فاصل أدنى.
- الأصوات (v68f): صوت «Slap - Cartoony» (من Freesound، اختاره المستخدم) لضرب كل الحشرات بنغمة مختلفة لكل نوع؛ التأوهات للزعماء فقط (صفعة + تأوه). تنبيه: ترخيص هذا الصوت لم يُتحقق منه — راجع assets/sfx/LICENSES.md.
- الأصوات (v68g): صوت المطرقة مختلف عن الشبشب: الشبشب = صفعة كرتونية، المطرقة = «طُنك» خشبي ثقيل أخفض، الرشّاش = فقاعة ناعمة. ضربة الزعيم (بالمطرقة) = طنك عميق + تأوه.

## v68h
- Fix spider/bug-hit lag: removed ctx.filter brightness flash (≈200 ms hitch per hit) → cheap white flash.
- Attack mode: giant fly costs 50 coins ×3 per round then rewarded ads; giant ant 100 coins once then ads (not enough coins → ad).
- Giant ant releases 3 ants at 75/50/25% health and 4 on death; ants crawl slowly near the cake.
- Sounds: Mixkit punch/cartoon-punch/splat/fart/boing/slide mapped per tool/bug/boss; Freesound slap removed.

## v69
- Attack mode: attacker shop/loadout (choose 3; buy bomber 250 / roach 200 / spider 300 with coins; saved in localStorage).
- New attackers: Bomber (explodes on nearest tower; 3 blasts disable it 12 s), Roach (fast, resistant), Spider (drops 3 ants on death).
- Abilities charged by eating the cake: Scream (+60% speed 3 s), Hole (ants untargetable 3.5 s).
- Mid-round events: cat knocks out 2 towers 6 s; broom sweeps a warned band (hidden ants survive).
- Cake milestones every 20% eaten: free ants + 10 coins + charge. Star rating on win (time, ants lost). Tower order random per round.

## v69b
- Draw-a-route: drag on the paper in attack mode; ants follow the line then go to the cake (short tap still launches straight).
- Perk cards at every 20% of the cake (split, thick skin, sprinters, hungry, quick reload, better bombs, fast charge, loot).
- Daily rule for standalone attack rounds (blind towers / tough-slow ants / ants die after 10 s / storm / rush) + 50 coins on first win of the day.
- Ant hats (cosmetic) sold for coins, chosen in the loadout screen.

## v70
- Attack mode: removed cat/broom events, Scream and Hole abilities, and the free-ants/coins reward at 20% cake steps (perk cards stay).
- Formation screen before every attack: choose up to 5 kinds and at most 50 insects (fast ≤50, armored ≤10, decoy ≤5, fly ≤2, giant ant ≤3, + shop kinds); press "Attack". Units are consumed on launch; running out with no live attackers = loss ("failureNoAnts").
- New shop insects: flea 150, shadefly 350 (invisible to towers 3 s), goldbug 400 (bullet-resistant); bomber/roach/spider kept.

## v71 — one-shot assault (Cake Attack)
- Shop: choose the army, press "Play ▶". The whole army appears lined up at the bottom.
- Tap kinds to set who attacks first (numbered badges), optionally drag one route, press "Attack ⚔️".
- The army is released once, in that order; no more launching afterwards. Timer starts at Attack.
- Giant ant / giant fly: coins first, then rewarded ads (paid when Attack is pressed). Cooldown perk removed.
- Failure when the whole army is sent and none is alive.

## v72 — army blocks + sniper wasp
- Each kind is its own block on the paper (centre / left / right / front / back); tap a block (or its chip) to set attack order.
- "Together" toggle releases all blocks at the same time.
- New ranged insect: sniper wasp 🐝 (shop, 350 coins) stops at tower range and zaps towers; 3 zaps disable a tower.

## v73 — no timer, shapes, upgrades
- Cake Attack: timer and "+2:00 ad" removed; round ends when the cake is eaten or every insect is gone. Stars now depend on losses.
- Formations use shapes (triangle, ring, arc, diamond, wall, square) instead of grids.
- Shop: per-kind upgrades, power ⚔️ and health ❤️ (5 levels each, coins). Giant ant: power only.

## v74 — shop copied from the mock-up, group attack, boosters
- "Together" button removed: no order chosen = all groups attack together; chosen groups go first in order, the rest together.
- Attack-mode shop rebuilt as a single page like the supplied mock-up: header with coins/+/close, 5 tabs (scroll anchors), insects panel with 3 upgrade bars (coin loot / power / health) + stepper + upgrade button, special-insect cards, boosters, look, offers.
- Artwork cropped from the supplied mock-up into assets/shop/*.webp (insects, boosters, hats, chest, coins).
- Offers use the game's existing billing SKUs (starter pack, 5000 coins) through PPBilling, unchanged.
- Loot upgrade: +5 coins per level per kind used on victory. Boosters: freeze towers 5 s / bomb nearest tower 12 s / cloak 3 s, used from the HUD during the attack.
- Names follow the mock-up (mosquito, scorpion, centipede, killer wasp). Shadefly and bomber have no artwork in the mock-up: emoji tiles.

## v75 — bomber ant
- Bomber is now an ant carrying a lit bomb (shop picture composed from the mock-up ant + drawn bomb; in-game ant drawn with a bomb on its back). Renamed "Bomber ant". Only the shadefly still uses an emoji tile.

## v76
- Attack campaign: 10 levels (stars, unlocks, level 10 boss with weapon swap every 10 s, +300 coins first clear); insects unlock by progress.
- Tower weaknesses (⚠ hint above towers), medic ant (heals allies), saved formations (3 slots), last-attack stats + retry with previous order, daily challenge with local best.
- Shadefly redrawn to match the other insects.
- Not done: online weekly leaderboard (needs backend).

## v77
- Attack mode is endless: eating the cake moves to the next level (new cake, more and stronger towers: 1 tower at level 1, up to 4), then a card appears to buy more ants / choose a new formation. Stars and level-select removed; best level reached unlocks insects.
- Fast ants are refilled for free on every new-level card.
- Only one giant ant per attack.
- Staged groups are shrunk to fit their own cell (largest in the middle) so they no longer overlap.

## v78
- Seamless road: after the cake is eaten there is no level screen. A small bottom card offers reinforcements (3 free picks from owned kinds, 2 kinds via rewarded ad), fast ants are free, then it disappears and the next cake/towers appear without any "new level" screen.

## v79
- Attack stage restyled to the user's mock-up: real game sprites (glossy black ants, beetles, ladybugs, flies) in the groups and on the bottom chips (art + name + price + count), bold outlined "N×" labels, bigger white caption box and Attack button, hint toast removed. Attack-mode ants are black.

## v80
- "Auto formation" button (armor/decoy first, swarm next, giants last) and a one-time "Last bite!" popup at 10% cake in attack mode.

## v81
- Tower range circles in the planning phase and a red warning ring ~0.5 s before a tower fires.
- Swarm leader "Queen": +40% speed for 5 s, 25 s cooldown, unlocked at best level 3 (ATK_QUEEN holds the numbers).

## v82
- Cake-bonus upgrade cards no longer pause the attack: three side buttons for 4 s, a random one is taken if none is chosen.
- Last 15% "frenzy": all towers wake, a hen runs in, bite marks grow, "Last bite!" popup; finishing it with <=3 losses gives a +50 coin "Clean eat" bonus.
- Retry starts instantly with the same army and previous order (shop is a button next to Auto formation; the shop still opens at the first run of a session).

## v83
- واجهة غزو الحشرات: شريط علوي (دفاعات/طعام/منطقة/عنوان/إعدادات) وبطاقات سفلية ملوّنة أصغر، المتجر مضغوط (حشرات خاصة بصف واحد، 3 أعمدة)، وزر الإعدادات يفتح الإيقاف مع الصوت والرئيسية.

## v83b
- متجر غزو الحشرات بسمة بنفسجية مأخوذة من ملف السرب: بطاقات حشرات عمودين، شريط جيش، نفس الأرقام والمحرك.

## v83c
- المتجر: رجوع للسمة الفاتحة وصفوف الحشرات بترتيب الصورة (صورة، اسم، أشرطة، عدّاد، ترقية)؛ بطاقات اللعب السفلية أكبر.

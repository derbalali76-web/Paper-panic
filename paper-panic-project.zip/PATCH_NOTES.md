# Paper Panic — gameplay fixes

## Changes

- Removed the standalone Desk Lamp mode and the How to Play card/button.
  Night phases within Classic mode and its short interactive tutorial remain.
- Ant-type buttons now select and launch an ant immediately. Tapping the paper
  launches the selected type again. Fast ants have no cooldown; armored ants
  and decoys keep their existing recharge times.
- Ants enter above the bottom controls so their launch is visible.
- Every defensive tower is positioned behind the cake, including after resizing.
- Tower artwork stays clear of the cake health bar, and attack-mode hints fit a
  narrow phone screen.
- Towers use the game's actual SVG weapon artwork instead of emoji.
- Defences activate progressively: one tower for 1–9 ants, two for 10–19, three
  for 20–29, and additional towers at 30 and 40 if the stage has them. Towers
  rotate duty every six seconds; inactive towers stop their residual attacks.
  Inactive towers are visibly dimmed.
- Fast ants now actually use their configured 215 px/s movement rather than
  the generic species movement. They have 6 HP. Towers have shorter ranges,
  smaller area attacks and longer firing intervals, with no escalating
  damage as the cake shrinks. New standard ants have a 1.2-second targeting
  grace period. Fast-ant launching still has no cooldown or population cap.
- Completing the giant-ant reward launches a giant ant protected until it
  personally eats 10 HP (10% of a full cake). Damage by other ants does not
  count. Once that quota is reached, active defences can attack it, but
  it needs eight separate accepted impacts to die. Impacts are at least
  half a second apart, including combined gun/spray/flame attacks. A visible
  health bar tracks its survival. Its eating rate becomes gentler after
  protection ends, so it can survive multiple hits without immediately
  consuming the entire cake.
- Normal attack ants use eight cached animation frames, retaining the original
  vector artwork without rebuilding every leg and body path per ant per frame.
  Small-ant hit flashes no longer require per-ant canvas brightness filters.
- Attack-mode particles are capped at 160; fire effects are lighter; HUD
  updates run at 10 Hz; sleeping-tower effect cleanup runs only when needed.
- Old ad callbacks cannot introduce a giant into a later round.
- Browser test ads now pause the simulation until the ad finishes.
- Both browser and Capacitor web entry points contain identical game code.
- Leaderboard and guest/join cards are translated into all 11 supported
  languages, including loading, empty, save-name and deletion states.
- Declared UTF-8 at the beginning of the document so Arabic, Chinese, accented
  letters, and emoji render correctly even when hosting supplies no charset.
- On first launch, the language follows the phone/browser language preferences,
  handling regional variants (for example fr-FR, pt-BR and zh-CN).
  Unsupported preferences fall back to English. An explicit choice in the
  language selector is remembered. Legacy automatically saved Arabic defaults
  no longer override the device language.

## Checks

Run `npm test` (no additional test dependencies).

The regression script checks JavaScript syntax, synchronized entry points,
removed menu features, visible spawn positions, all three standard ant types,
unlimited fast launches, other cooldowns, inactive/finished-round guards, tower
placement and density-based activation, personal giant eating quotas, decoy
targeting, stale reward callbacks, the three-giant reward limit, translation
coverage, regional phone locales, RTL, remembered manual language choices,
configured movement speed, ordinary-ant survival and eight separated giant hits.

Native AdMob delivery and an Android APK/AAB build require an Android device or
the existing Android build workflow. Browser test ads do not validate live AdMob.

### Focused browser verification

- A small group of ordinary fast ants reached the cake through real controls,
  reduced its HP, and a natural play observation reached a cake-devoured victory.
- In a giant-only round, its first accepted damage came after it had eaten
  10.19 cake HP. It then survived eight accepted impacts over 6.57 seconds.
- Same-run synthetic drawing comparison: 200 ants, 390×697 canvas, DPR 1,
  ten warmup draws followed by three batches of forty draws. Median batch
  time fell from 131.5 ms to 42.8 ms (about 67.5% lower).
  This measures browser drawing work, not real Android-device FPS.
- No page errors were observed in the focused browser pass.

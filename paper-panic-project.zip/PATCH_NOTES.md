# Paper Panic — menu, challenge and stability update

## Changes

- Removed the standalone Desk Lamp mode and the How to Play card/button.
  Night phases within Classic mode and its short interactive tutorial remain.
- Ant-type buttons now select and launch an ant immediately. Tapping the paper
  launches the selected type again. Fast ants have no cooldown but are limited
  to 20 simultaneously active units. The button shows the live count out of 20;
  defeating an ant frees a slot. Armored ants recharge in 24 seconds and decoys
  in 16 seconds, so support units can be used tactically within the round.
- Ants enter above the bottom controls so their launch is visible.
- Every defensive tower is positioned behind the cake, including after resizing.
- Tower artwork stays clear of the cake health bar, and attack-mode hints fit a
  narrow phone screen.
- Towers use the game's actual SVG weapon artwork instead of emoji.
- Before arrival, defences activate progressively with ant population. As soon
  as a non-decoy ant reaches the cake, all towers wake and remain active for
  the rest of that round. At least one tower stays asleep until that physical
  arrival, even at the population cap. A new round resets the alarm.
- Fast ants launch in small staggered lanes instead of an overlapping pile.
  The visible 20/20 limit replaces repeated popup messages when the cap is full.
- Fast ants move at 65 px/s, have 3 HP, and eat more slowly. The active-unit
  cap also prevents unlimited swarms from overwhelming rendering or the cake.
- At most eight normal units can advance to eat at once. Others form an
  outside queue and replace defeated attackers; rewarded giants retain access.
  Thus, twenty simultaneous taps cannot produce twenty simultaneous eaters.
- Alerted towers fire a little more frequently with stronger area damage.
  Decoys now travel inside the short-range defensive zone rather than stopping
  too far away to distract anything. Armored units have 16 HP.
- Towers are grouped behind the cake so their short ranges actually cover its
  edge: gun 170 px, spray 165 px, flame 160 px. No whole-board giant targeting.
- Completing the giant-ant reward launches a giant ant protected until it
  personally eats 10 HP (10% of a full cake). Damage by other ants does not
  count. Once that quota is reached, active defences can attack it, but
  it needs eight separate accepted impacts to die. Impacts are at least
  half a second apart, including combined gun/spray/flame attacks. A visible
  health bar tracks its survival. Its eating rate becomes gentler after
  protection ends, so it can survive multiple hits without immediately
  consuming the entire cake.
- Normal attack ants use eight cached animation frames, retaining the original
  vector artwork without rebuilding every leg and body path per ant per frame.
  Small-ant hit flashes no longer require per-ant canvas brightness filters.
- All ants have revised copper-brown segmented bodies, glossy shells,
  articulated legs, curved antennae and larger expressive eyes.
- Attack-mode particles are capped at 160; fire effects are lighter; HUD
  updates run at 10 Hz; sleeping-tower effect cleanup runs only when needed.
- Old ad callbacks cannot introduce a giant into a later round.
- Browser test ads now pause the simulation until the ad finishes.
- Both browser and Capacitor web entry points contain identical game code.
- Leaderboard and guest/join cards are translated into all 11 supported
  languages, including loading, empty, save-name and deletion states.
- Declared UTF-8 at the beginning of the document so Arabic, Chinese, accented
  letters, and emoji render correctly even when hosting supplies no charset.
- On first launch, the language follows the phone/browser language preferences,
  handling regional variants (for example fr-FR, pt-BR and zh-CN).
  Unsupported preferences fall back to English. An explicit choice in the
  language selector is remembered. Legacy automatically saved Arabic defaults
  no longer override the device language.

## Start card and startup stability

- Rebuilt the start card with consistent offline SVG icons for the modes,
  language, currency, shop and leaderboard; no platform emoji on the card.
- Preserves all navigation, translations, language selection and RTL.
  Responsive spacing, scroll-safe short-screen layout and visible focus states.
- The start card has no continuous movement or shifting button transforms.
- Returning to the main menu now explicitly stops gameplay and clears shake.
- Frozen menus and paused overlays no longer redraw the background canvas every
  frame. Gameplay and resize still redraw correctly; duplicate boot requests
  cannot create additional animation loops.

## Classic-mode giant

- Replaces the oversized classic boss with a smaller, actual ant (radius 24).
- Roams both horizontally and vertically across the paper.
- Dies after exactly five accepted hits, regardless of weapon damage.
- Every accepted hit releases five one-hit small ants, including the final hit.
  On nonlethal hits a blue shield stays until all five guards are defeated.
  Guard ants have blue identifying rings and the shield displays guards left.
- Killing unrelated ants does not remove the shield. Repeated/area attacks
  cannot bypass it, and an already-counted guard cannot unlock it twice.
- Continues replace cleared guards so the boss cannot become permanently
  invulnerable after its guard wave disappears.
- Non-classic legacy bosses keep their existing rules. The rewarded giant in
  Attack the Cake retains its separate eating-quota and eight-impact rules.

## Checks

Run `npm test` (no additional test dependencies).

The regression script checks JavaScript syntax, synchronized entry points,
removed menu features, visible spawn positions, all three standard ant types,
unlimited fast launches, other cooldowns, inactive/finished-round guards, tower
placement and density-based activation, personal giant eating quotas, decoy
targeting, stale reward callbacks, the three-giant reward limit, translation
coverage, regional phone locales, RTL, remembered manual language choices,
the 20-unit cap and slot reuse, slow movement, arrival-triggered alarm,
short-range firing and eight separated rewarded-giant hits.
It also checks the eight-attacker capacity, support-unit placement/recharge,
SVG menu controls, frozen menu/pause redraws and single animation-loop startup.

The classic-boss suite checks five-hit death, all five guard kills being required,
guard ownership and duplicate deaths, continue recovery, movement in four
directions, and unchanged non-classic boss rules.

Native AdMob delivery and an Android APK/AAB build require an Android device or
the existing Android build workflow. Browser test ads do not validate live AdMob.


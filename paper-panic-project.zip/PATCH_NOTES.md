# Paper Panic — gameplay fixes

## Changes

- Removed the standalone Desk Lamp mode and the How to Play card/button.
  Night phases within Classic mode and its short interactive tutorial remain.
- Ant-type buttons now select and launch an ant immediately. Tapping the paper
  launches the selected type again, subject to its existing cooldown.
- Ants enter above the bottom controls so their launch is visible.
- Every defensive tower is positioned behind the cake, including after resizing.
- Tower artwork stays clear of the cake health bar, and attack-mode hints fit a
  narrow phone screen.
- Towers use the game's actual SVG weapon artwork instead of emoji.
- Completing the giant-ant reward launches a giant ant. Defences prioritize it
  with increased range, firing cadence, and damage, then return to normal strength.
- Old ad callbacks cannot introduce a giant into a later round.
- Browser test ads now pause the simulation until the ad finishes.
- Both browser and Capacitor web entry points contain identical game code.

## Checks

Run `npm test` (no additional test dependencies).

The regression script checks JavaScript syntax, synchronized entry points,
removed menu features, visible spawn positions, all three standard ant types,
cooldowns, inactive/finished-round guards, tower placement, anti-giant behaviour,
decoy targeting, stale reward callbacks, and the three-giant reward limit.

Native AdMob delivery and an Android APK/AAB build require an Android device or
the existing Android build workflow. Browser test ads do not validate live AdMob.

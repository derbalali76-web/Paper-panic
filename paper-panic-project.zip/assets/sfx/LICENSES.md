# Sound sample credits (embedded in index.html as window.PP_SFX)

All samples are CC0 1.0 (public domain). Attribution is not required; recorded here for the store/licensing record.
Collected from the GitHub repository https://github.com/lavenderdotpet/CC0-Public-Domain-Sounds (a curated CC0 collection).
Files were trimmed, loudness-normalised and re-encoded to mono MP3; some were pitch-shifted.

| Used as | Original pack / file | Author / license statement |
|---|---|---|
| boing1-4, boingS | "BB_Retail Therapy Sample Pack" / Boyioioing 1-4 | Ben Burnes — CC0 (pack README) |
| whistle_* | "bb - Slide Whistle (Aug 2021)" / Fast Rise Fall, Fast Drop, Wobble Drop, Drunk 1 | Ben Burnes — CC0 (pack README) |
| plop_* | "bb - Bottle Plops (Apr 2021)" / Plop - Airy 1, Viscous 1, Sputter 1 | Ben Burnes — CC0 (pack README) |
| cat_trevor, cat_tito | "Micro Pack - Cat Meows" / Trevor, Tiny Tito | Ben Burnes — CC0 (pack README) |
| hey_ooooh, laughing, thonks, thunk1 | "BB_Retail Therapy Sample Pack" / Hey Ooooh, Laughing on Company Time, Heavy Thonks, Good Thunk 1 | Ben Burnes — CC0 (pack README) |
| hurt2-5, hurt3_up, hurt5_up, scream1 | "80-CC0-creature-SFX" / hurt_02-05, scream_01 | CC0 (pack name/collection license) |
| man_pain(_up), woman_pain_up | "warfork-cc0" / players/male|female/pain50.ogg | Team Forbidden — CC0 (warfork_assets_cc0.txt) |

Please re-verify each license against the upstream sources before commercial release.

## Added by the user (hit sound for regular bugs)
- `slap`: "Slap - Cartoony" by AdminMP on freesound.org (page: freesound.org, March 7th 2017; a remix of "Whip02" by Snowflakes and "facepunch" by Makemebad).
  The recording was extracted from the user's screen capture. **The Freesound license of this sound was NOT verified** — check the license shown on its Freesound page
  (CC0 / CC-BY need credit or are fine; CC-BY-NC forbids commercial use) and the licenses of the two source sounds BEFORE publishing commercially.

## v68 – Mixkit sounds (replace the Freesound "slap", which is removed)
mx_punch (soft-quick-punch-2151), mx_cpunch (cartoon-punch-2149), mx_boing (metallic-boing-hit-2895),
mx_slide (funny-video-game-slide-2888), mx_splat (funny-cartoon-fast-splat-2889), mx_fart (cartoon-fart-or-splat-3056)
Source: mixkit.co – Mixkit Sound Effects Free License (verify current terms before release). Processed: trimmed, boosted, mono 32 kHz.

- boss_ow — "Ow exclamation of pain" (Mixkit sound effect #2204), supplied by the owner; used for the boss hit/fall voice in classic and cake-guard modes. Mixkit Sound Effects Free License (free for use in apps, no attribution required).
- boss_cough — "Man coughing loud" (Mixkit sound effect #2222), supplied by the owner; played when spray gas reaches a boss. Mixkit Sound Effects Free License.

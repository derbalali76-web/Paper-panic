(function(root,factory){
  var api=factory();
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  if(root) root.PPSwarm=api;
  if(typeof document!=='undefined') api.install();
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  var SAVE_KEY='pp_swarm_run_v1',CAP=64;
  var ROLES={
    worker:{label:'Worker',ar:'عاملة',type:'ant',r:6,hp:17,speed:47,power:1,eat:1.2,heal:0,spacing:17},
    armor:{label:'Armor',ar:'مدرعة',type:'beetle',r:9,hp:54,speed:34,power:2,eat:.7,heal:0,spacing:23},
    breaker:{label:'Breaker',ar:'محطّمة',type:'roach',r:8,hp:31,speed:40,power:7,eat:.15,heal:0,spacing:21},
    medic:{label:'Medic',ar:'معالجة',type:'ladybug',r:7,hp:22,speed:37,power:.2,eat:.3,heal:3,spacing:19}
  };
  var strings={
    en:{title:'SWARM INVASION',pause:'Pause',home:'Home',resume:'Resume',newrun:'New run',attack:'Attack',auto:'Auto',undo:'Undo',favorite:'Save line',line:'Line',arc:'Arc',circle:'Circle',troops:'in reserve',draw:'Choose a bug, then draw a line, arc or circle in the lower paper.',fight:'Both the defenses and the snack must fall.',food:'Snack',towers:'Defenses',repair:'Patch the paper army',choose:'Pick one field repair',heal:'Patch up',reinforce:'Fresh legs',damage:'Sharper jaws',march:'The crumbs are marching…',defeat:'The army ran out of legs',report:'Run report',foods:'snacks eaten',broken:'defenses broken',distance:'zones reached',best:'best',exit:'Keep this run saved and head home?',yes:'Leave run',no:'Stay',health:'army',command:'Order',attackOrder:'Attack',protect:'Protect',flank:'Flank',selected:'Selected',welcome:'Run-only starter crew—no unlocks, currency or permanent upgrades are changed. A mixed line is stronger than a stampede.',foodDone:'Snack eaten',towersDone:'Defenses down',round:'zone',saved:'Favorite saved',none:'No formation yet',resumeTitle:'Your trail is still warm',newTitle:'Start a new invasion?',remaining:'remaining',crew:'in the field',largest:'largest army'},
    ar:{title:'غزو السرب',pause:'إيقاف',home:'الرئيسية',resume:'استكمال',newrun:'غزوة جديدة',attack:'اهجم',auto:'تشكيل تلقائي',undo:'تراجع',favorite:'حفظ الخط',line:'خط',arc:'قوس',circle:'دائرة',troops:'احتياط',draw:'اختر حشرة ثم ارسم خطًا أو قوسًا أو دائرة في أسفل الورقة.',fight:'اهزم الدفاعات والتهم الطعام معًا.',food:'الطعام',towers:'الدفاعات',repair:'ترميم جيش الورق',choose:'اختر ترميمًا واحدًا',heal:'استعادة الصحة',reinforce:'تعزيزات جديدة',damage:'فكوك أقوى',march:'الفتات يتقدم…',defeat:'نفدت قوة الجيش',report:'تقرير الغزوة',foods:'أطعمة ملتهمة',broken:'دفاعات مدمرة',distance:'مناطق تم بلوغها',best:'أفضل نتيجة',exit:'سيبقى تقدمك محفوظًا. العودة للرئيسية؟',yes:'خروج',no:'بقاء',health:'الجيش',command:'أمر',attackOrder:'هجوم',protect:'حماية',flank:'التفاف',selected:'محدد',welcome:'تشكيلة البداية خاصة بالغزوة؛ لا تغيّر الملكية أو العملات أو الترقيات الدائمة. التشكيلة المتنوعة أفضل من الاندفاع.',foodDone:'تم التهام الطعام',towersDone:'سقطت الدفاعات',round:'منطقة',saved:'تم حفظ التشكيل',none:'لا يوجد تشكيل بعد',resumeTitle:'غزوتك بانتظارك',newTitle:'بدء غزوة جديدة؟',remaining:'احتياط',crew:'في الميدان',largest:'أكبر جيش'}
  };
  var allLang={
    fr:['Invasion en essaim','Pause','Accueil','Reprendre','Nouvelle partie','Attaquer','Auto','Annuler','Garder','Ligne','Arc','Cercle','en réserve','Choisissez un insecte puis dessinez dans le bas.','Détruisez les défenses et mangez le goûter.','Goûter','Défenses','Réparer l’essaim','Choisissez une réparation','Soigner','Renforts','Mâchoires fortes','Les miettes avancent…','L’essaim est épuisé','Bilan','goûters mangés','défenses détruites','zones atteintes','record'],
    es:['Invasión en enjambre','Pausa','Inicio','Continuar','Nueva partida','Atacar','Auto','Deshacer','Guardar','Línea','Arco','Círculo','en reserva','Elige un insecto y dibuja abajo.','Derriba las defensas y come el tentempié.','Tentempié','Defensas','Reparar el enjambre','Elige una reparación','Curar','Refuerzos','Mandíbulas fuertes','Las migas avanzan…','El enjambre se agotó','Informe','tentempiés comidos','defensas destruidas','zonas alcanzadas','récord'],
    de:['Schwarmangriff','Pause','Start','Fortsetzen','Neuer Lauf','Angreifen','Auto','Zurück','Speichern','Linie','Bogen','Kreis','Reserve','Insekt wählen und unten zeichnen.','Verteidigung besiegen und Snack essen.','Snack','Verteidigung','Schwarm flicken','Eine Reparatur wählen','Heilen','Verstärkung','Stärkere Kiefer','Die Krümel marschieren…','Schwarm erschöpft','Laufbericht','Snacks gegessen','Verteidigung zerstört','Zonen erreicht','Bestwert'],
    it:['Invasione dello sciame','Pausa','Casa','Riprendi','Nuova partita','Attacca','Auto','Annulla','Salva','Linea','Arco','Cerchio','in riserva','Scegli un insetto e disegna in basso.','Abbatti le difese e mangia lo snack.','Snack','Difese','Ripara lo sciame','Scegli una riparazione','Cura','Rinforzi','Mascelle forti','Le briciole avanzano…','Sciame esausto','Resoconto','snack mangiati','difese distrutte','zone raggiunte','record'],
    pt:['Invasão de enxame','Pausa','Início','Retomar','Novo jogo','Atacar','Auto','Desfazer','Salvar','Linha','Arco','Círculo','na reserva','Escolha um inseto e desenhe abaixo.','Derrube defesas e coma o lanche.','Lanche','Defesas','Reparar o enxame','Escolha um reparo','Curar','Reforços','Mandíbulas fortes','As migalhas marcham…','Enxame esgotado','Relatório','lanches comidos','defesas destruídas','zonas alcançadas','recorde'],
    ru:['Нашествие роя','Пауза','Домой','Продолжить','Новый забег','Атаковать','Авто','Отмена','Сохранить','Линия','Дуга','Круг','в резерве','Выберите жука и рисуйте внизу.','Сломайте защиту и съешьте угощение.','Угощение','Защита','Починить рой','Выберите ремонт','Лечение','Подкрепление','Острые челюсти','Крошки идут…','Рой истощён','Отчёт','съедено','защит уничтожено','зон пройдено','рекорд'],
    tr:['Sürü istilası','Duraklat','Ana sayfa','Sürdür','Yeni koşu','Saldır','Oto','Geri al','Kaydet','Çizgi','Yay','Daire','yedekte','Bir böcek seçip aşağıya çiz.','Savunmayı yık ve atıştırmalığı ye.','Atıştırmalık','Savunma','Sürüyü onar','Bir onarım seç','İyileştir','Takviye','Güçlü çeneler','Kırıntılar ilerliyor…','Sürü tükendi','Koşu raporu','yenilen atıştırmalık','yıkılan savunma','ulaşılan bölge','rekor'],
    ja:['群れの侵攻','一時停止','ホーム','再開','新しい侵攻','攻撃','自動','戻す','保存','線','弧','円','予備','虫を選び、下側に描いてください。','防衛を壊しておやつを食べよう。','おやつ','防衛','群れを修復','修復を1つ選択','回復','増援','強いあご','パンくずが進む…','群れが尽きた','記録','食べたおやつ','破壊した防衛','到達ゾーン','最高記録'],
    zh:['虫群入侵','暂停','主页','继续','新一轮','进攻','自动','撤销','保存','直线','弧线','圆形','预备','选择昆虫并在下方绘制。','摧毁防御并吃掉点心。','点心','防御','修补虫群','选择一项修复','治疗','增援','锋利颚齿','碎屑正在前进…','虫群已耗尽','战报','吃掉的点心','摧毁的防御','到达区域','最佳纪录'],
    ko:['군단 침공','일시 정지','홈','계속','새 침공','공격','자동','취소','저장','선','호','원','예비','곤충을 고르고 아래에 그리세요.','방어를 부수고 간식을 먹으세요.','간식','방어','군단 수리','수리 하나 선택','치료','지원군','강한 턱','부스러기가 전진합니다…','군단 소진','기록','먹은 간식','부순 방어','도달 구역','최고 기록']
  };
  var keys=['title','pause','home','resume','newrun','attack','auto','undo','favorite','line','arc','circle','troops','draw','fight','food','towers','repair','choose','heal','reinforce','damage','march','defeat','report','foods','broken','distance','best'];
  var state=null,ui=null,raf=0,last=0,lastSave=0,quality='high',rafRunning=false;
  var attackMode='manual'; // User choice persists separately from run data.
  function readAttackMode(){try{return localStorage.getItem('pp_swarm_attack_mode')==='auto'?'auto':'manual';}catch(e){return 'manual';}}
  function setAttackMode(mode){attackMode=mode==='auto'?'auto':'manual';try{localStorage.setItem('pp_swarm_attack_mode',attackMode);}catch(e){}if(ui&&ui.modeButton){ui.modeButton.textContent=attackMode==='auto'?(langCode()==='ar'?'⚡ هجوم تلقائي':'⚡ Auto attack'):(langCode()==='ar'?'✋ هجوم يدوي':'✋ Manual attack');ui.modeButton.setAttribute('aria-pressed',String(attackMode==='auto'));}if(attackMode==='auto'&&state&&state.phase==='plan'&&state.starterChosen)autoAssault();}
  function autoAssault(){if(!state||state.phase!=='plan'||!state.starterChosen)return;if(!alive().some(function(a){return a.role!=='medic';}))autoDeploy();if(alive().some(function(a){return a.role!=='medic';}))startFight();}
  function langCode(){try{return (window.PPSwarmBridge&&window.PPSwarmBridge.getLanguage())||localStorage.getItem('pp_lang')||'en';}catch(e){return 'en';}}
  function tr(key){var l=langCode();if(l==='ar')return strings.ar[key]||strings.en[key];if(strings.en[key]){if(l==='en')return strings.en[key];if(allLang[l]){var i=keys.indexOf(key);if(i>=0&&allLang[l][i])return allLang[l][i];}return strings.en[key];}return strings.en[key]||key;}
  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y);}
  // Geometry engine: density is proportional to area for filled shapes and length for paths.
  function formationSlots(role,shape,a,b,box){
    var spec=ROLES[role];if(!spec||!a||!b)return [];
    var dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),step=spec.spacing,pts=[];
    var cx=a.x,cy=a.y,r=clamp(len,18,Math.min(box.w,box.h)*.43);
    function point(x,y){pts.push({x:x,y:y});}
    function disk(x,y,rx,ry){
      for(var yy=-ry;yy<=ry;yy+=step*.87){var row=Math.round((yy+ry)/(step*.87));
        for(var xx=-rx;xx<=rx;xx+=step){var px=xx+(row%2)*step*.5;if((px/rx)**2+(yy/ry)**2<=.95)point(x+px,y+yy);}
      }
    }
    if(shape==='circle'||shape==='ellipse')disk(cx,cy,r,shape==='ellipse'?r*.56:r);
    else if(shape==='rectangle'||shape==='square'){
      var ww=shape==='square'?r:r*1.6,hh=shape==='square'?r:r*.7;
      for(var y=-hh;y<=hh;y+=step*.88)for(var x=-ww;x<=ww;x+=step)point(cx+x+(Math.round(y/step)%2)*step*.35,cy+y);
    }else if(shape==='triangle'){
      for(var yy=0;yy<=r*1.65;yy+=step*.86){var half=yy/1.65;
        for(var xx=-half;xx<=half;xx+=step)point(cx+xx,cy-r*.8+yy);
      }
    }else if(shape==='arc'||shape==='semicircle'){
      var n=Math.max(2,Math.floor(Math.PI*r/step));
      for(var j=0;j<n;j++){var t=j/(n-1),theta=Math.PI*(1+t)+Math.atan2(dy,dx);point(cx+Math.cos(theta)*r,cy+Math.sin(theta)*r);}
    }else if(shape==='v'||shape==='zigzag'){
      var vertices=shape==='v'?[{x:cx-r,y:cy+r*.6},{x:cx,y:cy-r*.6},{x:cx+r,y:cy+r*.6}]:[{x:cx-r,y:cy-r*.5},{x:cx-r/3,y:cy+r*.5},{x:cx+r/3,y:cy-r*.5},{x:cx+r,y:cy+r*.5}];
      for(var k=1;k<vertices.length;k++){var u=vertices[k-1],v=vertices[k],nseg=Math.max(2,Math.floor(dist(u,v)/step));for(var t=0;t<nseg;t++)point(u.x+(v.x-u.x)*t/(nseg-1),u.y+(v.y-u.y)*t/(nseg-1));}
    }else{
      var nline=Math.max(1,Math.floor(len/step));for(var i=0;i<nline;i++){var t=nline===1?.5:i/(nline-1);point(a.x+dx*t,a.y+dy*t);}
    }
    var safe=pts.filter(function(p){return p.x>=box.x+spec.r&&p.x<=box.x+box.w-spec.r&&p.y>=box.y+spec.r&&p.y<=box.y+box.h-spec.r;});
    var result=[];safe.forEach(function(p){if(result.every(function(q){return dist(p,q)>=spec.r*2+2;}))result.push(p);});return result;
  }
  function recognizeGesture(points){
    if(!points||points.length<3)return 'line';
    var first=points[0],last=points[points.length-1],length=0,minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    points.forEach(function(p,i){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);if(i)length+=dist(p,points[i-1]);});
    var width=maxX-minX,height=maxY-minY,span=Math.hypot(width,height);
    if(span<22||length<span*1.14)return 'line';
    var closed=dist(first,last)<span*.25,ratio=Math.max(width,height)/Math.max(1,Math.min(width,height));
    // Resample by travelled distance: sharp corners must not be counted repeatedly.
    var sample=[points[0]],step=Math.max(8,length/28),carry=0;
    for(var i=1;i<points.length;i++){var from=points[i-1],to=points[i],seg=dist(from,to);if(!seg)continue;var at=step-carry;while(at<=seg){sample.push({x:from.x+(to.x-from.x)*at/seg,y:from.y+(to.y-from.y)*at/seg});at+=step;}carry=seg-(at-step);}
    sample.push(last);
    var corners=0,signChanges=0,lastSign=0;
    for(var j=2;j<sample.length-2;j+=2){var p0=sample[j-2],p1=sample[j],p2=sample[j+2],a1=Math.atan2(p1.y-p0.y,p1.x-p0.x),a2=Math.atan2(p2.y-p1.y,p2.x-p1.x),turn=Math.atan2(Math.sin(a2-a1),Math.cos(a2-a1));if(Math.abs(turn)>.66)corners++;if(Math.abs(turn)>.45){var sign=Math.sign(turn);if(lastSign&&sign!==lastSign)signChanges++;lastSign=sign;}}
    if(closed){if(corners>=3&&corners<=6){if(corners<=3)return 'triangle';return ratio<1.25?'square':'rectangle';}return ratio>1.48?'ellipse':'circle';}
    if(signChanges>=2&&length>span*1.65)return 'zigzag';
    if(corners>=1&&corners<=3&&length>span*1.22)return 'v';
    if(length>span*1.2)return 'arc';return 'line';
  }
  function gestureEndpoints(points,shape){
    if(['circle','ellipse','rectangle','square','triangle','arc','semicircle','v','zigzag'].indexOf(shape)>=0){
      var minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
      points.forEach(function(p){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);});
      var center={x:(minX+maxX)/2,y:(minY+maxY)/2};
      return [center,{x:center.x+Math.max(18,Math.max(maxX-minX,maxY-minY)*.5),y:center.y}];
    }
    return [points[0],points[points.length-1]];
  }
  var FORM_SHAPES=['auto','line','arc','circle','ellipse','rectangle','square','triangle','v','zigzag'];
  var SHAPE_LABELS={auto:['تلقائي','Auto'],line:['خط','Line'],arc:['قوس','Arc'],circle:['دائرة','Circle'],ellipse:['بيضاوي','Ellipse'],rectangle:['مستطيل','Rectangle'],square:['مربع','Square'],triangle:['مثلث','Triangle'],v:['حرف V','V'],zigzag:['متعرج','Zigzag']};
  function shapeLabel(k){return (SHAPE_LABELS[k]||SHAPE_LABELS.auto)[langCode()==='ar'?0:1];}
  var PROGRESS_KEY='pp_swarm_growth_v2';
  function growth(){try{var g=JSON.parse(localStorage.getItem(PROGRESS_KEY)||'null');return g&&Number.isFinite(g.level)?g:{level:0,best:0};}catch(e){return {level:0,best:0};}}
  // Permanent, run-earned specialization: separate troop levels, no premium currency.
  var ROLE_PROGRESS_KEY='pp_swarm_role_levels_v1';
  function roleProgress(){try{var x=JSON.parse(localStorage.getItem(ROLE_PROGRESS_KEY)||'{}');return {points:clamp(Number(x.points)||0,0,999),levels:Object.fromEntries(Object.keys(ROLES).map(function(k){return [k,clamp(Math.floor(Number(x.levels&&x.levels[k])||0),0,8)];}))};}catch(e){return {points:0,levels:{worker:0,armor:0,breaker:0,medic:0}};}}
  function storeRoleProgress(p){try{localStorage.setItem(ROLE_PROGRESS_KEY,JSON.stringify(p));}catch(e){}}
  function roleLevel(role){return roleProgress().levels[role]||0;}
  function upgradeCost(role){return 2+roleLevel(role)*2;}
  function buyRoleUpgrade(role){if(!ROLES[role])return false;var p=roleProgress(),cost=upgradeCost(role);if(p.points<cost||p.levels[role]>=8)return false;p.points-=cost;p.levels[role]++;storeRoleProgress(p);return true;}
  function troopSpec(role){var base=ROLES[role],lv=roleLevel(role);return {hp:Math.round(base.hp*(1+.075*lv)),power:base.power*(1+.055*lv),eat:base.eat*(1+.04*lv),heal:base.heal*(1+.06*lv),speed:base.speed*(1+.015*lv)};}
  function awardRolePoints(){if(!state||state.rolePointsAwarded)return;var points=Math.min(12,Math.max(1,Math.floor((state.foods||0)/2)+Math.floor((state.towersBroken||0)/5)));var p=roleProgress();p.points=Math.min(999,p.points+points);storeRoleProgress(p);state.rolePointsAwarded=points;}
  function starterBudget(){return Math.min(65,30+growth().level*3);}
  function recordGrowth(){if(!state||state.growthRecorded)return;var g=growth();g.best=Math.max(g.best,state.zone);g.level=Math.min(11,Math.max(g.level,Math.floor(state.foods/2)));try{localStorage.setItem(PROGRESS_KEY,JSON.stringify(g));}catch(e){}awardRolePoints();state.growthRecorded=true;}
  function starterRoster(){return {worker:18,armor:6,breaker:4,medic:2};}
  function starterSelection(){var total=Object.keys(state.reserve).reduce(function(n,k){return n+state.reserve[k];},0);return {total:total,budget:starterBudget()};}
  function newRun(){
    var roster=starterRoster();
    var favorite=null;try{favorite=JSON.parse(localStorage.getItem('pp_swarm_favorite_v1')||'null');}catch(e){}
    return {v:1,viewVersion:2,runId:'run-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),phase:'plan',zone:0,camera:0,army:[],reserve:roster,formations:[],favorite:favorite,selected:'worker',shape:'auto',command:'attack',foodHp:100,towers:[],foodEaten:0,towersBroken:0,foods:0,largest:30,distance:0,repairTaken:false,offer:null,upgrades:{damage:1},seed:779,paused:false,simTime:0,stats:{lost:0},zoneStart:0};
  }
  function towerSet(zone){
    var base=zone*760,hard=Math.max(0,Math.floor(zone*.42)), count=zone%7===5?4:zone%5===3?2:3;
    var kinds=['gun','flame','spray','glue'];var towers=[];
    for(var i=0;i<count;i++)towers.push({id:'z'+zone+'t'+i,kind:kinds[(i+zone)%4],x:(count===4?[.17,.39,.61,.83]:count===2?[.32,.68]:[.24,.5,.76])[i],y:base+390+(i%2)*38,hp:46+hard*6+(zone>=4&&zone%5===4&&i===0?28:0),maxHp:46+hard*6+(zone>=4&&zone%5===4&&i===0?28:0),cd:1.2+i*.48,alive:true,ai:zone>=2?1:0,elite:zone>=4&&zone%5===4&&i===0});
    return towers;
  }
  function serialize(){return JSON.stringify(state,function(key,value){if(key==='units'&&Array.isArray(value))return value.map(function(u){return typeof u==='object'?u.id:u;});return value;});}
  function save(force){if(!state)return;var now=Date.now();if(!force&&now-lastSave<1700)return;lastSave=now;try{localStorage.setItem(SAVE_KEY,serialize());return true;}catch(e){if(ui&&ui.hint)ui.hint.textContent=langCode()==='ar'?'تعذر الحفظ على هذا الجهاز. لا تغلق اللعبة الآن.':'Saving failed on this device. Keep the game open.';return false;}}
  function validSave(o){
    return !!o&&o.v===1&&['plan','fight','march','repair','defeat'].indexOf(o.phase)>=0&&Number.isInteger(o.zone)&&o.zone>=0&&Number.isFinite(o.camera)&&Number.isFinite(o.foodHp)&&o.foodHp>=0&&o.foodHp<=100&&o.reserve&&Object.keys(ROLES).every(function(k){return Number.isInteger(o.reserve[k])&&o.reserve[k]>=0&&o.reserve[k]<=CAP;})&&Array.isArray(o.army)&&o.army.length<=CAP&&o.army.every(function(u){return u&&ROLES[u.role]&&Number.isFinite(u.x)&&Number.isFinite(u.y)&&Number.isFinite(u.hp)&&Number.isFinite(u.maxHp)&&u.maxHp>0;})&&Array.isArray(o.towers)&&o.towers.length<=4&&o.towers.every(function(t){return t&&['gun','flame','spray','glue'].indexOf(t.kind)>=0&&Number.isFinite(t.x)&&Number.isFinite(t.y)&&Number.isFinite(t.hp)&&Number.isFinite(t.maxHp)&&t.maxHp>0;})&&o.upgrades&&Number.isFinite(o.upgrades.damage)&&o.stats&&Array.isArray(o.formations);
  }
  function hydrate(o){
    o.formations=(o.formations||[]).map(function(f){f.units=(f.units||[]).map(function(ref){var id=typeof ref==='object'?ref.id:ref;return o.army.find(function(u){return u.id===id;});}).filter(Boolean);return f;}).filter(function(f){return f.units.length>0;});
    o.army.forEach(function(u){u.atk=Number.isFinite(u.atk)?u.atk:0;u.food=Number.isFinite(u.food)?u.food:0;u.healCd=Number.isFinite(u.healCd)?u.healCd:0;});
    return o;
  }
  function load(){try{var o=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');return validSave(o)?hydrate(o):null;}catch(e){return null;}}
  function totalReserve(){return Object.keys(ROLES).reduce(function(n,k){return n+(state.reserve[k]||0);},0);}
  function alive(){return state.army.filter(function(a){return a.hp>0;});}
  function effective(){return state.army.some(function(a){return a.hp>0&&(ROLES[a.role].power>0||ROLES[a.role].eat>0);});}
  function makeOffers(){
    var losses=state.stats.lost||0,crew=state.army.filter(function(a){return a.hp>0;}).length,ar=langCode()==='ar';
    var pct=crew<12||losses>8?.42:.35;
    var hurt=state.army.some(function(a){return a.hp<a.maxHp*.95;});
    var harden={id:'harden',title:ar?'دروع أكثر متانة':'Harder shells',text:ar?'صحة الناجين القصوى +12%':'Survivor maximum health +12%',run:function(){state.army.forEach(function(a){var extra=a.maxHp*.12;a.maxHp+=extra;a.hp+=extra;});}};
    var heal={id:'heal',title:tr('heal'),text:'+'+Math.round(pct*100)+(ar?'% من صحة الناجين':'% survivor health'),run:function(){state.army.forEach(function(a){a.hp=Math.min(a.maxHp,a.hp+a.maxHp*pct);});}};
    var reinforce={id:'reinforce',title:tr('reinforce'),text:ar?'+6 عاملات · +2 مدرعة':'+6 workers · +2 armor',run:function(){addReserve('worker',6);addReserve('armor',2);}};
    var damage={id:'damage',title:tr('damage'),text:ar?'ضرر الجيش +15% خلال الغزوة':'Army damage +15% this invasion',run:function(){state.upgrades.damage=Math.min(4,(state.upgrades.damage||1)*1.15);}};
    var pace={id:'pace',title:ar?'خطوات أخف':'Lighter steps',text:ar?'سرعة الجيش +8% خلال الغزوة':'Army movement +8% this invasion',run:function(){state.upgrades.speed=Math.min(1.4,(state.upgrades.speed||1)*1.08);}};
    var room=CAP-alive().length-totalReserve();
    return [hurt?heal:harden,room>0?reinforce:pace,state.zone%2&&(state.upgrades.speed||1)<1.4?pace:damage].filter(function(o,index,array){return array.findIndex(function(p){return p.id===o.id;})===index;}).concat(room<=0?[damage]:[]).slice(0,3);
  }
  function addReserve(role,count){
    var room=Math.max(0,CAP-alive().length-totalReserve());
    state.reserve[role]=(state.reserve[role]||0)+Math.min(room,count);
  }
  function applyRepair(id){
    if(state.phase!=='repair'||state.repairTaken)return false;
    if(!(state.offer||[]).some(function(o){return o.id===id;}))return false;
    var option=makeOffers().filter(function(o){return o.id===id;})[0];if(!option)return false;
    option.run();state.repairTaken=true;state.offer=null;
    if(state.marchDone){finishMarch();}else{state.phase='march';}
    save(true);return true;
  }
  function finishMarch(){state.zone++;state.distance=state.zone;zoneInit();return state.zone;}
  function ensureInitial(){hydrate(state);}
  function addFormation(role,shape,points){
    if(state.phase!=='plan'&&state.phase!=='fight')return null;
    var active=state.army.filter(function(a){return a.hp>0;}).length;
    if(active>=CAP)return null;
    var box=ui.deployBox(),slots=formationSlots(role,shape,points[0],points[1],box);
    var available=Math.min(state.reserve[role]||0,CAP-active);
    slots=slots.slice(0,available);
    if(!slots.length)return null;
    var spec=ROLES[role],boost=troopSpec(role),base=(state.zone*760);
    var formation={id:Date.now()+Math.random(),role:role,shape:shape,command:state.command,units:[]};
    slots.forEach(function(p,i){
      var world=worldPoint(p.x,p.y);
      // reject overlap against every deployed body, not just members of this drawing
      if(state.army.some(function(u){return u.hp>0&&Math.hypot((u.x-world.x)*ui.w,u.y-world.y)<ROLES[u.role].r+spec.r+4;}))return;
      var unit={id:Date.now()+i+Math.random(),role:role,x:world.x,y:world.y,hp:boost.hp,maxHp:boost.hp,formation:formation.id,command:state.command,target:null,atk:0,food:0,healCd:0};
      formation.units.push(unit);state.army.push(unit);
    });
    var placed=formation.units.length;state.reserve[role]-=placed;
    if(!placed)return null;
    state.formations.push(formation);state.largest=Math.max(state.largest,state.army.filter(function(u){return u.hp>0;}).length);
    save(true);return {formation:formation,count:placed,reserve:state.reserve[role]};
  }
  function calculateReward(){
    var total=state.foods*4+state.towersBroken*2+Math.floor(state.zone*1.5),coins=Math.max(0,Math.min(300,total));
    var key='pp_swarm_settled_v1',settled={};try{settled=JSON.parse(localStorage.getItem(key)||'{}')||{};}catch(e){}
    var runId=state.runId||'run-'+state.zone+'-'+state.foods+'-'+state.towersBroken;
    if(state.rewardSettled||settled[runId]){state.rewardCoins=state.rewardCoins||(typeof settled[runId]==='number'?settled[runId]:coins);state.rewardSettled=true;return state.rewardCoins;}
    settled[runId]=coins||true;var ids=Object.keys(settled);while(ids.length>40)delete settled[ids.shift()];try{localStorage.setItem(key,JSON.stringify(settled));}catch(e){}
    state.rewardCoins=coins;state.rewardSettled=true;
    try{var best=+(localStorage.getItem('pp_swarm_best_v1')||0);state.personalBest=Math.max(best,state.zone);localStorage.setItem('pp_swarm_best_v1',String(state.personalBest));}catch(e){}
    if(window.PPSwarmBridge)window.PPSwarmBridge.rewardCoins(coins);
    return coins;
  }
  function zoneInit(){
    var base=state.zone*760;state.zoneStart=base;state.foodHp=100;state.towers=towerSet(state.zone);state.repairTaken=false;state.phase='plan';state.offer=null;
    state.camera=base;state.nextTowers=null;state.nextZone=null;state.marchDone=false;state.zoneClear=false;
    state.formations=state.formations.filter(function(f){f.units=f.units.filter(function(u){return u.hp>0;});return f.units.length>0;});
    state.army.forEach(function(a){a.target=null;a.food=0;});
    addReserve('worker',2);
    state.largest=Math.max(state.largest,alive().length+totalReserve());save(true);
  }
  function stop(){if(raf){cancelAnimationFrame(raf);raf=0;}rafRunning=false;}
  function startLoop(){if(rafRunning)return;rafRunning=true;last=0;raf=requestAnimationFrame(loop);}
  function loop(ts){if(!state||!ui||ui.root.hidden){stop();return;}raf=requestAnimationFrame(loop);if(!last)last=ts;var dt=Math.min(.04,(ts-last)/1000);last=ts;if(!state.paused)update(dt);if(!ui.hudAt||ts-ui.hudAt>160){updateHud();ui.hudAt=ts;}draw();save(false);}
  function update(dt){
    // Drawing is the action: no separate bottom Attack button is required.
    // Planning remains open until the player explicitly starts the assault.
    if(state.phase==='plan'&&attackMode==='auto'&&state.starterChosen)autoAssault();
    if(state.phase==='fight')simulateFight(dt);
    if(state.phase==='march'||state.phase==='repair'&&state.zoneClear&&!state.marchDone)simulateMarch(dt);
  }
  function simulateFight(dt){
    var towers=state.towers.filter(function(t){return t.alive;});
    // Fixed tower cadence prevents a larger crowd from silently accelerating defense damage.
    towers.forEach(function(t){
      t.cd-=dt;if(t.cd>0)return;
      var candidates=state.army.filter(function(u){return u.hp>0&&Math.hypot((u.x-t.x)*ui.w,u.y-t.y)<(t.kind==='spray'?118:104);})
        .sort(function(a,b){var da=Math.hypot((a.x-t.x)*ui.w,a.y-t.y),db=Math.hypot((b.x-t.x)*ui.w,b.y-t.y);if(t.ai){var priority=function(u){if(t.kind==='gun')return u.role==='medic'?32:u.role==='breaker'?22:0;if(t.kind==='spray')return u.role==='worker'?12:0;if(t.kind==='flame')return u.role==='armor'?15:0;if(t.kind==='glue')return u.role==='breaker'?18:0;return 0;};da-=priority(a);db-=priority(b);}return da-db;});
      if(!candidates.length)return;
      t.cd=t.kind==='flame'?1.15:t.kind==='spray'?1.7:t.kind==='glue'?1.8:1.55;
      t.fireAt=state.simTime;
      var harm=(t.elite?1.15:1)*(t.kind==='flame'?5:t.kind==='spray'?3.5:t.kind==='glue'?0:7)*(1+Math.min(1.2,state.zone*.065));
      var victims=t.kind==='spray'?candidates.slice(0,4):t.kind==='flame'?candidates.filter(function(v){return Math.hypot((v.x-t.x)*ui.w,v.y-t.y)<65;}).slice(0,3):candidates.slice(0,1);
      victims.forEach(function(v){
        var shield=state.army.some(function(a){return a!==v&&a.hp>0&&a.role==='armor'&&a.y>=v.y-8&&Math.hypot((a.x-v.x)*ui.w,a.y-v.y)<62;})?.78:1;
        v.hp-=harm*shield*(v.role==='armor'?.62:1);
        if(t.kind==='glue')v.slowUntil=(state.simTime||0)+1.4;
      });
    });
    state.army.forEach(function(u){
      if(u.hp<=0)return;
      var role=ROLES[u.role],boost=troopSpec(u.role);
      if(role.heal){u.healCd-=dt;if(u.healCd<=0){u.healCd=1.35;var friend=state.army.filter(function(a){return a.hp>0&&a.hp<a.maxHp&&a!==u;}).sort(function(a,b){return Math.hypot((a.x-u.x)*ui.w,a.y-u.y)-Math.hypot((b.x-u.x)*ui.w,b.y-u.y);})[0];if(friend&&Math.hypot((friend.x-u.x)*ui.w,friend.y-u.y)<72)friend.hp=Math.min(friend.maxHp,friend.hp+boost.heal);}}
      var tower=null,nearest=Infinity;
      towers.forEach(function(t){if(!t.alive)return;var d=Math.hypot((t.x-u.x)*ui.w,t.y-u.y);if(t.id===u.target)d=-1;if(d<nearest){nearest=d;tower=t;}});
      var attackTower=!!tower&&(u.role!=='worker'||u.target||state.foodHp<=0);
      var tx=attackTower?tower.x:.5,ty=attackTower?tower.y:state.zone*760+490;
      if(u.role==='medic'&&towers.length){
        var front=state.army.find(function(a){return a.hp>0&&a.role!=='medic';});
        if(front){tx=front.x;ty=front.y-30;attackTower=false;}
      }
      if(u.command==='protect'&&u.role!=='armor'&&tower&&!u.target){
        var tank=state.army.find(function(a){return a.hp>0&&a.role==='armor';});
        if(tank&&tank.y<state.zone*760+450){tx=tank.x;ty=tank.y-26;attackTower=false;}
      }
      if(u.command==='flank'&&tower&&u.y<tower.y-35){
        tx=u.x<.5?.1:.9;ty=tower.y+36;attackTower=false;
      }
      // Cohesion: retain lateral formation spacing while approaching, then release
      // units close to their target so they can surround and attack it.
      var squad=state.formations.find(function(f){return f.id===u.formation;});
      if(squad&&squad.units&&squad.units.length>1){
        var living=squad.units.filter(function(v){return v.hp>0;});
        var rank=living.indexOf(u),n=living.length;
        if(rank>=0&&n>1){
          var lateral=(rank-(n-1)/2)*Math.min(ROLES[u.role].spacing*.70,13);
          var approach=Math.hypot((tx-u.x)*ui.w,ty-u.y);
          var influence=clamp((approach-46)/115,0,1);
          // Lateral slots are centered on the objective, so formation doesn't
          // collapse into a single pixel during the march.
          tx=clamp(tx+lateral/ui.w*influence,.055,.945);
        }
      }
      var dx=(tx-u.x)*ui.w,dy=ty-u.y,d=Math.hypot(dx,dy);
      u.facing=Math.atan2(dy,dx);
      if(d>29){
        var slow=u.slowUntil>state.simTime?.56:1,step=Math.min(d,boost.speed*dt*slow*(state.upgrades.speed||1));
        u.x=clamp(u.x+dx/Math.max(d,.001)*step/ui.w,.035,.965);u.y+=dy/Math.max(d,.001)*step;
      }else if(attackTower&&tower.alive){
        u.atk-=dt;if(u.atk<=0){u.atk=role.power>3?.85:.65;tower.hp-=boost.power*(state.upgrades.damage||1);if(tower.hp<=0){tower.hp=0;tower.alive=false;state.towersBroken++;state.army.forEach(function(a){if(a.target===tower.id)a.target=null;});fx(tower.x,tower.y,'paper');}}
      }else if(state.foodHp>0&&Math.hypot((.5-u.x)*ui.w,state.zone*760+490-u.y)<36){
        u.food-=dt;if(u.food<=0){u.food=.6;state.foodHp=Math.max(0,state.foodHp-boost.eat*(u.role==='worker'?1:.34));fx(.5,state.zone*760+490,'crumb');}
      }
    });
    // Bounded local separation keeps a 64-unit army from collapsing into a single dot.
    for(var ai=0;ai<state.army.length;ai++)for(var bi=ai+1;bi<state.army.length;bi++){
      var a=state.army[ai],b=state.army[bi];if(a.hp<=0||b.hp<=0)continue;
      var sx=(b.x-a.x)*ui.w,sy=b.y-a.y,sd=Math.hypot(sx,sy),spacing=ROLES[a.role].r+ROLES[b.role].r;
      if(sd<spacing){if(sd<.01){sx=1;sy=0;sd=1;}var push=Math.min(spacing-sd,45*dt)*.5;a.x=clamp(a.x-sx/sd*push/ui.w,.035,.965);b.x=clamp(b.x+sx/sd*push/ui.w,.035,.965);a.y-=sy/sd*push;b.y+=sy/sd*push;}
    }
    state.simTime=(state.simTime||0)+dt;
    state.army=state.army.filter(function(a){if(a.hp<=0){state.stats.lost++;return false;}return true;});
    if(!state.foodHp&&state.foodCountedZone!==state.zone){state.foodCountedZone=state.zone;state.foods++;}
    if(!state.towers.some(function(t){return t.alive;})&&state.foodHp<=0){
      state.marchTime=0;state.marchOrigin=state.camera;state.marchTarget=(state.zone+1)*760;state.zoneClear=true;state.marchDone=false;
      state.nextZone=state.zone+1;state.nextTowers=towerSet(state.nextZone);
      var live=alive();live.forEach(function(a,i){a.marchX=.16+(i%9)*.084;a.marchY=state.marchTarget+viewOrigin(ui.h)-ui.h*.71+Math.floor(i/9)*19;a.marchFromX=a.x;a.marchFromY=a.y;});
      addReserve('worker',Math.max(0,4-(state.reserve.worker||0)));
      state.offer=makeOffers().map(function(o){return {id:o.id,title:o.title,text:o.text};});state.phase='repair';save(true);if(ui.root)paintBanner();return;
    }
    if(!state.army.some(function(u){return u.hp>0&&u.role!=='medic';})&&Object.keys(ROLES).every(function(k){return k==='medic'||!state.reserve[k];})){state.phase='defeat';recordGrowth();calculateReward();save(true);if(ui.root)paintBanner();}
  }
  function simulateMarch(dt){
    state.marchTime=(state.marchTime||0)+dt;
    var progress=clamp(state.marchTime/2.85,0,1),walk=progress*progress*(3-2*progress);
    state.army.forEach(function(a){a.x=(a.marchFromX??a.x)+((a.marchX??a.x)-(a.marchFromX??a.x))*walk;a.y=(a.marchFromY??a.y)+((a.marchY??a.y)-(a.marchFromY??a.y))*walk;});
    // Let the survivors visibly advance first; then ease the camera to the next connected zone.
    if(state.marchTime>.48){var p=clamp((state.marchTime-.48)/2.35,0,1);var ease=p*p*(3-2*p);state.camera=state.marchOrigin+(state.marchTarget-state.marchOrigin)*ease;}
    if(state.marchTime>=2.85){state.camera=state.marchTarget;state.marchDone=true;if(state.repairTaken)finishMarch();}
  }
  function fx(x,y,type){if(!ui)return;ui.particles.push({x:x,y:y,type:type,age:0,life:.6+Math.random()*.4});if(ui.particles.length>55)ui.particles.shift();}
  function viewOrigin(h){return ui&&Number.isFinite(ui.viewOrigin)?ui.viewOrigin:625;}
  function worldPoint(x,y){return {x:x/ui.w,y:viewOrigin(ui.h)-y+state.camera};}
  function migrateView(o,h,origin){
    if(o.viewVersion===2)return false;
    var shift=origin-h;
    o.army.forEach(function(a){a.y+=shift;if(Number.isFinite(a.marchY))a.marchY+=shift;if(Number.isFinite(a.marchFromY))a.marchFromY+=shift;});
    o.viewVersion=2;return true;
  }
  function draw(){
    if(!ui)return;var c=ui.ctx,w=ui.w,h=ui.h,dpr=ui.dpr;
    c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
    var cam=state.camera,base=state.zone*760,paper=['#e8e3d2','#e7e7d7','#e9dfd0','#e1e9df'];
    c.fillStyle=paper[state.zone%paper.length];c.fillRect(0,0,w,h);
    // Soft paper lighting and subtle fibers; drawn procedurally without image downloads.
    var light=c.createLinearGradient(0,0,w,h);light.addColorStop(0,'rgba(255,255,246,.22)');light.addColorStop(.65,'rgba(255,255,255,0)');light.addColorStop(1,'rgba(102,75,43,.08)');c.fillStyle=light;c.fillRect(0,0,w,h);
    c.fillStyle='rgba(108,83,52,.045)';for(var fi=0;fi<32;fi++){var fx0=((fi*97+state.zone*13)%997)/997*w,fy0=((fi*157+Math.floor(cam/15)*3)%991)/991*h;c.fillRect(fx0,fy0,1.5,1.5);}
    c.strokeStyle='rgba(114,151,177,.19)';c.lineWidth=1;
    for(var gy=(((cam%34)+34)%34)-34;gy<h;gy+=34){c.beginPath();c.moveTo(0,gy);c.lineTo(w,gy);c.stroke();}
    c.strokeStyle='rgba(196,99,94,.28)';c.lineWidth=1.5;c.beginPath();c.moveTo(w*.105,0);c.lineTo(w*.105,h);c.stroke();
    // Fine paper vignette gives the scene a warmer, more dimensional notebook look.
    var vignette=c.createRadialGradient(w*.5,h*.43,w*.08,w*.5,h*.43,w*.82);
    vignette.addColorStop(0,'rgba(255,255,246,0)');vignette.addColorStop(1,'rgba(114,87,50,.105)');
    c.fillStyle=vignette;c.fillRect(0,0,w,h);
    warmSceneArt();
    drawZoneDecor(c,base,cam,w,h,state.zone);
    var nextZone=Number.isFinite(state.nextZone)?state.nextZone:state.zone+1;
    var nextBase=nextZone*760,nextBoundary=worldY(nextBase,cam,h),hasNext=Array.isArray(state.nextTowers)&&nextBoundary>0&&worldY((nextZone+1)*760,cam,h)<h;
    if(hasNext){
      c.save();c.beginPath();c.rect(0,0,w,Math.min(h,nextBoundary));c.clip();
      c.fillStyle=paper[nextZone%paper.length];c.fillRect(0,0,w,h);
      c.strokeStyle='rgba(102,143,116,.18)';c.lineWidth=1;
      for(var ny=(((cam%34)+34)%34)-34;ny<h;ny+=34){c.beginPath();c.moveTo(0,ny);c.lineTo(w,ny);c.stroke();}
      c.strokeStyle='rgba(196,99,94,.22)';c.beginPath();c.moveTo(w*.105,0);c.lineTo(w*.105,h);c.stroke();
      drawZoneDecor(c,nextBase,cam,w,h,nextZone);
      c.restore();
      c.save();c.strokeStyle='rgba(93,83,69,.32)';c.lineWidth=1.5;c.setLineDash([7,5]);c.beginPath();c.moveTo(0,nextBoundary);c.lineTo(w,nextBoundary);c.stroke();c.setLineDash([]);c.restore();
    }
    state.towers.forEach(function(t){if(t.alive)drawTower(c,t,cam,w,h);});
    drawFood(c,base+490,cam,w,h,state.foodHp,state.zone);
    if(hasNext){
      c.save();c.beginPath();c.rect(0,0,w,Math.min(h,nextBoundary));c.clip();
      state.nextTowers.forEach(function(t){if(t.alive)drawTower(c,t,cam,w,h);});
      drawFood(c,nextBase+490,cam,w,h,100,nextZone);
      c.restore();
    }
    state.army.forEach(function(a){if(a.hp>0)drawBug(c,a,cam,w,h);});
    ui.particles.forEach(function(p){p.age+=.016;var sy=worldY(p.y,cam,h),alpha=Math.max(0,1-p.age/p.life);c.globalAlpha=alpha;c.fillStyle=p.type==='paper'?'#76635b':'#bd7d43';c.save();c.translate(p.x*w,sy);c.rotate(p.age*4);c.fillRect(-2-p.age*3,-2-p.age*3,4+p.age*4,4+p.age*4);c.restore();});c.globalAlpha=1;
    if(ui.drag&&!ui.drag.formation)drawPreview(c,ui.drag,w,h);
    // The unobstructed paper is the attack area; keep only a subtle boundary.
    var box=ui.deployBox();
    if(state.phase==='plan'&&box.h>0){c.strokeStyle='rgba(59,85,67,.16)';c.lineWidth=1;c.setLineDash([4,8]);c.beginPath();c.moveTo(16,box.y);c.lineTo(w-16,box.y);c.stroke();c.setLineDash([]);}
  }
  function worldY(y,camera,h){return viewOrigin(h)-(y-camera);}
  function drawZoneDecor(c,base,cam,w,h,zoneNumber){
    var z=Number.isFinite(zoneNumber)?zoneNumber:state.zone,sy=worldY(base+170,cam,h),colors=['#d2a46d','#cba978','#b5c596','#d8a29a'];
    if(sy<-50||sy>h+55)return;
    c.save();c.fillStyle='rgba(71,54,46,.14)';c.beginPath();c.ellipse(w*.5,sy+7,w*.39,18,0,0,Math.PI*2);c.fill();
    c.fillStyle=colors[z%colors.length];c.strokeStyle='#77624e';c.lineWidth=2.2;c.beginPath();c.ellipse(w*.5,sy,w*.38,16,0,0,Math.PI*2);c.fill();c.stroke();
    c.strokeStyle='rgba(255,247,218,.72)';c.lineWidth=2;c.beginPath();c.ellipse(w*.5,sy,w*.35,11,0,0,Math.PI*2);c.stroke();
    for(var i=0;i<7;i++){var lx=w*(.18+i*.105),ly=sy+Math.sin(z+i)*5;c.fillStyle=i%2?'#76976b':'#8ba97a';c.beginPath();c.ellipse(lx,ly,7,3,i%2?-.38:.38,0,Math.PI*2);c.fill();}
    c.fillStyle='#39463f';c.font='800 10px system-ui';c.textAlign='center';c.fillText(tr('round')+' '+(z+1),w*.5,sy+4);c.textAlign='left';c.restore();
  }
  // Dedicated 2.5D scene sprites. They never replace the other game modes' renderers.
  var sceneArt={};
  function sceneSprite(name){
    if(!sceneArt[name]&&typeof Image!=='undefined'){
      var image=new Image();sceneArt[name]={image:image,ready:false};
      image.onload=function(){sceneArt[name].ready=true;};
      image.onerror=function(){sceneArt[name].ready=false;};
      image.src='assets/swarm-art/'+name+'.svg';
    }
    return sceneArt[name]&&sceneArt[name].ready?sceneArt[name].image:null;
  }
  function warmSceneArt(){
    ['food-cake','food-donut','food-leaf','food-cookie','tower-gun','tower-flame','tower-spray','tower-other'].forEach(sceneSprite);
  }
  function drawFood(c,y,cam,w,h,remainingHp,zoneNumber){
    var sy=worldY(y,cam,h),remain=clamp((Number.isFinite(remainingHp)?remainingHp:state.foodHp)/100,0,1),z=Number.isFinite(zoneNumber)?zoneNumber:state.zone;
    if(sy<-70||sy>h+70)return;
    var sprite=remain>0?sceneSprite('food-'+['cake','donut','leaf','cookie'][z%4]):null;
    if(sprite){
      c.save();c.globalAlpha=.45+.55*remain;
      var scale=.66+.34*remain;c.translate(w*.5,sy);c.scale(scale,scale);
      c.drawImage(sprite,-73,-65,146,122);c.restore();
      c.fillStyle='#44383a';c.font='800 12px system-ui';c.textAlign='center';c.fillText(tr('food'),w*.5,sy+48);c.textAlign='left';
      return;
    }
    c.save();c.translate(w*.5,sy);
    c.fillStyle='rgba(60,43,39,.16)';c.beginPath();c.ellipse(1,25,48,13,0,0,Math.PI*2);c.fill();
    c.fillStyle='#f2ead9';c.strokeStyle='#716159';c.lineWidth=2.2;c.beginPath();c.ellipse(0,19,48,15,0,0,Math.PI*2);c.fill();c.stroke();
    c.strokeStyle='rgba(158,125,98,.45)';c.lineWidth=1;c.beginPath();c.ellipse(0,19,38,10,0,0,Math.PI*2);c.stroke();
    if(remain<=0){
      c.fillStyle='#bc8050';for(var crumb=0;crumb<8;crumb++){c.beginPath();c.arc(-29+crumb*8,12+(crumb%3)*3,1.8+(crumb%2),0,Math.PI*2);c.fill();}
      c.restore();c.fillStyle='#44383a';c.font='800 12px system-ui';c.textAlign='center';c.fillText(tr('foodDone'),w*.5,sy+47);c.textAlign='left';return;
    }
    c.globalAlpha=.42+remain*.58;
    if(z%4===0){
      // Layered strawberry cake with frosting, fruit and glossy icing.
      var cakeR=Math.max(12,36*remain);
      c.fillStyle='#bd7957';c.strokeStyle='#795144';c.lineWidth=2.4;
      c.beginPath();c.ellipse(0,8,cakeR,19*remain,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#f3c18e';c.beginPath();c.ellipse(0,1,cakeR,19*remain,0,0,Math.PI*2);c.fill();
      c.fillStyle='#fff4e5';c.beginPath();c.ellipse(0,-9,cakeR,18*remain,0,0,Math.PI*2);c.fill();
      c.fillStyle='#ef8290';c.beginPath();c.ellipse(0,-12,cakeR*.88,15*remain,0,0,Math.PI*2);c.fill();
      c.strokeStyle='#fff4e9';c.lineWidth=4;c.beginPath();c.ellipse(0,-12,cakeR*.82,12*remain,0,0,Math.PI*2);c.stroke();
      for(var berry=0;berry<5;berry++){
        var theta=berry*Math.PI*2/5,bx=Math.cos(theta)*cakeR*.62,by=-13+Math.sin(theta)*10*remain;
        c.fillStyle='#d94d62';c.beginPath();c.ellipse(bx,by,4.3*remain,5.6*remain,.2,0,7);c.fill();
        c.fillStyle='#7da45e';c.beginPath();c.ellipse(bx-1,by-4,2.4,1.5,-.4,0,7);c.fill();
      }
      c.fillStyle='#fffaf3';for(var cream=0;cream<4;cream++){c.beginPath();c.arc(-18+cream*12,-18+(cream%2)*5,2.2,0,7);c.fill();}
    }else if(z%4===1){
      c.fillStyle='#f2c98f';c.strokeStyle='#805d4b';c.lineWidth=2.4;c.beginPath();c.arc(0,0,31*remain,0,Math.PI*2);c.arc(0,0,12*remain,0,Math.PI*2,true);c.fill('evenodd');c.stroke();
      c.fillStyle='#fff0d2';c.beginPath();c.ellipse(0,-13,22*remain,7,0,0,Math.PI*2);c.fill();
      c.fillStyle='#dc7b61';for(var sprinkle=0;sprinkle<6;sprinkle++)c.fillRect(-15+sprinkle*6,-2+(sprinkle%2)*8,3,1.6);
    }else if(z%4===2){
      c.fillStyle='#b7cb82';c.strokeStyle='#627c4c';c.lineWidth=2.5;c.beginPath();c.moveTo(0,-28*remain);c.bezierCurveTo(34*remain,-29*remain,35*remain,11*remain,10*remain,25*remain);c.bezierCurveTo(-13*remain,39*remain,-34*remain,12*remain,-27*remain,-9*remain);c.bezierCurveTo(-21*remain,-26*remain,-9*remain,-29*remain,0,-28*remain);c.fill();c.stroke();c.strokeStyle='#526543';c.beginPath();c.moveTo(0,-25*remain);c.lineTo(3,-37*remain);c.stroke();
    }else if(z%4===3){
      c.fillStyle='#dfb37c';c.strokeStyle='#785c48';c.lineWidth=2.4;c.beginPath();c.roundRect(-31*remain,-21*remain,62*remain,42*remain,8);c.fill();c.stroke();
      c.fillStyle='#725b47';for(var chip=0;chip<7;chip++){c.beginPath();c.arc(-20+chip*7,-10+(chip%3)*10,2,0,Math.PI*2);c.fill();}
    }else{
      c.fillStyle='#e8aa79';c.strokeStyle='#75534d';c.lineWidth=2.7;c.beginPath();c.ellipse(0,13,Math.max(10,38*remain),15,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#f4c6a0';c.beginPath();c.ellipse(0,-1,Math.max(8,33*remain),21,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#ed6f72';c.beginPath();c.ellipse(-3,-8,Math.max(5,20*remain),9,0,0,Math.PI*2);c.fill();c.fillStyle='#fff2d9';c.beginPath();c.arc(8,-12,3,0,Math.PI*2);c.fill();
    }
    c.restore();c.fillStyle='#44383a';c.font='800 12px system-ui';c.textAlign='center';c.fillText(tr('food'),w*.5,sy+48);c.textAlign='left';
  }
  function drawTower(c,t,cam,w,h){
    var x=t.x*w,y=worldY(t.y,cam,h),outline='#493d3a',clock=state.simTime||0;
    if(y<-70||y>h+75)return;
    var target=state.army.filter(function(a){return a.hp>0;}).sort(function(a,b){return Math.hypot((a.x-t.x)*w,a.y-t.y)-Math.hypot((b.x-t.x)*w,b.y-t.y);})[0];
    var aim=target?Math.atan2(-(target.y-t.y),(target.x-t.x)*w):Math.PI;
    var firing=Number.isFinite(t.fireAt)&&clock-t.fireAt>=0&&clock-t.fireAt<.28;
    var towerSprite=sceneSprite('tower-'+(t.kind==='gun'||t.kind==='flame'||t.kind==='spray'?t.kind:'other'));
    if(towerSprite){
      c.save();c.translate(x,y);
      c.drawImage(towerSprite,-40,-45,80,72);
      if(t.elite){c.strokeStyle='#e9bc50';c.lineWidth=2;c.setLineDash([4,4]);c.beginPath();c.arc(0,0,37,0,Math.PI*2);c.stroke();c.setLineDash([]);}
      var towerRatio=clamp(t.hp/Math.max(1,t.maxHp),0,1);
      c.fillStyle='#433a39';c.beginPath();c.roundRect(-23,29,46,8,4);c.fill();
      c.fillStyle=towerRatio>.55?'#80a76b':towerRatio>.25?'#dfb851':'#d76c58';c.beginPath();c.roundRect(-21,31,42*towerRatio,4,2);c.fill();
      c.fillStyle='#493d3a';c.font='700 8px system-ui';c.textAlign='center';c.fillText(Math.ceil(t.hp)+'/'+t.maxHp,0,46);
      c.restore();return;
    }
    c.save();c.translate(x,y);
    if(t.elite){c.strokeStyle='#db9d32';c.lineWidth=3;c.setLineDash([5,5]);c.beginPath();c.arc(0,0,34,0,Math.PI*2);c.stroke();c.setLineDash([]);}
    c.fillStyle='rgba(62,47,41,.20)';c.beginPath();c.ellipse(2,18,30,10,0,0,Math.PI*2);c.fill();
    c.fillStyle='#857467';c.strokeStyle=outline;c.lineWidth=2.5;c.beginPath();c.roundRect(-23,-1,46,25,7);c.fill();c.stroke();
    c.fillStyle='#b3a18a';c.lineWidth=1;c.beginPath();c.roundRect(-18,4,36,16,4);c.fill();c.stroke();
    var bodyShine=c.createLinearGradient(-20,0,20,20);bodyShine.addColorStop(0,'rgba(255,255,240,.42)');bodyShine.addColorStop(1,'rgba(20,30,35,.10)');c.fillStyle=bodyShine;c.beginPath();c.roundRect(-18,4,36,16,4);c.fill();
    c.fillStyle='#efe1bf';[-14,14].forEach(function(rx){c.beginPath();c.arc(rx,7,2.3,0,7);c.fill();});
    [-14,14].forEach(function(rx){c.fillStyle='#5c5048';c.beginPath();c.arc(rx,12,2,0,Math.PI*2);c.fill();});
    c.save();c.translate(0,-7);c.rotate(aim);
    if(t.kind==='gun'){
      c.fillStyle='#566e84';c.strokeStyle=outline;c.lineWidth=2;c.beginPath();c.arc(0,0,12,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#708ba2';c.beginPath();c.roundRect(4,-5,25,10,4);c.fill();c.stroke();
      c.fillStyle='#293c49';c.beginPath();c.arc(28,0,3,0,Math.PI*2);c.fill();
      if(firing){c.fillStyle='#ffd16f';c.beginPath();c.moveTo(30,0);c.lineTo(43,-6);c.lineTo(39,0);c.lineTo(43,6);c.closePath();c.fill();for(var bi=0;bi<3;bi++){c.fillStyle='#f5c650';c.beginPath();c.arc(42+bi*7,Math.sin(clock*55+bi)*2,1.8,0,Math.PI*2);c.fill();}}
    }else if(t.kind==='flame'){
      c.fillStyle='#bd644c';c.strokeStyle=outline;c.lineWidth=2;c.beginPath();c.roundRect(-11,-11,20,22,5);c.fill();c.stroke();
      c.fillStyle='#e8a16d';c.beginPath();c.roundRect(1,-7,24,14,4);c.fill();c.stroke();c.fillStyle='#5f433c';c.beginPath();c.arc(24,0,4,0,Math.PI*2);c.fill();
      if(firing){c.fillStyle='rgba(247,139,68,.42)';c.beginPath();c.moveTo(26,-7);c.quadraticCurveTo(51,-8,58,0);c.quadraticCurveTo(50,8,26,7);c.closePath();c.fill();c.fillStyle='#efac55';c.beginPath();c.moveTo(28,-4);c.quadraticCurveTo(45,0,28,4);c.closePath();c.fill();}
    }else if(t.kind==='spray'){
      c.fillStyle='#6c9d91';c.strokeStyle=outline;c.lineWidth=2;c.beginPath();c.roundRect(-11,-13,21,26,5);c.fill();c.stroke();
      c.fillStyle='#d8e5c2';c.fillRect(-7,-6,13,12);c.fillStyle='#495e57';c.fillRect(-4,-18,8,6);c.fillStyle='#76948b';c.beginPath();c.moveTo(7,-8);c.lineTo(20,-8);c.lineTo(24,-3);c.lineTo(10,-2);c.closePath();c.fill();c.stroke();
      if(firing){for(var mi=0;mi<8;mi++){var travel=(mi%4)*8+((clock*38+mi*11)%7);c.globalAlpha=.42;c.fillStyle='#eff6e6';c.beginPath();c.arc(25+travel,Math.sin(clock*13+mi*2)*8+(mi-4)*2,2+(mi%3),0,Math.PI*2);c.fill();}c.globalAlpha=1;}
    }else{
      c.fillStyle='#d49c37';c.strokeStyle=outline;c.lineWidth=2;c.beginPath();c.moveTo(-11,-10);c.lineTo(8,-10);c.lineTo(11,-4);c.lineTo(9,12);c.lineTo(-10,12);c.closePath();c.fill();c.stroke();
      c.fillStyle='#f4d36c';c.beginPath();c.ellipse(0,-11,12,4,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#fff0ae';c.beginPath();c.ellipse(0,1,6,4,0,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(223,169,53,.58)';c.strokeStyle='#b67b20';c.beginPath();c.ellipse(-2,23,24,7,0,0,Math.PI*2);c.fill();c.stroke();c.beginPath();c.ellipse(28,22,14,5,.1,0,Math.PI*2);c.fill();c.stroke();
      if(firing){c.fillStyle='#f2c950';c.beginPath();c.arc(17,0,3+Math.sin(clock*30)*1.2,0,Math.PI*2);c.fill();}
    }
    c.restore();
    if(state.army.some(function(a){return a.hp>0&&a.target===t.id;})){c.strokeStyle='#e9bd55';c.lineWidth=2;c.setLineDash([4,3]);c.beginPath();c.arc(0,-4,31,0,Math.PI*2);c.stroke();c.setLineDash([]);}
    var ratio=clamp(t.hp/Math.max(1,t.maxHp),0,1);
    c.fillStyle='#433a39';c.beginPath();c.roundRect(-23,29,46,8,4);c.fill();c.fillStyle=ratio>.55?'#80a76b':ratio>.25?'#dfb851':'#d76c58';c.beginPath();c.roundRect(-21,31,42*ratio,4,2);c.fill();
    c.fillStyle='#f7edd9';c.font='700 8px system-ui';c.textAlign='center';c.fillText(Math.ceil(t.hp)+'/'+t.maxHp,0,46);c.restore();
  }
  // Swarm-only illustrated characters: no changes to the classic renderer.
  function glossyOval(c,x,y,rx,ry,top,bottom,stroke){
    var g=typeof c.createLinearGradient==='function'?c.createLinearGradient(x,y-ry,x,y+ry):null;if(g){g.addColorStop(0,top);g.addColorStop(1,bottom);}
    c.fillStyle=g||top;c.strokeStyle=stroke||'#493c38';c.lineWidth=1.35;
    c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='rgba(255,255,255,.42)';c.beginPath();c.ellipse(x-rx*.25,y-ry*.43,rx*.48,ry*.2,-.25,0,Math.PI*2);c.fill();
  }
  function insectForm(c,role,phase){
    var wiggle=Math.sin(phase)*1.1;
    c.save();c.lineCap='round';c.lineJoin='round';
    // Keep the original renderer contract for other integrations, but draw only our swarm skin.
    if(window.PPSwarmBridge&&typeof window.PPSwarmBridge.drawInsect==='function'){
      c.save();c.globalAlpha=0;try{window.PPSwarmBridge.drawInsect(c,ROLES[role].type,12.5,phase||0);}finally{c.restore();}
    }
    var palette={worker:['#efbc65','#a66b37'],armor:['#7ebc91','#2d765e'],breaker:['#bd91df','#744e9d'],medic:['#f48e85','#b95059']};
    var pal=palette[role]||palette.worker;
    // Legs and antennae are deliberately oversized for readability on a phone.
    c.strokeStyle='#4c433e';c.lineWidth=2.05;
    for(var i=-1;i<=1;i++){
      var bx=-4+i*5,dy=wiggle*(i===0?-1:1);
      c.beginPath();c.moveTo(bx,-5);c.quadraticCurveTo(bx-5,-10+dy,bx-9,-12+dy);c.stroke();
      c.beginPath();c.moveTo(bx,5);c.quadraticCurveTo(bx-5,10-dy,bx-9,12-dy);c.stroke();
    }
    c.strokeStyle='#514038';c.lineWidth=1.6;
    c.beginPath();c.moveTo(7,-5);c.quadraticCurveTo(15,-15,19,-12+wiggle);c.moveTo(7,5);c.quadraticCurveTo(15,15,19,12-wiggle);c.stroke();
    glossyOval(c,-6,0,7,7,pal[0],pal[1]);
    glossyOval(c,1,0,9,8,pal[0],pal[1]);
    glossyOval(c,9,0,7,7,pal[0],pal[1]);
    if(role==='armor'){
      glossyOval(c,-1,0,9.5,8.5,'#9de0a4','#327c62','#315f50');
      c.strokeStyle='#32674e';c.lineWidth=1.3;c.beginPath();c.moveTo(-1,-7);c.lineTo(-1,7);c.stroke();
      c.fillStyle='#d3f6c4';c.beginPath();c.arc(-5,-3,1.8,0,7);c.fill();
    }else if(role==='breaker'){
      c.fillStyle='#e5c9ff';c.strokeStyle='#61448c';c.lineWidth=1.5;
      c.beginPath();c.moveTo(9,-5);c.lineTo(19,-12);c.lineTo(17,-2);c.lineTo(11,0);c.lineTo(17,2);c.lineTo(19,12);c.lineTo(9,5);c.stroke();c.fill();
    }else if(role==='medic'){
      c.fillStyle='#fff7e5';c.strokeStyle='#bd625f';c.lineWidth=1;c.beginPath();c.arc(-1,0,5.2,0,7);c.fill();c.stroke();
      c.fillStyle='#db5960';c.fillRect(-2.1,-3.6,2.2,7.2);c.fillRect(-4.6,-1.1,7.2,2.2);
    }else{
      c.strokeStyle='#7e562e';c.lineWidth=1;c.beginPath();c.moveTo(-6,-5);c.lineTo(-6,5);c.moveTo(-2,-6);c.lineTo(-2,6);c.stroke();
    }
    // Expressive eyes, bright highlights and friendly facial detail.
    for(var eye=-1;eye<=1;eye+=2){c.fillStyle='#fff9ef';c.beginPath();c.ellipse(12,eye*3.2,2.45,2.2,0,0,7);c.fill();c.fillStyle='#292e34';c.beginPath();c.arc(13,eye*3.2,.95,0,7);c.fill();}
    c.strokeStyle='#63463b';c.lineWidth=.8;c.beginPath();c.arc(14,0,1.9,.1,Math.PI-.1);c.stroke();
    c.restore();
  }
  // 2.5D sprite artwork is scoped to this mode only. Canvas drawings remain as fallback.
  var swarmArt={};
  function loadSwarmArt(){
    if(typeof Image==='undefined')return;
    Object.keys(ROLES).forEach(function(role){
      if(swarmArt[role])return;
      var img=new Image();swarmArt[role]={image:img,ready:false};
      img.onload=function(){swarmArt[role].ready=true;if(ui&&ui.roles)ui.roles.forEach(function(b){if(b.getAttribute('data-role')===role)renderRolePortrait(b.querySelector('canvas'),role);});};
      img.onerror=function(){swarmArt[role].ready=false;};
      img.src='assets/swarm-art/'+role+'.svg';
    });
  }
  function paintSwarmArt(c,role,phase){
    var art=swarmArt[role];if(!art||!art.ready)return false;
    c.save();c.translate(0,Math.sin(phase||0)*.9);c.drawImage(art.image,-17,-15,34,30);c.restore();return true;
  }
  function renderRolePortrait(canvas,role){
    loadSwarmArt();
    if(!canvas||!canvas.getContext||!ROLES[role])return false;
    var c=canvas.getContext('2d');if(!c)return false;
    var w=canvas.width||64,h=canvas.height||48;c.clearRect(0,0,w,h);c.save();
    c.translate(w*.5,h*.5);c.scale(Math.min(w/34,h/38),Math.min(w/34,h/38));
    c.fillStyle='rgba(55,43,32,.1)';c.beginPath();c.ellipse(-.5,5.2,12,4.1,0,0,Math.PI*2);c.fill();
    if(!paintSwarmArt(c,role,0))insectForm(c,role,0);c.restore();return true;
  }
  function drawBug(c,a,cam,w,h){
    var spec=ROLES[a.role],x=a.x*w,y=worldY(a.y,cam,h),target=a.target&&state.towers.filter(function(t){return t.id===a.target;})[0];
    if(!target&&a.role!=='worker')target=state.towers.filter(function(t){return t.alive;}).sort(function(p,q){return Math.hypot((p.x-a.x)*w,p.y-a.y)-Math.hypot((q.x-a.x)*w,q.y-a.y);})[0];
    var tx=target?target.x:.5,ty=target?target.y:state.zone*760+490,angle=Number.isFinite(a.facing)?-a.facing:Math.atan2(-(ty-a.y),(tx-a.x)*w);
    var phase=(state.simTime||0)*13+(Number(a.id)||0)*.017,scale=Math.max(.8,spec.r/7);
    c.save();c.translate(x,y);c.rotate(angle);c.scale(scale,scale);
    c.fillStyle='rgba(43,34,27,.2)';c.beginPath();c.ellipse(-.6,5.1,12.8,4.3,0,0,Math.PI*2);c.fill();
    if(!paintSwarmArt(c,a.role,phase))insectForm(c,a.role,phase);c.restore();
    if(a.hp<a.maxHp){var bar=18,ratio=clamp(a.hp/a.maxHp,0,1);c.fillStyle='#53433d';c.fillRect(x-bar/2,y-14,bar,3);c.fillStyle=ratio>.45?'#78a86b':'#d97162';c.fillRect(x-bar/2,y-14,bar*ratio,3);}
  }
  function drawPreview(c,d,w,h){
    var previewShape=state.shape==='auto'?recognizeGesture(d.points||[d.a,d.b]):state.shape,previewEnds=gestureEndpoints(d.points||[d.a,d.b],previewShape);var pts=formationSlots(state.selected,previewShape,previewEnds[0],previewEnds[1],ui.deployBox()).filter(function(p){var world=worldPoint(p.x,p.y),spec=ROLES[state.selected];return !state.army.some(function(u){return u.hp>0&&Math.hypot((u.x-world.x)*ui.w,u.y-world.y)<ROLES[u.role].r+spec.r+4;});});
    c.strokeStyle='#398756';c.lineWidth=2;c.setLineDash([4,4]);c.beginPath();c.moveTo(d.a.x,d.a.y);if(d.points&&d.points.length>2){d.points.forEach(function(p,i){if(i)c.lineTo(p.x,p.y);});c.stroke();c.beginPath();c.moveTo(d.a.x,d.a.y);}
    if(previewShape==='line')c.lineTo(d.b.x,d.b.y);else {var box=ui.deployBox(),r=clamp(Math.hypot(d.b.x-d.a.x,d.b.y-d.a.y),previewShape==='circle'?18:24,Math.min(box.w,box.h)*(previewShape==='circle'?.42:.47)),rotation=previewShape==='circle'?0:Math.atan2(d.b.y-d.a.y,d.b.x-d.a.x);c.arc(d.a.x,d.a.y,r,(previewShape==='circle'?0:Math.PI)+rotation,Math.PI*2+rotation);}
    c.stroke();c.setLineDash([]);var n=Math.min(pts.length,state.reserve[state.selected]||0,CAP-state.army.filter(function(a){return a.hp>0;}).length);pts.slice(0,n).forEach(function(p){c.fillStyle='#4b9064';c.beginPath();c.arc(p.x,p.y,4,0,7);c.fill();});c.fillStyle='#2c4e3a';c.font='bold 12px system-ui';c.fillText(n+' '+tr('selected'),d.b.x+6,d.b.y-7);
  }
  function updateHud(){
    if(!ui)return;if(ui.tactics)ui.tactics.hidden=state.phase!=='plan';ui.root.classList.toggle('sw-ar',langCode()==='ar');ui.title.textContent=tr('title');
    ui.foodHud.textContent=tr('food')+' '+Math.round(100-state.foodHp)+'%';var n=state.towers.filter(function(t){return t.alive;}).length;ui.towerHud.textContent=tr('towers')+' '+n;
    ui.roles.forEach(function(b){var role=b.getAttribute('data-role'),count=state.reserve[role]||0;b.classList.toggle('selected',role===state.selected);b.setAttribute('aria-pressed',String(role===state.selected));b.disabled=count<=0;b.querySelector('small').textContent=count+' '+tr('troops');b.querySelector('b').textContent=roleLabel(role);});
    if(ui.shapeButtons)ui.shapeButtons.forEach(function(b){b.classList.toggle('active',b.dataset.shape===state.shape);b.setAttribute('aria-pressed',String(b.dataset.shape===state.shape));});
    ui.home.textContent=tr('home');
    if(ui.attackButton){ui.attackButton.textContent=tr('attack');ui.attackButton.disabled=state.phase!=='plan'||!alive().some(function(a){return a.role!=='medic';});ui.autoButton.textContent=tr('auto');ui.autoButton.disabled=state.phase!=='plan';ui.undoButton.textContent=tr('undo');ui.undoButton.disabled=state.phase!=='plan'||!state.formations.length;ui.commandButton.textContent=tr(state.command==='attack'?'attackOrder':state.command);}
    ui.pause.textContent=state.paused?tr('resume'):tr('pause');
  }
  function roleLabel(key){var l=langCode();return l==='ar'?ROLES[key].ar:ROLES[key].label;}
  function openBanner(html){ui.banner.innerHTML=html;ui.banner.hidden=false;}
  function closeBanner(){ui.banner.classList.remove('sw-shop-open');ui.banner.hidden=true;}
  function paintBanner(){
    var l=langCode()==='ar';
    if(state.phase==='repair'&&!state.repairTaken){
      var opts=state.offer||[];openBanner('<h2>'+tr('repair')+'</h2><p>'+tr('choose')+'</p><div class="sw-choices">'+opts.map(function(o){return '<button class="sw-choice" data-repair="'+o.id+'"><span>'+o.title+'</span><small>'+o.text+'</small></button>';}).join('')+'</div>');
      ui.banner.querySelectorAll('[data-repair]').forEach(function(b){b.onclick=function(){applyRepair(b.dataset.repair);closeBanner();updateHud();};});return;
    }
    if(state.phase==='defeat'){
      var coins=calculateReward();recordGrowth();openBanner('<h2>'+tr('defeat')+'</h2><p>'+tr('report')+': '+state.foods+' '+tr('foods')+' · '+state.towersBroken+' '+tr('broken')+' · '+state.distance+' '+tr('distance')+'<br>'+tr('largest')+': '+state.largest+' · '+tr('best')+': '+(state.personalBest||state.zone)+'<br>+'+coins+' coins · +'+(state.rolePointsAwarded||0)+' ⭐</p><button class="sw-button primary" data-dismiss>'+tr('home')+'</button>');
      ui.banner.querySelector('[data-dismiss]').onclick=exitHome;return;
    }
    closeBanner();
  }
  // Each selected species contributes its entire available troop count; no per-unit +/- controls.
  function speciesCount(role){
    var base=starterRoster()[role]||0;
    return Math.min(CAP,base+roleLevel(role)*2+Math.floor(growth().level/3));
  }
  function showStarterPicker(){
    if(!state||state.phase!=='plan'||state.zone!==0||state.army.length)return;
    if(!state.rosterPicked){state.rosterPicked={worker:true,armor:true,breaker:true,medic:true};}
    function applyPicked(){
      Object.keys(ROLES).forEach(function(k){state.reserve[k]=state.rosterPicked[k]?speciesCount(k):0;});
    }
    function render(){
      applyPicked();
      var ar=langCode()==='ar',progress=roleProgress(),selected=Object.keys(ROLES).filter(function(k){return state.rosterPicked[k];});
      var total=selected.reduce(function(n,k){return n+state.reserve[k];},0);
      var html='<div class="sw-shop-head"><span class="sw-shop-icon">✦</span><div><h2>'+(ar?'تجهيز جيش الغزو':'BUILD YOUR SWARM')+'</h2><p>'+(ar?'اختر أنواع الحشرات لتدخل بكامل عددها':'Select a species to deploy its entire troop count')+'</p></div><span class="sw-shop-head-badge">⚔</span></div>';
      html+='<div class="sw-shop-summary"><span>'+(ar?'الجيش المختار':'Selected army')+'</span><strong>'+total+' <em>/ '+CAP+'</em></strong><div class="sw-shop-track"><i style="width:'+Math.min(100,Math.round(total/CAP*100))+'%"></i></div></div>';
      html+='<div class="sw-shop-grid">';
      Object.keys(ROLES).forEach(function(k){
        var lv=progress.levels[k],cost=upgradeCost(k),count=speciesCount(k),picked=!!state.rosterPicked[k];
        var specialty={worker:ar?'جمع الطعام':'Foraging',armor:ar?'الدفاع والحماية':'Defense',breaker:ar?'تحطيم الأبراج':'Siege',medic:ar?'العلاج والدعم':'Healing'}[k];
        html+='<article class="sw-shop-card sw-shop-'+k+(picked?' is-picked':'')+'"><button type="button" class="sw-shop-select" data-pick="'+k+'" aria-pressed="'+picked+'" aria-label="'+(ar?'اختيار ':'Select ')+roleLabel(k)+'"><span class="sw-shop-check">'+(picked?'✓':'○')+'</span><div class="sw-shop-art"><img src="assets/swarm-art/'+k+'.svg" alt="" draggable="false"><span class="sw-shop-level">'+(ar?'مستوى ':'Lv ')+lv+'</span></div><strong class="sw-shop-name">'+roleLabel(k)+'</strong><span class="sw-shop-specialty">'+specialty+'</span><span class="sw-shop-count">'+(ar?'العدد: ':'Troops: ')+'<b>'+count+'</b></span></button>';
        html+='<button type="button" class="sw-shop-upgrade" data-upgrade="'+k+'" '+(lv>=8||progress.points<cost?'disabled':'')+'>'+(lv>=8?(ar?'أقصى مستوى':'MAX'):(ar?'ترقية':'Upgrade')+' · '+cost+' ★')+'</button></article>';
      });
      html+='</div><div class="sw-shop-points">★ '+(ar?'نقاط التطوير':'Upgrade points')+': <strong>'+progress.points+'</strong></div>';
      html+='<button class="sw-button primary sw-shop-ready" data-ready '+(!selected.some(function(k){return k!=='medic';})||total>CAP?'disabled':'')+'>'+(ar?'ابدأ الغزو':'Start invasion')+'</button>';
      openBanner(html);ui.banner.classList.add('sw-shop-open');
      ui.banner.querySelectorAll('[data-pick]').forEach(function(btn){btn.onclick=function(){
        var k=btn.dataset.pick,next=!state.rosterPicked[k];
        if(next&&total+speciesCount(k)>CAP)return;
        state.rosterPicked[k]=next;render();
      };});
      ui.banner.querySelectorAll('[data-upgrade]').forEach(function(btn){btn.onclick=function(){if(buyRoleUpgrade(btn.dataset.upgrade))render();};});
      ui.banner.querySelector('[data-ready]').onclick=function(){
        if(total>CAP||!selected.some(function(k){return k!=='medic';}))return;
        applyPicked();state.starterChosen=true;closeBanner();save(true);updateHud();
        if(attackMode==='auto')autoAssault();
      };
    }
    render();
  }
  function createUI(){
    var root=document.createElement('div');root.id='pp-swarm-root';root.hidden=true;
    root.innerHTML='<canvas id="pp-swarm-world"></canvas><header class="sw-head"><strong class="sw-brand" id="sw-title"></strong><div class="sw-head-actions"><button class="sw-button" id="sw-pause"></button><button class="sw-button" id="sw-home"></button></div></header><div class="sw-hud"><span class="sw-meter" id="sw-tower"></span><span class="sw-meter food" id="sw-food"></span></div><aside class="sw-tactics" id="sw-tactics"><button class="sw-button sw-attack-mode" id="sw-attack-mode" type="button" aria-pressed="false"></button><div class="sw-actions"><button class="sw-button" id="sw-auto"></button><button class="sw-button" id="sw-undo"></button><button class="sw-button" id="sw-command"></button><button class="sw-button primary" id="sw-attack"></button></div><button class="sw-button sw-formation-toggle" id="sw-formation-toggle" type="button" aria-label="اختيار الشكل الهندسي" title="اختيار الشكل الهندسي">✎</button><div class="sw-shapes" id="sw-shapes" hidden></div></aside><section class="sw-dock"><div class="sw-roster" id="sw-roster"></div></section><div class="sw-banner" id="sw-banner" hidden></div>';
    document.body.appendChild(root);
    var canvas=root.querySelector('#pp-swarm-world'),ctx=canvas.getContext('2d'),roles=root.querySelector('#sw-roster');
    Object.keys(ROLES).forEach(function(k){roles.insertAdjacentHTML('beforeend','<button class="sw-role" data-role="'+k+'"><canvas width="84" height="62" aria-hidden="true"></canvas><b></b><small></small></button>');renderRolePortrait(roles.lastElementChild.querySelector('canvas'),k);});
    ui={root:root,canvas:canvas,ctx:ctx,w:360,h:640,dpr:1,particles:[],drag:null,title:root.querySelector('#sw-title'),pause:root.querySelector('#sw-pause'),home:root.querySelector('#sw-home'),hint:null,foodHud:root.querySelector('#sw-food'),towerHud:root.querySelector('#sw-tower'),roles:Array.from(roles.children),banner:root.querySelector('#sw-banner')};
    ui.deployBox=function(){var dock=ui.root.querySelector('.sw-dock').getBoundingClientRect(),root=ui.root.getBoundingClientRect(),top=Math.max(viewOrigin(ui.h)-300,ui.h*.36);return {x:0,y:top,w:ui.w,h:Math.max(0,dock.top-root.top-top-12)};};
    ui.roles.forEach(function(b){b.onclick=function(){if(!state||state.paused||!ui.banner.hidden)return;state.selected=b.dataset.role;updateHud();};});
    var shapes=root.querySelector('#sw-shapes');FORM_SHAPES.forEach(function(k){var b=document.createElement('button');b.className='sw-shape';b.dataset.shape=k;b.textContent=shapeLabel(k);b.onclick=function(){if(!state||state.paused||state.phase!=='plan')return;state.shape=k;updateHud();};shapes.appendChild(b);});ui.shapeButtons=Array.from(shapes.children);ui.tactics=root.querySelector('#sw-tactics');ui.shapeToggle=root.querySelector('#sw-formation-toggle');ui.shapeToggle.onclick=function(){shapes.hidden=!shapes.hidden;ui.shapeToggle.setAttribute('aria-expanded',String(!shapes.hidden));};ui.shapeToggle.setAttribute('aria-expanded','false');
    ui.pause.onclick=togglePause;ui.home.onclick=exitPrompt;ui.attackButton=root.querySelector('#sw-attack');ui.autoButton=root.querySelector('#sw-auto');ui.undoButton=root.querySelector('#sw-undo');ui.commandButton=root.querySelector('#sw-command');ui.modeButton=root.querySelector('#sw-attack-mode');ui.modeButton.onclick=function(){setAttackMode(attackMode==='auto'?'manual':'auto');};setAttackMode(attackMode);ui.attackButton.onclick=startFight;ui.autoButton.onclick=autoDeploy;ui.undoButton.onclick=undoLast;ui.commandButton.onclick=cycleCommand;
    canvas.addEventListener('pointerdown',function(e){
      if(!state||state.paused||!ui.banner.hidden||state.phase!=='plan'&&state.phase!=='fight')return;
      var r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top},box=ui.deployBox();
      if(p.y<box.y||p.y>box.y+box.h){
        var hit=state.towers.find(function(t){return t.alive&&Math.hypot(t.x*ui.w-p.x,worldY(t.y,state.camera,ui.h)-p.y)<36;});
        if(hit){state.army.forEach(function(u){u.target=hit.id;});save(true);}return;
      }
      if(state.phase==='plan'){
        var unit=state.army.filter(function(u){return u.hp>0&&u.formation;}).sort(function(a,b){return Math.hypot(a.x*ui.w-p.x,worldY(a.y,state.camera,ui.h)-p.y)-Math.hypot(b.x*ui.w-p.x,worldY(b.y,state.camera,ui.h)-p.y);})[0];
        if(unit&&Math.hypot(unit.x*ui.w-p.x,worldY(unit.y,state.camera,ui.h)-p.y)<16){
          var f=state.formations.find(function(x){return x.id===unit.formation;});
          if(f){ui.drag={formation:f,last:p};canvas.setPointerCapture(e.pointerId);return;}
        }
      }
      ui.drag={a:p,b:p,points:[p]};canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove',function(e){
      if(!ui.drag)return;var r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};
      if(ui.drag.formation){
        var f=ui.drag.formation,dx=p.x-ui.drag.last.x,dy=p.y-ui.drag.last.y,box=ui.deployBox(),members=f.units.filter(function(u){return u.hp>0;});
        var invalid=members.some(function(u){var radius=ROLES[u.role].r,x=u.x*ui.w+dx,y=worldY(u.y,state.camera,ui.h)+dy;return x<radius||x>ui.w-radius||y<box.y+radius||y>box.y+box.h-radius;});
        if(invalid)return;
        var blocked=members.some(function(u){return state.army.some(function(other){return other.hp>0&&members.indexOf(other)<0&&Math.hypot((other.x-u.x-dx/ui.w)*ui.w,other.y-u.y+dy)<ROLES[other.role].r+ROLES[u.role].r+3;});});
        if(!blocked){members.forEach(function(u){u.x+=dx/ui.w;u.y-=dy;});ui.drag.last=p;}return;
      }
      ui.drag.b=p;if(ui.drag.points&&(!ui.drag.points.length||dist(ui.drag.points[ui.drag.points.length-1],p)>4))ui.drag.points.push(p);
    });
    canvas.addEventListener('pointerup',function(){if(!ui.drag)return;var d=ui.drag;ui.drag=null;if(d.formation){save(true);return;}var shape=state.shape==='auto'?recognizeGesture(d.points):state.shape,ends=gestureEndpoints(d.points,shape);var added=addFormation(state.selected,shape,ends);if(added){updateHud();}});
    canvas.addEventListener('pointercancel',function(){ui.drag=null;});
    window.addEventListener('resize',resize);document.addEventListener('visibilitychange',function(){if(document.hidden&&state){state.paused=true;save(true);}else if(state&&ui&&!ui.root.hidden&&rafRunning){state.paused=true;last=0;openPause();updateHud();}});
    resize();return ui;
  }
  function resize(){if(!ui)return;var r=ui.root.getBoundingClientRect();ui.w=r.width;ui.h=r.height;var head=ui.root.querySelector('.sw-head').getBoundingClientRect();ui.viewOrigin=490+Math.max(135,head.bottom-r.top+78);ui.dpr=Math.min(window.devicePixelRatio||1,quality==='low'?1:1.6);ui.canvas.width=Math.floor(ui.w*ui.dpr);ui.canvas.height=Math.floor(ui.h*ui.dpr);ui.canvas.style.width=ui.w+'px';ui.canvas.style.height=ui.h+'px';}
  function autoDeploy(){if(state.phase!=='plan')return;var roles=['armor','breaker','worker','medic'],box=ui.deployBox(),favorite=state.favorite||[];roles.forEach(function(r,index){var available=state.reserve[r]||0;if(!available)return;var saved=favorite.filter(function(f){return f.role===r;})[0],shape=saved?saved.shape:'line',n=Math.min(available,saved?saved.count:available),y=box.y+12+Math.max(0,box.h-24)*index/3,a,b;if(shape==='circle'||shape==='arc'){var radius=Math.max(22,n*ROLES[r].spacing/(shape==='circle'?Math.PI*2:Math.PI));a={x:ui.w*.5,y:clamp(y,box.y+radius,box.y+box.h-10)};b={x:ui.w*.5+radius,y:a.y};}else{var length=Math.min(box.w*.82,Math.max(2,n*ROLES[r].spacing));a={x:(ui.w-length)*.5,y:y};b={x:a.x+length,y:y};}state.selected=r;state.shape=shape;addFormation(r,shape,[a,b]);});updateHud();}
  function undoLast(){if(state.phase!=='plan'||!state.formations.length)return;var f=state.formations.pop();f.units.forEach(function(u){var i=state.army.findIndex(function(a){return a.id===u.id;});if(i>=0){state.army.splice(i,1);state.reserve[f.role]=(state.reserve[f.role]||0)+1;}});save(true);updateHud();}
  function saveFavorite(){if(!state.formations.length)return;state.favorite=state.formations.map(function(f){return {role:f.role,shape:f.shape,count:f.units.length};});try{localStorage.setItem('pp_swarm_favorite_v1',JSON.stringify(state.favorite));}catch(e){}save(true);if(ui.hint)ui.hint.textContent=tr('saved');}
  function cycleCommand(){if(state.phase!=='plan')return;state.command=state.command==='attack'?'protect':state.command==='protect'?'flank':'attack';state.army.forEach(function(a){a.command=state.command;});updateHud();save(true);}
  function startFight(){if(state.phase!=='plan'||!alive().some(function(a){return a.role!=='medic';}))return;state.phase='fight';state.army.forEach(function(u){u.command=state.command;});save(true);updateHud();}
  function resumePlaying(){state.paused=false;last=0;paintBanner();updateHud();save(true);}
  function openPause(){openBanner('<h2>'+tr('pause')+'</h2><p>'+tr('exit')+'</p><button class="sw-button primary" data-stay>'+tr('resume')+'</button>');ui.banner.querySelector('[data-stay]').onclick=resumePlaying;}
  function togglePause(){if(!state||state.phase==='defeat')return;if(state.paused){resumePlaying();}else{state.paused=true;openPause();updateHud();save(true);}}
  function exitPrompt(){if(!state)return;state.paused=true;save(true);openBanner('<h2>'+tr('home')+'</h2><p>'+tr('exit')+'</p><button class="sw-button primary" data-exit>'+tr('yes')+'</button> <button class="sw-button" data-stay>'+tr('no')+'</button>');ui.banner.querySelector('[data-exit]').onclick=exitHome;ui.banner.querySelector('[data-stay]').onclick=resumePlaying;}
  function exitHome(){save(true);stop();ui.root.hidden=true;state=null;if(window.PPSwarmBridge)window.PPSwarmBridge.setMenu();}
  function launch(resume){
    if(!ui)createUI();quality=window.PPSwarmBridge?window.PPSwarmBridge.quality():'high';
    attackMode=readAttackMode();state=resume||newRun();state.paused=false;
    if(!state.towers||!state.towers.length)state.towers=towerSet(state.zone||0);
    ensureInitial();ui.root.hidden=false;ui.particles=[];if(window.PPSwarmBridge)window.PPSwarmBridge.setPlaying();resize();
    migrateView(state,ui.h,viewOrigin(ui.h));
    state.shape='auto';setAttackMode(attackMode);updateHud();paintBanner();if(!resume||!state.starterChosen&&state.zone===0&&state.army.length===0)showStarterPicker();startLoop();
  }
  function menu(){
    var prior=load();if(!ui)createUI();stop();state=prior||newRun();state.towers=state.towers&&state.towers.length?state.towers:towerSet(state.zone||0);ui.root.hidden=false;resize();
    var buttons=prior?'<button class="sw-button primary" data-resume>'+tr('resume')+'</button><button class="sw-button" data-new>'+tr('newrun')+'</button>':'<button class="sw-button primary" data-new>'+tr('attack')+'</button>';
    openBanner('<h2>'+tr(prior?'resumeTitle':'title')+'</h2>'+buttons+' <button class="sw-button" data-home>'+tr('home')+'</button>');
    ui.banner.querySelector('[data-resume]')&&(ui.banner.querySelector('[data-resume]').onclick=function(){launch(prior);});
    ui.banner.querySelector('[data-new]').onclick=function(){if(prior&&!window.confirm(tr('newTitle')))return;var s=newRun();s.runId='run-'+Date.now();s.towers=towerSet(0);try{localStorage.setItem(SAVE_KEY,JSON.stringify(s));}catch(e){}launch(s);};
    ui.banner.querySelector('[data-home]').onclick=function(){ui.root.hidden=true;closeBanner();state=null;};
    updateHud();draw();
  }
  function install(){
    if(typeof document==='undefined')return;
    document.addEventListener('click',function(e){
      var mode=e.target&&e.target.closest&&e.target.closest('[data-mode]');
      if(mode&&mode.getAttribute('data-mode')==='cakeattack'){
        e.preventDefault();e.stopImmediatePropagation();if(window.PPSwarmBridge)window.PPSwarmBridge.sound();menu();
      }
    },true);
    window.addEventListener('pagehide',function(){save(true);});
  }
  return {install:install,launch:launch,menu:menu,FORM_SHAPES:FORM_SHAPES,starterBudget:starterBudget,starterSelection:starterSelection,roleProgress:roleProgress,buyRoleUpgrade:buyRoleUpgrade,troopSpec:troopSpec,getState:function(){return state;},setStateForTest:function(s,viewport){state=s;var w=viewport&&viewport.w||360,h=viewport&&viewport.h||640;ui={w:w,h:h,particles:[],deployBox:function(){return {x:0,y:h*.59,w:w,h:h*.25};}};},screenY:worldY,toWorldPoint:worldPoint,migrateView:migrateView,placeFormation:addFormation,ROLES:ROLES,CAP:CAP,formationSlots:formationSlots,recognizeGesture:recognizeGesture,gestureEndpoints:gestureEndpoints,renderRolePortrait:renderRolePortrait,getAttackMode:function(){return attackMode;},setAttackMode:setAttackMode,newRun:newRun,applyRepair:applyRepair,calculateReward:calculateReward,finishMarch:finishMarch,validSave:validSave,hydrate:hydrate,serialize:serialize,towerSet:towerSet,simulateFight:simulateFight,simulateMarch:simulateMarch,constants:{SAVE_KEY:SAVE_KEY}};
});

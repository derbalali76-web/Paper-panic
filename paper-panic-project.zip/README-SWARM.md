# Paper Panic — Swarm Invasion (first playable)

## ملخص النسخة العربية

هذا **مشروع اللعبة المعدّل كاملًا كما ورد في الملف المرفق**، وليس APK جاهزًا أو مجرد صور. من الواجهة الرئيسية اختر «هاجم الكعكة» لفتح «غزو السرب». أوضاع اللعب الأخرى ومهام هجوم الكعكة داخل خريطة الصفحات تبقى في مسارها الأصلي.

- الكعكة والأبراج في أعلى الشاشة، وبطاقات الحشرات الأربع وحدها في الأسفل، دون تعليمات أو صفوف أزرار إضافية.
- اختر بطاقة الحشرة واسحب خطًا في مساحة الورقة أسفل الدفاعات. يبدأ الهجوم تلقائيًا عند إطلاق أول حشرة مقاتلة، ويمكن رسم تعزيزات أثناء الهجوم.
- طول الرسم والتباعد يحددان العدد؛ الباقي يبقى في الاحتياط. بعد الترميم يتابع الناجون الهجوم تلقائيًا دون الحاجة إلى زر جديد.
- الحشرات وصور بطاقاتها تستخدم دوال الرسم الأصلية وألوان الأنواع الموجودة في المود الكلاسيكي نفسه: النملة والخنفساء والصرصور والدعسوقة، مع الحفاظ على حركة الأرجل واتجاه السير. أزيل الرسم البديل من مود الغزو، ولم تتغير رسوم الكلاسيكي.
- الأدوار الأساسية: عاملة، مدرعة، محطمة أبراج، معالجة. طاقم البداية خاص بالغزوة ولا يغير ملكية الحشرات أو مشترياتك الدائمة.
- لمس برج يحدد أولوية مهاجمته. أزيلت أزرار اختيار الأشكال والأوامر والتشكيل التلقائي والتراجع من واجهة اللعب بناءً على طلب تبسيطها.
- دمر الدفاعات والتهم الطعام حتى يتقدم الناجون. اختر مكافأة ترميم واحدة أثناء السير؛ ينتظر الجيش بأمان إذا تأخرت.
- من الإيقاف أو الرئيسية يمكنك حفظ الغزوة والعودة إليها. عند إعادة فتح المود يظهر اختيار الاستكمال أو غزوة جديدة.
- الحد الأقصى 64 حشرة مقاتلة، مع تقييد التعزيزات الكلية والمؤثرات. هذا حد برمجي، وليس إثبات أداء على هاتف ضعيف.

**التشغيل والبناء:** افتح `index.html` لتجربة المتصفح، أو استخدم ملفات `www` في مشروع Capacitor الأصلي. بعد تثبيت اعتماديات المشروع شغّل `npm test` للفحوص و`npm run sync` لمزامنة ملفات الويب قبل بناء Android بالطريقة المعتادة. بنية المشروع الأصلية وملفات إعداد البناء مرفقة؛ لم يُنشأ APK أو يُختبر متجر Google Play في هذه الجلسة.

**حدود هذه النسخة:** نسخة أولى قابلة للعب، وليست تنفيذًا لكل مراحل الوثيقة. لا تتضمن القادة والزعماء والمسارات المتفرعة والرسم الحر والتعرف التلقائي على الإيماءات أو أوامر مستقلة لكل مجموعة أو نظام عوائق ومسارات متقدم. الواجهة الجديدة كاملة بالعربية والإنجليزية؛ بعض النصوص المساعدة في اللغات الأخرى تستخدم الإنجليزية احتياطيًا. اللعبة مصممة للشاشة العمودية؛ اختبار الأداء واللمس والدوران على هاتف Android حقيقي ما زال مطلوبًا.

## Shipped slice

The normal **Attack** entry (`cakeattack`) opens a continuous invasion overlay; map-selected, numbered cake-attack stages still use the original implementation. The corrected phone layout anchors the food and defenses at the top and leaves only four compact insect cards at the bottom. Select a card and draw a deployment line; combat starts automatically, and reinforcements can be drawn during battle. Survivors also resume automatically after the connected march and repair choice. There is no gameplay instruction panel or bottom toolbar. Pause/home, reserve feedback, tower targeting, four fixed-cadence defenses, progress, one-choice repair, defeat report, and idempotent coin settlement remain. Moving insects and card portraits directly reuse the original classic ant, beetle, roach and ladybug renderers and their original palettes through the bridge; no separate replacement insect artwork remains. Classic gameplay and renderers themselves are unchanged.

The lightweight, isolated engine maintains a fixed battle camera, streams the next zone as the army marches, and generates further encounters from a bounded current-zone defense set. Army state, reserves, zone, structures, offer state, and upgrades use the separate `pp_swarm_run_v1` local-storage key. Existing permanent attack ownership/upgrades and other modes are not modified or granted. English and Arabic have full new-flow copy; all existing supported locales show dedicated translated core labels where available and safe English fallback otherwise. The supplied monolith exposed no graphics-quality preference API, so rendering uses a bounded device-pixel ratio and never changes simulation.

## Integration and checks

- New modules: `assets/swarm-invasion.css`, `assets/swarm-invasion.js`; loaded after the existing game IIFE.
- `npm run sync` mirrors both modules into `www/assets/` before running Capacitor sync.
- `window.PPSwarmBridge` is the narrow integration surface: `getLanguage`, `setPlaying`, `setMenu`, `rewardCoins`, `sound`, and `quality`.
- The `cakeattack` home-card click is intercepted in capture phase; a nonzero map stage is not intercepted.
- `npm test` runs the existing regression checks plus `scripts/check-swarm.cjs` for safe formation capacity, strict snapshot validation and shared-object rehydration, three naturally simulated connected encounters, correct army-before-camera marching, no teleport on transition, safe waiting for repair, healer-only defeat, repair-once, reward-once across stale snapshots, module syntax, and root/www HTML parity.

## Not in this release

No commander selection, branching route choices, freehand/V formations, boss/event encounters, advanced group pathfinding, permanent invasion upgrades, or new purchase/ads provider. Theater-quality animation/audio, sustained Android device performance, touch testing on physical phones, and native store/restore testing remain follow-up verification. Run `npm run sync` before packaging so the Android `www/assets` mirror is byte-identical.

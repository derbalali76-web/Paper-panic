package com.paperpanic.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

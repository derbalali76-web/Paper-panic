# حرب الورقة: غزو الحشرات 🐜

لعبة أركيد هاتفية خفيفة (Casual Arcade) تُلعب بيد واحدة، مغلّفة بـ Capacitor للنشر على Google Play.

## التقنية
- HTML5 Canvas + JavaScript خالص (بدون React/Vite — ملف HTML واحد في `www/index.html`)
- Capacitor 6 لتغليف الـ Android
- GitHub Actions لبناء الـ APK تلقائياً

## الهوية
- **appId**: `com.paperpanic.game`
- **appName**: `حرب الورقة`
- **التوجه**: عمودي فقط (one-handed casual)

## التطوير محلياً

### المتطلبات
- Node.js 18+ و npm
- JDK 17
- Android SDK (للبناء المحلي فقط — إذا كنت تستخدم GitHub Actions فلا حاجة لها)

### التثبيت
```bash
npm install
```

### مزامنة الكود مع Android
```bash
npm run sync
```
هذا ينسخ `www/index.html` إلى `android/app/src/main/assets/public/` ويحدّث الإضافات.

### بناء APK تجريبي (debug) محلياً
```bash
cd android
./gradlew assembleDebug
```
الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

## البناء التلقائي عبر GitHub Actions

### إعداد المستودع
1. ارفع هذا المشروع (كامل) إلى **مستودع خاص** على GitHub
2. غيّر `index.html` في `www/` إذا أردت

### بناء APK تجريبي (بدون توقيع)
- كل push إلى `main` أو `master` يُطلق workflow يبني **debug APK**
- حمّله من قسم Artifacts في Actions

### بناء APK موقّع للنشر (release signed)
أضف هذه السرّية (**Secrets**) إلى المستودع تحت
`Settings → Secrets and variables → Actions → New repository secret`:

| السرّ | المحتوى |
|------|---------|
| `ANDROID_KEYSTORE_B64` | محتوى keystore.jks مُشفّر بـ base64 (مثلاً: `base64 -w0 my-release.keystore`) |
| `ANDROID_KEYSTORE_PASSWORD` | كلمة سر الـ keystore |
| `ANDROID_KEY_ALIAS` | اسم الـ alias (مثلاً: `paperpanic`) |
| `ANDROID_KEY_PASSWORD` | كلمة سر المفتاح |

إذا كانت هذه السرّيات موجودة، الـ workflow سيبني تلقائياً **release APK موقّع** جاهز للرفع على Google Play.

### توليد keystore جديد
```bash
keytool -genkeypair -v -keystore paper-panic.keystore \
  -alias paperpanic -keyalg RSA -keysize 2048 -validity 25000
```
احتفظ بالـ keystore وكلمات السرّ في مكان آمن — بدونها لن تستطيع تحديث التطبيق على Play Store مستقبلاً.

## البنية
```
paper-panic-capacitor/
├── www/
│   └── index.html         ← اللعبة نفسها
├── android/               ← مشروع Android (مُنشأ عبر `npx cap add android`)
│   └── app/
│       ├── build.gradle   ← فيه signingConfigs يقرأ من keystore.properties
│       └── src/main/
│           ├── AndroidManifest.xml
│           └── res/values/strings.xml
├── capacitor.config.json  ← إعدادات التغليف
├── package.json
└── .github/workflows/android.yml  ← بناء APK تلقائياً
```

## الصلاحيات المطلوبة
- `INTERNET` — لـ WebView
- `VIBRATE` — ردّة الفعل اللمسية عند الضرب

## تعديل اللعبة
فقط عدّل `www/index.html` ثم:
```bash
npm run sync
```
أو ادفع إلى GitHub ودعِ الـ workflow يبني لك APK جديداً.

## نشرها على Play Store
1. ولّد keystore (مرة واحدة فقط — احفظه)
2. ارفع السرّيات إلى GitHub
3. ادفع التحديثات؛ حمّل الـ release APK من Actions
4. ارفعه إلى Google Play Console

---
*مبني بالاعتماد على نفس نمط "World Dominion 2030".*
